package com.example.domain.formula

enum class FormulaSubject(val displayName: String, val subtitle: String, val topicCount: Int) {
  MATHEMATICS("Mathematics", "Quantitative Aptitude & Advanced Math", 30),
  REASONING("Reasoning", "Verbal, Analytical & Logical Reasoning", 21),
  ENGLISH("English Language", "Grammar Rules, Vocabulary & Comprehension", 27)
}

data class SolvedExample(
  val id: String,
  val problem: String,
  val hindiProblem: String = "",
  val stepByStepSolution: List<String>,
  val finalAnswer: String,
  val shortcutTip: String = ""
)

data class TopicPracticeMcq(
  val id: String,
  val question: String,
  val hindiQuestion: String = "",
  val options: List<String>,
  val hindiOptions: List<String> = emptyList(),
  val correctOptionIndex: Int, // 0..3
  val explanation: String,
  val hindiExplanation: String = ""
)

data class FormulaTopic(
  val id: String,
  val subject: FormulaSubject,
  val chapter: String,
  val title: String,
  val hindiTitle: String,
  val summary: String,
  val coreFormula: String,
  val symbolExplanations: List<Pair<String, String>>,
  val importantIdentities: List<String> = emptyList(),
  val shortcutsAndTips: List<String> = emptyList(),
  val commonMistakes: List<String> = emptyList(),
  val solvedExamples: List<SolvedExample>,
  val practiceMcqs: List<TopicPracticeMcq>
)

data class TopicQuizResult(
  val topicId: String,
  val score: Int,
  val totalQuestions: Int,
  val incorrectQuestionIndices: List<Int> = emptyList(),
  val timestamp: Long = System.currentTimeMillis()
)

data class TopicProgress(
  val topicId: String,
  val isBookmarked: Boolean = false,
  val isCompleted: Boolean = false,
  val lastScore: Int = 0,
  val totalQuestions: Int = 0,
  val incorrectQuestionIndices: List<Int> = emptyList(),
  val lastAttemptTimestamp: Long = 0L,
  val bestScorePercent: Int = 0,
  val incorrectQuestionIds: List<String> = emptyList(),
  val lastAttemptedMillis: Long = 0L
)
