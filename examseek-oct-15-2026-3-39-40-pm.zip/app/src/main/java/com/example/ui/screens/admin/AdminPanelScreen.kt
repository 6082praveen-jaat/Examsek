package com.example.ui.screens.admin

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PostAdd
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ExamCategory
import com.example.domain.model.SubscriptionTier
import com.example.domain.model.TestType
import com.example.ui.components.VerifiedBadge
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
  viewModel: MainViewModel,
  onBack: () -> Unit
) {
  val context = LocalContext.current
  val allTests by viewModel.filteredTests.collectAsState()
  val allQuestions by viewModel.allQuestions.collectAsState()

  var selectedTab by remember { mutableIntStateOf(0) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.AdminPanelSettings,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Admin & Content Studio", fontWeight = FontWeight.Bold, fontSize = 18.sp)
          }
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        }
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
        .testTag("admin_panel_screen")
    ) {
      TabRow(selectedTabIndex = selectedTab) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text("Publish Test", fontSize = 12.sp) }
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text("Add Question", fontSize = 12.sp) }
        )
        Tab(
          selected = selectedTab == 2,
          onClick = { selectedTab = 2 },
          text = { Text("Test Catalog", fontSize = 12.sp) }
        )
        Tab(
          selected = selectedTab == 3,
          onClick = { selectedTab = 3 },
          text = { Text("AI Question Review", fontSize = 12.sp) }
        )
        Tab(
          selected = selectedTab == 4,
          onClick = { selectedTab = 4 },
          text = { Text("Usage & Cost", fontSize = 12.sp) }
        )
      }

      when (selectedTab) {
        0 -> CreateTestTab(viewModel = viewModel) {
          Toast.makeText(context, "Test published successfully!", Toast.LENGTH_SHORT).show()
        }
        1 -> AddQuestionTab(viewModel = viewModel) {
          Toast.makeText(context, "Question added to Question Bank!", Toast.LENGTH_SHORT).show()
        }
        2 -> ManageContentTab(viewModel = viewModel)
        3 -> ReviewQuestionsTab(viewModel = viewModel)
        4 -> SystemUsageTab(
          testsCount = allTests.size,
          questionsCount = allQuestions.size
        )
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreateTestTab(
  viewModel: MainViewModel,
  onCreated: () -> Unit
) {
  var title by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf(ExamCategory.SSC) }
  var selectedType by remember { mutableStateOf(TestType.FULL_MOCK) }
  var selectedTier by remember { mutableStateOf(SubscriptionTier.FREE) }
  var durationStr by remember { mutableStateOf("15") }
  var totalMarksStr by remember { mutableStateOf("20") }
  var negativeRateStr by remember { mutableStateOf("0.5") }
  var subject by remember { mutableStateOf("Full Length Mock") }
  var description by remember { mutableStateOf("") }
  var isVerified by remember { mutableStateOf(true) }

  var isCatDropdownExpanded by remember { mutableStateOf(false) }
  var isTypeDropdownExpanded by remember { mutableStateOf(false) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState())
  ) {
    Text(
      text = "Publish Test Series / Mock Exam",
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold
    )
    Text(
      text = "Specify syllabus, duration, negative penalty, entitlement tier, and verified status.",
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Spacer(modifier = Modifier.height(14.dp))

    OutlinedTextField(
      value = title,
      onValueChange = { title = it },
      label = { Text("Test Title") },
      placeholder = { Text("e.g. SSC CGL 2024 Tier-1 Official Pattern Mock") },
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(10.dp)
    )

    Spacer(modifier = Modifier.height(10.dp))

    // Exam Category Dropdown
    ExposedDropdownMenuBox(
      expanded = isCatDropdownExpanded,
      onExpandedChange = { isCatDropdownExpanded = it }
    ) {
      OutlinedTextField(
        value = selectedCategory.displayName,
        onValueChange = {},
        readOnly = true,
        label = { Text("Exam Category") },
        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isCatDropdownExpanded) },
        modifier = Modifier.fillMaxWidth().menuAnchor(),
        shape = RoundedCornerShape(10.dp)
      )
      ExposedDropdownMenu(
        expanded = isCatDropdownExpanded,
        onDismissRequest = { isCatDropdownExpanded = false }
      ) {
        ExamCategory.entries.forEach { cat ->
          DropdownMenuItem(
            text = { Text(cat.displayName) },
            onClick = {
              selectedCategory = cat
              isCatDropdownExpanded = false
            }
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Test Type Dropdown
    ExposedDropdownMenuBox(
      expanded = isTypeDropdownExpanded,
      onExpandedChange = { isTypeDropdownExpanded = it }
    ) {
      OutlinedTextField(
        value = selectedType.displayName,
        onValueChange = {},
        readOnly = true,
        label = { Text("Test Type") },
        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTypeDropdownExpanded) },
        modifier = Modifier.fillMaxWidth().menuAnchor(),
        shape = RoundedCornerShape(10.dp)
      )
      ExposedDropdownMenu(
        expanded = isTypeDropdownExpanded,
        onDismissRequest = { isTypeDropdownExpanded = false }
      ) {
        TestType.entries.forEach { t ->
          DropdownMenuItem(
            text = { Text(t.displayName) },
            onClick = {
              selectedType = t
              isTypeDropdownExpanded = false
            }
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Entitlement Tier Row
    Text("Entitlement Access Tier:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      SubscriptionTier.entries.forEach { t ->
        FilterChip(
          selected = selectedTier == t,
          onClick = { selectedTier = t },
          label = { Text(t.displayName, fontSize = 11.sp) }
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      OutlinedTextField(
        value = durationStr,
        onValueChange = { durationStr = it },
        label = { Text("Duration (M)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.weight(1f),
        shape = RoundedCornerShape(10.dp)
      )
      OutlinedTextField(
        value = totalMarksStr,
        onValueChange = { totalMarksStr = it },
        label = { Text("Total Marks") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.weight(1f),
        shape = RoundedCornerShape(10.dp)
      )
      OutlinedTextField(
        value = negativeRateStr,
        onValueChange = { negativeRateStr = it },
        label = { Text("Neg. Rate") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.weight(1f),
        shape = RoundedCornerShape(10.dp)
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    OutlinedTextField(
      value = subject,
      onValueChange = { subject = it },
      label = { Text("Subject Coverage") },
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(10.dp)
    )

    Spacer(modifier = Modifier.height(10.dp))

    OutlinedTextField(
      value = description,
      onValueChange = { description = it },
      label = { Text("Test Instructions / Description") },
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(10.dp),
      maxLines = 3
    )

    Spacer(modifier = Modifier.height(14.dp))

    // Verified Content Toggle
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(
        containerColor = if (isVerified) Color(0xFFF0F9FF) else Color(0xFFFFF1F2)
      )
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = if (isVerified) "Verified Exam Series (Official Standard)" else "Demo / Community Practice Set",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = if (isVerified) Color(0xFF0369A1) else Color(0xFFBE123C)
          )
          Text(
            text = if (isVerified) "Questions aligned with official syllabus" else "Clearly separated as preview set",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Switch(
          checked = isVerified,
          onCheckedChange = { isVerified = it }
        )
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    Button(
      onClick = {
        if (title.isBlank()) return@Button
        viewModel.addCustomTest(
          title = title,
          category = selectedCategory,
          type = selectedType,
          durationMinutes = durationStr.toIntOrNull() ?: 15,
          totalMarks = totalMarksStr.toFloatOrNull() ?: 20f,
          negativeRate = negativeRateStr.toFloatOrNull() ?: 0.5f,
          isVerified = isVerified,
          subject = subject,
          description = description,
          tier = selectedTier
        ) {
          title = ""
          onCreated()
        }
      },
      modifier = Modifier
        .fillMaxWidth()
        .height(48.dp)
        .testTag("admin_save_test_btn"),
      shape = RoundedCornerShape(10.dp)
    ) {
      Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(6.dp))
      Text("Publish Test Series", fontWeight = FontWeight.Bold)
    }

    Spacer(modifier = Modifier.height(40.dp))
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddQuestionTab(
  viewModel: MainViewModel,
  onAdded: () -> Unit
) {
  val tests by viewModel.filteredTests.collectAsState()

  var selectedTestId by remember { mutableStateOf(tests.firstOrNull()?.id ?: "test_ssc_cgl_tier1_01") }
  var isTestDropdownExpanded by remember { mutableStateOf(false) }

  var subject by remember { mutableStateOf("Quantitative Aptitude") }
  var topic by remember { mutableStateOf("Arithmetic - Percentages") }
  var questionText by remember { mutableStateOf("") }
  var hindiQuestionText by remember { mutableStateOf("") }
  var optionA by remember { mutableStateOf("") }
  var optionB by remember { mutableStateOf("") }
  var optionC by remember { mutableStateOf("") }
  var optionD by remember { mutableStateOf("") }
  var correctIndex by remember { mutableIntStateOf(0) }
  var explanation by remember { mutableStateOf("") }
  var hindiExplanation by remember { mutableStateOf("") }
  var source by remember { mutableStateOf("SSC CGL Official Paper") }
  var year by remember { mutableStateOf("2024") }
  var isVerified by remember { mutableStateOf(true) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState())
  ) {
    Text(
      text = "Structured Question Bank Studio",
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold
    )
    Text(
      text = "Add verified questions with topic, bilingual statement, and transparent source labeling.",
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Spacer(modifier = Modifier.height(12.dp))

    // Select Test
    ExposedDropdownMenuBox(
      expanded = isTestDropdownExpanded,
      onExpandedChange = { isTestDropdownExpanded = it }
    ) {
      OutlinedTextField(
        value = tests.find { it.id == selectedTestId }?.title ?: "Select Test",
        onValueChange = {},
        readOnly = true,
        label = { Text("Assign to Test Series") },
        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTestDropdownExpanded) },
        modifier = Modifier.fillMaxWidth().menuAnchor(),
        shape = RoundedCornerShape(10.dp)
      )
      ExposedDropdownMenu(
        expanded = isTestDropdownExpanded,
        onDismissRequest = { isTestDropdownExpanded = false }
      ) {
        tests.forEach { t ->
          DropdownMenuItem(
            text = { Text(t.title) },
            onClick = {
              selectedTestId = t.id
              isTestDropdownExpanded = false
            }
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      OutlinedTextField(
        value = subject,
        onValueChange = { subject = it },
        label = { Text("Subject") },
        modifier = Modifier.weight(1f),
        shape = RoundedCornerShape(10.dp)
      )
      OutlinedTextField(
        value = topic,
        onValueChange = { topic = it },
        label = { Text("Topic") },
        modifier = Modifier.weight(1f),
        shape = RoundedCornerShape(10.dp)
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      OutlinedTextField(
        value = source,
        onValueChange = { source = it },
        label = { Text("Source Attribution") },
        modifier = Modifier.weight(1.5f),
        shape = RoundedCornerShape(10.dp)
      )
      OutlinedTextField(
        value = year,
        onValueChange = { year = it },
        label = { Text("Year") },
        modifier = Modifier.weight(1f),
        shape = RoundedCornerShape(10.dp)
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    OutlinedTextField(
      value = questionText,
      onValueChange = { questionText = it },
      label = { Text("Question Statement (English)") },
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(10.dp),
      maxLines = 3
    )

    Spacer(modifier = Modifier.height(8.dp))

    OutlinedTextField(
      value = hindiQuestionText,
      onValueChange = { hindiQuestionText = it },
      label = { Text("Question Statement (हिंदी Optional)") },
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(10.dp),
      maxLines = 3
    )

    Spacer(modifier = Modifier.height(10.dp))

    OutlinedTextField(
      value = optionA,
      onValueChange = { optionA = it },
      label = { Text("Option A") },
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(10.dp)
    )

    Spacer(modifier = Modifier.height(6.dp))

    OutlinedTextField(
      value = optionB,
      onValueChange = { optionB = it },
      label = { Text("Option B") },
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(10.dp)
    )

    Spacer(modifier = Modifier.height(6.dp))

    OutlinedTextField(
      value = optionC,
      onValueChange = { optionC = it },
      label = { Text("Option C") },
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(10.dp)
    )

    Spacer(modifier = Modifier.height(6.dp))

    OutlinedTextField(
      value = optionD,
      onValueChange = { optionD = it },
      label = { Text("Option D") },
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(10.dp)
    )

    Spacer(modifier = Modifier.height(12.dp))

    Text("Correct Answer Option:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      listOf("Option A", "Option B", "Option C", "Option D").forEachIndexed { idx, label ->
        val isSelected = correctIndex == idx
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
            .clickable { correctIndex = idx }
            .padding(vertical = 10.dp)
        ) {
          Text(
            text = label.replace("Option ", ""),
            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    OutlinedTextField(
      value = explanation,
      onValueChange = { explanation = it },
      label = { Text("Step-by-Step Explanation & Method (English)") },
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(10.dp),
      maxLines = 4
    )

    Spacer(modifier = Modifier.height(18.dp))

    Button(
      onClick = {
        if (questionText.isBlank() || optionA.isBlank() || optionB.isBlank()) return@Button
        viewModel.addCustomQuestion(
          testId = selectedTestId,
          subject = subject,
          topic = topic,
          questionText = questionText,
          hindiQuestionText = hindiQuestionText,
          optA = optionA,
          optB = optionB,
          optC = optionC,
          optD = optionD,
          correctIndex = correctIndex,
          explanation = explanation,
          hindiExplanation = hindiExplanation,
          source = source,
          year = year,
          isVerified = isVerified
        ) {
          questionText = ""
          hindiQuestionText = ""
          optionA = ""
          optionB = ""
          optionC = ""
          optionD = ""
          explanation = ""
          onAdded()
        }
      },
      modifier = Modifier
        .fillMaxWidth()
        .height(48.dp)
        .testTag("admin_add_question_btn"),
      shape = RoundedCornerShape(10.dp)
    ) {
      Icon(imageVector = Icons.Default.PostAdd, contentDescription = null, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(6.dp))
      Text("Save to Question Bank", fontWeight = FontWeight.Bold)
    }

    Spacer(modifier = Modifier.height(40.dp))
  }
}

@Composable
private fun ManageContentTab(viewModel: MainViewModel) {
  val tests by viewModel.filteredTests.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    item {
      Text(
        text = "Test Series & Verification Tier",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = "Tap the Verified switch to reclassify between Official and Demo sets.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(6.dp))
    }

    items(tests, key = { it.id }) { test ->
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(text = test.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(
              text = "${test.category.displayName} • ${test.type.displayName} • ${test.tier.displayName}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            VerifiedBadge(isVerified = test.isVerified)
          }

          Spacer(modifier = Modifier.width(8.dp))

          Switch(
            checked = test.isVerified,
            onCheckedChange = {
              viewModel.toggleTestVerification(test.id)
            }
          )
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(40.dp))
    }
  }
}

@Composable
private fun ReviewQuestionsTab(viewModel: MainViewModel) {
  androidx.compose.runtime.LaunchedEffect(Unit) {
    viewModel.loadPendingReviewQuestions()
  }

  val pendingQuestions by viewModel.pendingReviewQuestions.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    item {
      Text(
        text = "AI-Generated & Unverified Questions",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = "Admin Review Queue: Verify curriculum alignment or reject flawed generations.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(4.dp))
    }

    if (pendingQuestions.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
          modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
        ) {
          Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text("Review Queue Clean", fontWeight = FontWeight.Bold)
            Text("All questions are currently verified or approved.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    } else {
      items(pendingQuestions, key = { it.id }) { q ->
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text("${q.subject} • ${q.topic}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
              com.example.ui.components.SourceLabelBadge(sourceLabel = q.sourceLabel)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(q.questionText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(6.dp))
            Text("Ans: Option ${('A' + q.correctOptionIndex)} | Exp: ${q.explanation}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Button(
                onClick = { viewModel.approveQuestion(q.id) },
                modifier = Modifier.weight(1f)
              ) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Approve / Verify", fontSize = 11.sp)
              }
              OutlinedButton(
                onClick = { viewModel.rejectOrDeleteQuestion(q.id) },
                modifier = Modifier.weight(1f)
              ) {
                Text("Reject / Delete", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
              }
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(40.dp))
    }
  }
}

@Composable
private fun SystemUsageTab(
  testsCount: Int,
  questionsCount: Int
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState())
  ) {
    Text(
      text = "Aggregate System Usage & Cost Controls",
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold
    )
    Text(
      text = "Real-time statistics of local database models, quota throttling and AI token usage.",
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Spacer(modifier = Modifier.height(16.dp))

    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        StatRow(label = "Total Published Tests", value = "$testsCount")
        StatRow(label = "Total Questions in Bank", value = "$questionsCount")
        StatRow(label = "Database Schema Version", value = "v3 (Non-destructive Migration)")
        StatRow(label = "AI Question Generator Model", value = "gemini-3.8-flash (JSON Mode)")
        StatRow(label = "Fallback Model", value = "gemini-3.5-flash-lite")
        StatRow(label = "Estimated Cost per 10-Q Batch", value = "₹0.04 - ₹0.08 (~$0.0006 USD)")
        StatRow(label = "Daily Batch Limit (Free)", value = "10 batches (100-200 Qs/day)")
        StatRow(label = "Daily Batch Limit (Plus)", value = "30 batches (300-600 Qs/day)")
        StatRow(label = "Daily Batch Limit (Pro)", value = "100 batches (1,000-2,000 Qs/day)")
        StatRow(label = "Deduplication Strategy", value = "SHA-256 Content Hash + DB Index")
        StatRow(label = "Offline Academic Generator", value = "Curriculum Algorithmic Model")
      }
    }
  }
}

@Composable
private fun StatRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(text = value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
  }
}
