package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.ExamSeekRepository
import com.example.domain.model.AppLanguage
import com.example.domain.model.QuestionStatus
import com.example.domain.model.TestItem
import com.example.domain.model.TestQuestion
import com.example.domain.model.TestResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ExamViewModel(application: Application) : AndroidViewModel(application) {

  private val repository = ExamSeekRepository(application)

  private val _currentTest = MutableStateFlow<TestItem?>(null)
  val currentTest: StateFlow<TestItem?> = _currentTest.asStateFlow()

  private val _questions = MutableStateFlow<List<TestQuestion>>(emptyList())
  val questions: StateFlow<List<TestQuestion>> = _questions.asStateFlow()

  private val _currentIndex = MutableStateFlow(0)
  val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

  // Map of questionId -> selectedOptionIndex (null if not answered)
  private val _userAnswers = MutableStateFlow<Map<String, Int?>>(emptyMap())
  val userAnswers: StateFlow<Map<String, Int?>> = _userAnswers.asStateFlow()

  // Set of questionId marked for review
  private val _markedForReview = MutableStateFlow<Set<String>>(emptySet())
  val markedForReview: StateFlow<Set<String>> = _markedForReview.asStateFlow()

  // Set of bookmarked question IDs
  private val _bookmarks = MutableStateFlow<Set<String>>(emptySet())
  val bookmarks: StateFlow<Set<String>> = _bookmarks.asStateFlow()

  // Negative marking setting
  private val _applyNegativeMarking = MutableStateFlow(true)
  val applyNegativeMarking: StateFlow<Boolean> = _applyNegativeMarking.asStateFlow()

  // Language setting for test session
  private val _examLanguage = MutableStateFlow(AppLanguage.ENGLISH)
  val examLanguage: StateFlow<AppLanguage> = _examLanguage.asStateFlow()

  // Timer
  private val _timeRemainingSeconds = MutableStateFlow(0)
  val timeRemainingSeconds: StateFlow<Int> = _timeRemainingSeconds.asStateFlow()

  private val _isTimerRunning = MutableStateFlow(false)
  val isTimerRunning: StateFlow<Boolean> = _isTimerRunning.asStateFlow()

  private val _isTimeUp = MutableStateFlow(false)
  val isTimeUp: StateFlow<Boolean> = _isTimeUp.asStateFlow()

  private var timerJob: Job? = null
  private var totalDurationSeconds = 0

  // Result after submission
  private val _testResult = MutableStateFlow<TestResult?>(null)
  val testResult: StateFlow<TestResult?> = _testResult.asStateFlow()

  private val _isSubmitting = MutableStateFlow(false)
  val isSubmitting: StateFlow<Boolean> = _isSubmitting.asStateFlow()

  fun startTest(
    test: TestItem,
    applyNegative: Boolean = test.isNegativeMarkingEnabled,
    customQuestions: List<TestQuestion>? = null
  ) {
    _currentTest.value = test
    _applyNegativeMarking.value = applyNegative
    _currentIndex.value = 0
    _userAnswers.value = emptyMap()
    _markedForReview.value = emptySet()
    _testResult.value = null
    _isTimeUp.value = false

    totalDurationSeconds = test.durationMinutes * 60
    _timeRemainingSeconds.value = totalDurationSeconds

    viewModelScope.launch {
      val loadedQuestions = customQuestions ?: repository.getQuestionsForTest(test.id)
      _questions.value = loadedQuestions

      // Check for saved in-progress session to restore safely
      val savedSession = repository.getActiveTestSession(test.id)
      if (savedSession != null) {
        _timeRemainingSeconds.value = savedSession.timeRemainingSeconds
        _currentIndex.value = savedSession.currentIndex
        _applyNegativeMarking.value = savedSession.applyNegativeMarking

        // Restore answers
        val restoredAnswers = mutableMapOf<String, Int?>()
        if (savedSession.answersSummary.isNotBlank()) {
          savedSession.answersSummary.split(",").forEach { part ->
            val kv = part.split(":")
            if (kv.size == 2) {
              val opt = kv[1].toIntOrNull()
              if (opt != null && opt >= 0) restoredAnswers[kv[0]] = opt
            }
          }
        }
        _userAnswers.value = restoredAnswers

        // Restore marked
        val restoredMarked = mutableSetOf<String>()
        if (savedSession.markedReviewSummary.isNotBlank()) {
          savedSession.markedReviewSummary.split(",").forEach {
            if (it.isNotBlank()) restoredMarked.add(it)
          }
        }
        _markedForReview.value = restoredMarked
      }

      // Refresh bookmarks
      val bms = mutableSetOf<String>()
      loadedQuestions.forEach { q ->
        if (repository.isBookmarked(q.id)) {
          bms.add(q.id)
        }
      }
      _bookmarks.value = bms

      startTimer()
    }
  }

  fun toggleExamLanguage() {
    _examLanguage.value = if (_examLanguage.value == AppLanguage.ENGLISH) AppLanguage.HINDI else AppLanguage.ENGLISH
  }

  fun setNegativeMarkingEnabled(enabled: Boolean) {
    _applyNegativeMarking.value = enabled
    persistSession()
  }

  private fun startTimer() {
    timerJob?.cancel()
    _isTimerRunning.value = true
    timerJob = viewModelScope.launch {
      while (_timeRemainingSeconds.value > 0 && _isTimerRunning.value) {
        delay(1000)
        _timeRemainingSeconds.value -= 1
        // Auto-save progress every 15 seconds
        if (_timeRemainingSeconds.value % 15 == 0) {
          persistSession()
        }
      }
      if (_timeRemainingSeconds.value <= 0) {
        _isTimeUp.value = true
        _isTimerRunning.value = false
        submitTest()
      }
    }
  }

  fun togglePauseTimer() {
    if (_isTimerRunning.value) {
      _isTimerRunning.value = false
      timerJob?.cancel()
      persistSession()
    } else {
      startTimer()
    }
  }

  fun selectOption(optionIndex: Int) {
    val currentQ = currentQuestion ?: return
    val currentMap = _userAnswers.value.toMutableMap()
    currentMap[currentQ.id] = optionIndex
    _userAnswers.value = currentMap
    persistSession()
  }

  fun clearResponse() {
    val currentQ = currentQuestion ?: return
    val currentMap = _userAnswers.value.toMutableMap()
    currentMap.remove(currentQ.id)
    _userAnswers.value = currentMap
    persistSession()
  }

  fun toggleMarkForReview() {
    val currentQ = currentQuestion ?: return
    val currentSet = _markedForReview.value.toMutableSet()
    if (currentSet.contains(currentQ.id)) {
      currentSet.remove(currentQ.id)
    } else {
      currentSet.add(currentQ.id)
    }
    _markedForReview.value = currentSet
    persistSession()
  }

  fun toggleBookmarkCurrentQuestion() {
    val currentQ = currentQuestion ?: return
    viewModelScope.launch {
      repository.toggleBookmark(currentQ.id)
      val currentSet = _bookmarks.value.toMutableSet()
      if (currentSet.contains(currentQ.id)) {
        currentSet.remove(currentQ.id)
      } else {
        currentSet.add(currentQ.id)
      }
      _bookmarks.value = currentSet
    }
  }

  fun nextQuestion() {
    if (_currentIndex.value < _questions.value.size - 1) {
      _currentIndex.value += 1
      persistSession()
    }
  }

  fun previousQuestion() {
    if (_currentIndex.value > 0) {
      _currentIndex.value -= 1
      persistSession()
    }
  }

  fun goToQuestion(index: Int) {
    if (index in 0 until _questions.value.size) {
      _currentIndex.value = index
      persistSession()
    }
  }

  val currentQuestion: TestQuestion?
    get() = _questions.value.getOrNull(_currentIndex.value)

  fun getQuestionStatus(questionId: String): QuestionStatus {
    val hasAnswer = _userAnswers.value[questionId] != null
    val isMarked = _markedForReview.value.contains(questionId)

    return when {
      hasAnswer && isMarked -> QuestionStatus.ANSWERED_AND_MARKED_FOR_REVIEW
      hasAnswer -> QuestionStatus.ANSWERED
      isMarked -> QuestionStatus.MARKED_FOR_REVIEW
      else -> QuestionStatus.NOT_ANSWERED
    }
  }

  private fun persistSession() {
    val test = _currentTest.value ?: return
    viewModelScope.launch {
      repository.saveActiveTestSession(
        testId = test.id,
        timeRemainingSeconds = _timeRemainingSeconds.value,
        currentIndex = _currentIndex.value,
        answers = _userAnswers.value,
        markedForReview = _markedForReview.value,
        applyNegativeMarking = _applyNegativeMarking.value
      )
    }
  }

  fun submitTest(onFinished: ((TestResult) -> Unit)? = null) {
    if (_isSubmitting.value) return
    _isSubmitting.value = true
    timerJob?.cancel()
    _isTimerRunning.value = false

    val test = _currentTest.value ?: return
    val questionsList = _questions.value
    val spent = totalDurationSeconds - _timeRemainingSeconds.value

    viewModelScope.launch {
      val result = repository.evaluateAndSubmitTest(
        test = test,
        questions = questionsList,
        answers = _userAnswers.value,
        timeSpentSeconds = spent,
        applyNegativeMarking = _applyNegativeMarking.value
      )
      _testResult.value = result
      _isSubmitting.value = false
      onFinished?.invoke(result)
    }
  }

  override fun onCleared() {
    super.onCleared()
    timerJob?.cancel()
  }
}
