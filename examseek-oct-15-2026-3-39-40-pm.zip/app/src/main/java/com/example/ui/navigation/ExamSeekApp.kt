package com.example.ui.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.domain.model.TestItem
import com.example.domain.model.TestQuestion
import com.example.ui.screens.admin.AdminPanelScreen
import com.example.ui.screens.admin.BackendArchitectureScreen
import com.example.ui.screens.ai.AiDoubtSolverScreen
import com.example.ui.screens.analytics.AnalyticsScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.auth.RegisterScreen
import com.example.ui.screens.bookmarks.BookmarksScreen
import com.example.ui.screens.exam.ExamResultScreen
import com.example.ui.screens.exam.ExamRunnerScreen
import com.example.ui.screens.exam.SolutionReviewScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.learning.DailyLearningScreen
import com.example.ui.screens.practice.PracticeScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.subscription.SubscriptionScreen
import com.example.ui.screens.tests.TestListScreen
import com.example.ui.screens.trust.TrustAndLegalScreen
import com.example.ui.viewmodel.ExamViewModel
import com.example.ui.viewmodel.MainViewModel

data class BottomNavItem(
  val route: String,
  val title: String,
  val icon: ImageVector
)

@Composable
fun ExamSeekApp(
  navController: NavHostController = rememberNavController(),
  mainViewModel: MainViewModel = viewModel(),
  examViewModel: ExamViewModel = viewModel()
) {
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route

  val bottomNavItems = listOf(
    BottomNavItem(Screen.Home.route, "Home", Icons.Default.Home),
    BottomNavItem(Screen.Tests.route, "Tests", Icons.AutoMirrored.Filled.Assignment),
    BottomNavItem(Screen.DailyLearning.route, "Learning", Icons.Default.Newspaper),
    BottomNavItem(Screen.Analytics.route, "Analytics", Icons.Default.Analytics),
    BottomNavItem(Screen.Profile.route, "Profile", Icons.Default.Person)
  )

  // Show bottom bar only on primary tabs
  val showBottomBar = currentRoute in bottomNavItems.map { it.route }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    bottomBar = {
      AnimatedVisibility(
        visible = showBottomBar,
        enter = fadeIn(),
        exit = fadeOut()
      ) {
        NavigationBar(modifier = Modifier.testTag("bottom_nav_bar")) {
          bottomNavItems.forEach { item ->
            val isSelected = currentRoute == item.route
            NavigationBarItem(
              selected = isSelected,
              onClick = {
                navController.navigate(item.route) {
                  popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                  }
                  launchSingleTop = true
                  restoreState = true
                }
              },
              icon = {
                Icon(imageVector = item.icon, contentDescription = item.title)
              },
              label = {
                Text(item.title)
              },
              modifier = Modifier.testTag("nav_item_${item.route}")
            )
          }
        }
      }
    }
  ) { innerPadding ->
    NavHost(
      navController = navController,
      startDestination = Screen.Home.route,
      modifier = Modifier.padding(innerPadding)
    ) {
      // 1. Home Screen (Student Dashboard)
      composable(Screen.Home.route) {
        HomeScreen(
          viewModel = mainViewModel,
          onStartTest = { test: TestItem ->
            examViewModel.startTest(test)
            navController.navigate(Screen.ExamRunner.createRoute(test.id))
          },
          onNavigateToPractice = {
            navController.navigate(Screen.Practice.route)
          },
          onNavigateToDailyLearning = {
            navController.navigate(Screen.DailyLearning.route)
          },
          onNavigateToAiSolver = {
            navController.navigate(Screen.AiDoubtSolver.route)
          },
          onNavigateToExamGenerator = {
            navController.navigate(Screen.ExamGenerator.route)
          }
        )
      }

      // 2. Tests Catalog Screen
      composable(Screen.Tests.route) {
        TestListScreen(
          viewModel = mainViewModel,
          onStartTest = { test: TestItem ->
            examViewModel.startTest(test)
            navController.navigate(Screen.ExamRunner.createRoute(test.id))
          }
        )
      }

      // 3. Daily Learning Screen (Current Affairs, Mistake Vault, Formulas)
      composable(Screen.DailyLearning.route) {
        DailyLearningScreen(
          viewModel = mainViewModel,
          onNavigateToAiSolver = { navController.navigate(Screen.AiDoubtSolver.route) },
          onNavigateToFormulaDetail = { topicId ->
            navController.navigate(Screen.FormulaDetail.createRoute(topicId))
          }
        )
      }

      // 4. Practice Drills Screen
      composable(Screen.Practice.route) {
        PracticeScreen(
          viewModel = mainViewModel,
          onNavigateToExamGenerator = {
            navController.navigate(Screen.ExamGenerator.route)
          }
        )
      }

      // 5. Analytics & Test History Screen
      composable(Screen.Analytics.route) {
        AnalyticsScreen(
          viewModel = mainViewModel,
          onReviewAttempt = { attempt ->
            val test = mainViewModel.filteredTests.value.find { it.id == attempt.testId }
              ?: mainViewModel.filteredTests.value.firstOrNull()
            if (test != null) {
              examViewModel.startTest(test)
              navController.navigate(Screen.SolutionReview.route)
            }
          }
        )
      }

      // 6. Profile Screen
      composable(Screen.Profile.route) {
        ProfileScreen(
          viewModel = mainViewModel,
          onNavigateToBookmarks = { navController.navigate(Screen.Bookmarks.route) },
          onNavigateToDailyLearning = { navController.navigate(Screen.DailyLearning.route) },
          onNavigateToAiSolver = { navController.navigate(Screen.AiDoubtSolver.route) },
          onNavigateToSubscription = { navController.navigate(Screen.Subscription.route) },
          onNavigateToTrustLegal = { navController.navigate(Screen.TrustAndLegal.route) },
          onNavigateToAdmin = { navController.navigate(Screen.AdminPanel.route) },
          onNavigateToBackendPlan = { navController.navigate(Screen.BackendPlan.route) },
          onNavigateToLogin = { navController.navigate(Screen.Login.route) }
        )
      }

      // 7. CBT Exam Runner Screen
      composable(Screen.ExamRunner.route) {
        ExamRunnerScreen(
          viewModel = examViewModel,
          onFinishTest = {
            mainViewModel.checkForActiveSession()
            navController.navigate(Screen.ExamResult.route) {
              popUpTo(Screen.Home.route)
            }
          },
          onExit = {
            mainViewModel.checkForActiveSession()
            navController.popBackStack()
          }
        )
      }

      // 8. Exam Result Screen
      composable(Screen.ExamResult.route) {
        ExamResultScreen(
          viewModel = examViewModel,
          onReviewSolutions = {
            navController.navigate(Screen.SolutionReview.route)
          },
          onReattempt = {
            examViewModel.currentTest.value?.let { test ->
              examViewModel.startTest(test)
              navController.navigate(Screen.ExamRunner.createRoute(test.id)) {
                popUpTo(Screen.Home.route)
              }
            }
          },
          onBackToHome = {
            navController.navigate(Screen.Home.route) {
              popUpTo(Screen.Home.route) { inclusive = true }
            }
          }
        )
      }

      // 9. Detailed Solution Review Screen
      composable(Screen.SolutionReview.route) {
        SolutionReviewScreen(
          examViewModel = examViewModel,
          mainViewModel = mainViewModel,
          onNavigateToAiSolver = { q: TestQuestion ->
            mainViewModel.setSelectedQuestionForAi(q)
            navController.navigate(Screen.AiDoubtSolver.route)
          },
          onBack = { navController.popBackStack() }
        )
      }

      // 10. AI Doubt Solver Screen
      composable(Screen.AiDoubtSolver.route) {
        AiDoubtSolverScreen(
          viewModel = mainViewModel,
          onNavigateToSubscription = { navController.navigate(Screen.Subscription.route) },
          onBack = { navController.popBackStack() }
        )
      }

      // 11. Subscription & Paywall Screen
      composable(Screen.Subscription.route) {
        SubscriptionScreen(
          viewModel = mainViewModel,
          onNavigateToTrustLegal = { navController.navigate(Screen.TrustAndLegal.route) },
          onBack = { navController.popBackStack() }
        )
      }

      // 12. Trust, Policies & Support Screen
      composable(Screen.TrustAndLegal.route) {
        TrustAndLegalScreen(
          onBack = { navController.popBackStack() }
        )
      }

      // 13. Bookmarks Screen
      composable(Screen.Bookmarks.route) {
        BookmarksScreen(
          viewModel = mainViewModel,
          onBack = { navController.popBackStack() }
        )
      }

      // 14. Login Screen
      composable(Screen.Login.route) {
        LoginScreen(
          viewModel = mainViewModel,
          onLoginSuccess = { navController.popBackStack() },
          onNavigateToRegister = { navController.navigate(Screen.Register.route) },
          onBack = { navController.popBackStack() }
        )
      }

      // 15. Register Screen
      composable(Screen.Register.route) {
        RegisterScreen(
          viewModel = mainViewModel,
          onRegisterSuccess = { navController.popBackStack() },
          onNavigateToLogin = { navController.popBackStack() },
          onBack = { navController.popBackStack() }
        )
      }

      // 16. Admin Panel Screen
      composable(Screen.AdminPanel.route) {
        AdminPanelScreen(
          viewModel = mainViewModel,
          onBack = { navController.popBackStack() }
        )
      }

      // 17. Backend Architecture Screen
      composable(Screen.BackendPlan.route) {
        BackendArchitectureScreen(
          onBack = { navController.popBackStack() }
        )
      }

      // 18. Exam Selection & Unlimited Question Generator Screen
      composable(Screen.ExamGenerator.route) {
        com.example.ui.screens.exam.ExamSelectionGeneratorScreen(
          viewModel = mainViewModel,
          onStartCustomMock = { testItem, questions ->
            examViewModel.startTest(
              test = testItem,
              applyNegative = testItem.isNegativeMarkingEnabled,
              customQuestions = questions
            )
            navController.navigate(Screen.ExamRunner.createRoute(testItem.id))
          },
          onBack = { navController.popBackStack() }
        )
      }

      // 19. Formula Topic Detail Screen
      composable(Screen.FormulaDetail.route) { backStackEntry ->
        val topicId = backStackEntry.arguments?.getString("topicId") ?: ""
        com.example.ui.screens.learning.FormulaTopicDetailScreen(
          topicId = topicId,
          formulaRepository = mainViewModel.formulaRepository,
          onNavigateBack = { navController.popBackStack() }
        )
      }
    }
  }
}
