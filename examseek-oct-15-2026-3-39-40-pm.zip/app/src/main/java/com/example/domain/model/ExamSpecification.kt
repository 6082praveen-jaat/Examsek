package com.example.domain.model

data class ExamDetail(
  val id: String,
  val name: String,
  val category: ExamCategory,
  val stages: List<String>,
  val subjects: List<String>,
  val topicsBySubject: Map<String, List<String>>,
  val defaultDurationMinutes: Int = 60,
  val defaultMarksPerQuestion: Float = 2.0f,
  val defaultNegativeMarking: Float = 0.5f,
  val verifiedMarkingScheme: Boolean = true,
  val syllabusOverview: String
)

object ExamRegistry {

  val allExams: List<ExamDetail> = listOf(
    // 1. SSC CGL
    ExamDetail(
      id = "ssc_cgl",
      name = "SSC CGL",
      category = ExamCategory.SSC,
      stages = listOf("Tier-1 (Preliminary CBT)", "Tier-2 (Paper-I Mains)"),
      subjects = listOf("Quantitative Aptitude", "Quantitative Aptitude (Maths)", "Logical Reasoning", "General Awareness", "English Comprehension"),
      topicsBySubject = mapOf(
        "Quantitative Aptitude" to listOf("Percentages", "Profit & Loss", "Time & Work", "Ratio & Proportion", "Algebra & Identities", "Geometry & Mensuration", "Trigonometry", "Speed & Distance"),
        "Quantitative Aptitude (Maths)" to listOf("Percentages", "Profit & Loss", "Time & Work", "Ratio & Proportion", "Algebra & Identities", "Geometry & Mensuration", "Trigonometry", "Speed & Distance"),
        "Logical Reasoning" to listOf("Analogy", "Syllogisms", "Series & Number Patterns", "Coding-Decoding", "Blood Relations", "Direction Sense", "Venn Diagrams"),
        "General Awareness" to listOf("Indian Polity & Constitution", "Modern Indian History", "Indian Geography", "General Science (Physics/Chemistry/Bio)", "Economy & Five Year Plans", "Current Affairs (National/Awards)"),
        "English Comprehension" to listOf("Spotting Errors", "Synonyms & Antonyms", "One Word Substitution", "Idioms & Phrases", "Sentence Improvement", "Reading Comprehension")
      ),
      defaultDurationMinutes = 60,
      defaultMarksPerQuestion = 2.0f,
      defaultNegativeMarking = 0.5f,
      verifiedMarkingScheme = true,
      syllabusOverview = "Staff Selection Commission Combined Graduate Level Examination covering Maths, Reasoning, GA, and English."
    ),

    // 2. SSC CHSL
    ExamDetail(
      id = "ssc_chsl",
      name = "SSC CHSL",
      category = ExamCategory.SSC,
      stages = listOf("Tier-1 (10+2 Level CBT)", "Tier-2 (Skill Test & Mains)"),
      subjects = listOf("Quantitative Aptitude", "General Intelligence", "General Awareness", "English Language"),
      topicsBySubject = mapOf(
        "Quantitative Aptitude" to listOf("Arithmetic Basics", "Simple & Compound Interest", "Algebra", "Mensuration 2D/3D", "Data Interpretation"),
        "General Intelligence" to listOf("Symbolic Operations", "Figural Analogy", "Number Series", "Critical Thinking"),
        "General Awareness" to listOf("History & Culture", "Geography", "Economic Scene", "General Policy & Scientific Research"),
        "English Language" to listOf("Grammar Rules", "Cloze Test", "Active/Passive Voice", "Direct/Indirect Speech")
      ),
      defaultDurationMinutes = 60,
      defaultMarksPerQuestion = 2.0f,
      defaultNegativeMarking = 0.5f,
      verifiedMarkingScheme = true,
      syllabusOverview = "Combined Higher Secondary Level examination for Postal Assistants, LDC, and Data Entry Operators."
    ),

    // 3. SSC MTS
    ExamDetail(
      id = "ssc_mts",
      name = "SSC MTS",
      category = ExamCategory.SSC,
      stages = listOf("Session-1 (Maths & Reasoning)", "Session-2 (GA & English)"),
      subjects = listOf("Numerical & Mathematical Ability", "Reasoning Ability", "General Awareness", "English Language"),
      topicsBySubject = mapOf(
        "Numerical & Mathematical Ability" to listOf("LCM & HCF", "Decimals & Fractions", "Averages", "Work & Time", "Profit & Loss"),
        "Reasoning Ability" to listOf("Alpha-Numeric Series", "Coding & Decoding", "Following Directions", "Similarities & Differences"),
        "General Awareness" to listOf("Art & Culture", "Civics", "Environmental Studies", "Sports & Honours"),
        "English Language" to listOf("Basic Grammar", "Vocabulary", "Sentence Structure", "Synonyms/Antonyms")
      ),
      defaultDurationMinutes = 45,
      defaultMarksPerQuestion = 3.0f,
      defaultNegativeMarking = 1.0f,
      verifiedMarkingScheme = true,
      syllabusOverview = "Multi-Tasking (Non-Technical) Staff and Havaldar recruitment exam."
    ),

    // 4. SSC GD Constable
    ExamDetail(
      id = "ssc_gd",
      name = "SSC GD Constable",
      category = ExamCategory.SSC,
      stages = listOf("Computer Based Exam (CBE)"),
      subjects = listOf("Elementary Mathematics", "General Intelligence & Reasoning", "General Knowledge & GA", "English / Hindi"),
      topicsBySubject = mapOf(
        "Elementary Mathematics" to listOf("Number Systems", "Percentages", "Ratio & Proportion", "Averages", "Time & Distance", "Mensuration"),
        "General Intelligence & Reasoning" to listOf("Spatial Visualization", "Spatial Orientation", "Visual Memory", "Relationship Concepts"),
        "General Knowledge & GA" to listOf("Sports", "History", "Culture", "Geography", "Indian Constitution"),
        "English / Hindi" to listOf("Basic Comprehension", "Grammar Usage", "Error Recognition", "Fill in the Blanks")
      ),
      defaultDurationMinutes = 60,
      defaultMarksPerQuestion = 2.0f,
      defaultNegativeMarking = 0.5f,
      verifiedMarkingScheme = true,
      syllabusOverview = "Constable (GD) in Central Armed Police Forces (CAPFs), SSF, Rifleman (GD) in Assam Rifles."
    ),

    // 5. Railway RRB NTPC
    ExamDetail(
      id = "rrb_ntpc",
      name = "RRB NTPC",
      category = ExamCategory.RAILWAY,
      stages = listOf("CBT Stage-1 (Screening)", "CBT Stage-2 (Mains)"),
      subjects = listOf("Mathematics", "General Intelligence & Reasoning", "General Awareness"),
      topicsBySubject = mapOf(
        "Mathematics" to listOf("Number System", "Decimals", "Fractions", "Simple & Compound Interest", "Profit & Loss", "Time & Work", "Elementary Statistics"),
        "General Intelligence & Reasoning" to listOf("Analogies", "Completion of Number & Alphabetical Series", "Coding & Decoding", "Mathematical Operations", "Syllogisms", "Jumbling"),
        "General Awareness" to listOf("Current Events of National & International Importance", "Games & Sports", "Art & Culture of India", "Indian Literature", "Monuments & Places of India", "General Science (up to 10th CBSE)")
      ),
      defaultDurationMinutes = 90,
      defaultMarksPerQuestion = 1.0f,
      defaultNegativeMarking = 0.33f,
      verifiedMarkingScheme = true,
      syllabusOverview = "Railway Recruitment Board Non-Technical Popular Categories Graduate and Undergraduate posts."
    ),

    // 6. Railway RRB Group D
    ExamDetail(
      id = "rrb_group_d",
      name = "Railway RRB Group D",
      category = ExamCategory.RAILWAY,
      stages = listOf("Computer Based Test (CBT)"),
      subjects = listOf("General Science", "Mathematics", "General Intelligence & Reasoning", "General Awareness & Current Affairs"),
      topicsBySubject = mapOf(
        "General Science" to listOf("Physics (Mechanics, Electricity, Optics)", "Chemistry (Periodic Table, Acids/Bases, Reactions)", "Life Sciences (Biology, Human Anatomy, Botany)"),
        "Mathematics" to listOf("BODMAS", "Decimals", "Fractions", "Square Roots", "Age Calculations", "Pipes & Cistern"),
        "General Intelligence & Reasoning" to listOf("Analogies", "Venn Diagrams", "Data Interpretation & Sufficiency", "Statement & Arguments"),
        "General Awareness & Current Affairs" to listOf("Science & Technology", "Sports & Personalities", "Economics & Politics")
      ),
      defaultDurationMinutes = 90,
      defaultMarksPerQuestion = 1.0f,
      defaultNegativeMarking = 0.33f,
      verifiedMarkingScheme = true,
      syllabusOverview = "Track Maintainer Grade IV, Helper/Assistant in various technical departments."
    ),

    // 7. Railway RRB ALP
    ExamDetail(
      id = "rrb_alp",
      name = "Railway RRB ALP & Technician",
      category = ExamCategory.RAILWAY,
      stages = listOf("First Stage CBT", "Second Stage CBT (Part A & B)"),
      subjects = listOf("Mathematics", "General Intelligence & Reasoning", "General Science", "Basic Science & Engineering"),
      topicsBySubject = mapOf(
        "Mathematics" to listOf("Number System", "BODMAS", "Algebra", "Geometry & Trigonometry", "Statistics"),
        "General Intelligence & Reasoning" to listOf("Analogies", "Classification", "Direction Test", "Analytical Reasoning"),
        "Basic Science & Engineering" to listOf("Engineering Drawing", "Units & Measurements", "Mass, Weight & Density", "Work, Power & Energy", "Speed & Velocity", "Heat & Temperature", "Basic Electricity"),
        "General Science" to listOf("Physics", "Chemistry", "Biology up to 10th standard")
      ),
      defaultDurationMinutes = 60,
      defaultMarksPerQuestion = 1.0f,
      defaultNegativeMarking = 0.33f,
      verifiedMarkingScheme = true,
      syllabusOverview = "Assistant Loco Pilot and Technician Grade posts in Indian Railways."
    ),

    // 8. UPSC Civil Services Prelims
    ExamDetail(
      id = "upsc_prelims",
      name = "UPSC Civil Services Prelims",
      category = ExamCategory.UPSC,
      stages = listOf("General Studies Paper-I", "CSAT Paper-II (Aptitude)"),
      subjects = listOf("Polity & Governance", "History of India & INM", "Geography", "Economic & Social Development", "Environment & Ecology", "General Science", "Current Events"),
      topicsBySubject = mapOf(
        "Polity & Governance" to listOf("Constitution & Preamble", "Fundamental Rights & DPSP", "Parliament & Judiciary", "Constitutional & Non-Constitutional Bodies", "Panchayati Raj"),
        "History of India & INM" to listOf("Ancient India & Indus Valley", "Medieval India & Bhakti Movement", "Modern History & Freedom Struggle 1857-1947", "Art & Architecture"),
        "Geography" to listOf("Physical Geography of India & World", "River Systems & Drainage", "Climate & Monsoons", "Agriculture & Minerals"),
        "Economic & Social Development" to listOf("Sustainable Development & Poverty", "Monetary Policy & Inflation", "Fiscal Policy & Budget", "External Sector & WTO"),
        "Environment & Ecology" to listOf("Biodiversity & Conservation", "Climate Change & Conventions", "National Parks & Wildlife Sanctuaries", "Pollution & Environmental Laws")
      ),
      defaultDurationMinutes = 120,
      defaultMarksPerQuestion = 2.0f,
      defaultNegativeMarking = 0.66f,
      verifiedMarkingScheme = true,
      syllabusOverview = "Union Public Service Commission Civil Services Examination preliminary screening."
    ),

    // 9. Banking (IBPS PO & SBI PO)
    ExamDetail(
      id = "banking_po",
      name = "Banking (IBPS PO / SBI PO)",
      category = ExamCategory.BANKING,
      stages = listOf("Prelims Examination", "Mains Examination"),
      subjects = listOf("Quantitative Aptitude", "Reasoning Ability", "English Language", "General & Banking Awareness"),
      topicsBySubject = mapOf(
        "Quantitative Aptitude" to listOf("Data Interpretation (Charts/Tables)", "Quadratic Equations", "Number Series (Missing/Wrong)", "Arithmetic Word Problems", "Data Sufficiency"),
        "Reasoning Ability" to listOf("Seating Arrangements (Circular/Linear)", "Floor & Box Puzzles", "Syllogisms (Only a few cases)", "Inequalities", "Input-Output"),
        "English Language" to listOf("Reading Comprehension", "Para Jumbles", "Error Spotting", "Fillers & Sentence Connectors"),
        "General & Banking Awareness" to listOf("Banking Terminologies & RBI Circulars", "Monetary Policy Rates", "Financial Current Affairs", "Government Schemes (Financial)")
      ),
      defaultDurationMinutes = 60,
      defaultMarksPerQuestion = 1.0f,
      defaultNegativeMarking = 0.25f,
      verifiedMarkingScheme = true,
      syllabusOverview = "Probationary Officer recruitments across Public Sector Banks and SBI."
    ),

    // 10. State PCS
    ExamDetail(
      id = "state_pcs",
      name = "State PCS (UPPSC / BPSC / MPPSC / RAS)",
      category = ExamCategory.STATE_PCS,
      stages = listOf("Prelims Paper-1 (General Studies)", "Prelims Paper-2 (CSAT / Aptitude)"),
      subjects = listOf("General Science & Tech", "History of India & State History", "Geography of India & State", "Indian Polity & Economy", "State Special GK & Current Affairs"),
      topicsBySubject = mapOf(
        "History of India & State History" to listOf("Ancient & Medieval India", "Indian National Movement", "State Specific Freedom Fighters & Culture"),
        "Geography of India & State" to listOf("Physical Geography", "Rivers, Lakes & Dams of the State", "Climate, Soils & Agriculture"),
        "Indian Polity & Economy" to listOf("Constitutional Framework", "State Governance & Assembly", "State Budget & Economic Surveys"),
        "General Science & Tech" to listOf("Applied Physics & Chemistry", "Biology & Public Health", "Science in Everyday Life"),
        "State Special GK & Current Affairs" to listOf("State Government Welfare Schemes", "Festivals, Folk Arts & Heritage", "State Specific Census & Demographics")
      ),
      defaultDurationMinutes = 120,
      defaultMarksPerQuestion = 1.33f,
      defaultNegativeMarking = 0.44f,
      verifiedMarkingScheme = false, // Varies by state commission (clearly marked)
      syllabusOverview = "State Administrative and Police Services examinations conducted by State Public Service Commissions."
    ),

    // 11. Police Services
    ExamDetail(
      id = "police_si",
      name = "Police (UP Police SI / Delhi Police / Bihar SI)",
      category = ExamCategory.POLICE,
      stages = listOf("Written Examination (CBT/OMR)"),
      subjects = listOf("General Hindi / English", "Law & Constitution (Mool Vidhi)", "General Knowledge", "Numerical & Mental Ability", "Mental Aptitude & Reasoning"),
      topicsBySubject = mapOf(
        "Law & Constitution (Mool Vidhi)" to listOf("Indian Penal Code (IPC/BNS) Basics", "Criminal Procedure (CrPC/BNSS)", "Motor Vehicle Act & Human Rights", "Fundamental Rights & Police Power"),
        "General Knowledge" to listOf("General Science", "History & Culture", "Internal Security & Terrorism", "Cyber Crime & IT Act"),
        "Numerical & Mental Ability" to listOf("Arithmetic Word Problems", "Percentages & Profit-Loss", "Speed, Distance & Time", "Data Interpretation"),
        "Mental Aptitude & Reasoning" to listOf("Public Interest & Law Order", "Rule of Law", "Crime Control", "Logical & Non-Verbal Reasoning")
      ),
      defaultDurationMinutes = 120,
      defaultMarksPerQuestion = 2.5f,
      defaultNegativeMarking = 0.0f, // Many state police exams have no negative marking or 0.25 (clearly marked)
      verifiedMarkingScheme = false,
      syllabusOverview = "Sub-Inspector and Constable cadre selections in state and central police organisations."
    ),

    // 12. Teaching
    ExamDetail(
      id = "teaching_tet",
      name = "Teaching (CTET / State TET / KVS / Super TET)",
      category = ExamCategory.TEACHING,
      stages = listOf("Paper-1 (Classes I to V)", "Paper-2 (Classes VI to VIII)"),
      subjects = listOf("Child Development & Pedagogy (CDP)", "Mathematics & Pedagogy", "Environmental Studies (EVS)", "Language-I (Hindi/English)", "Language-II"),
      topicsBySubject = mapOf(
        "Child Development & Pedagogy (CDP)" to listOf("Concept of Development & Learning", "Piaget, Kohlberg & Vygotsky Theories", "Concept of Child-Centered & Progressive Education", "Inclusive Education & Addressing Diverse Learners", "NEP 2020 Pedagogical Framework"),
        "Environmental Studies (EVS)" to listOf("Family and Friends", "Food & Nutrition", "Shelter & Water", "Travel & Things We Make and Do", "EVS Pedagogical Issues"),
        "Mathematics & Pedagogy" to listOf("Numbers & Geometry", "Measurement & Weight", "Time & Money", "Nature of Mathematics & Diagnostic Teaching"),
        "Language-I (Hindi/English)" to listOf("Unseen Prose & Poetry", "Principles of Language Teaching", "Role of Listening & Speaking", "Remedial Teaching")
      ),
      defaultDurationMinutes = 150,
      defaultMarksPerQuestion = 1.0f,
      defaultNegativeMarking = 0.0f,
      verifiedMarkingScheme = true,
      syllabusOverview = "Central and State Teacher Eligibility Tests for primary and upper-primary educators."
    ),

    // 13. Defence
    ExamDetail(
      id = "defence_nda_cds",
      name = "Defence (NDA / CDS / AFCAT)",
      category = ExamCategory.DEFENCE,
      stages = listOf("Written Examination"),
      subjects = listOf("Mathematics (10+2 / Graduation)", "English Language", "General Knowledge & General Science", "Military & Defence Awareness"),
      topicsBySubject = mapOf(
        "Mathematics (10+2 / Graduation)" to listOf("Algebra & Matrices", "Trigonometry & Calculus", "Vector Algebra & Analytical Geometry", "Statistics & Probability"),
        "English Language" to listOf("Comprehension", "Ordering of Words/Sentences", "Idioms & Phrases", "Synonyms & Antonyms"),
        "General Knowledge & General Science" to listOf("Physics & Chemistry Basics", "General Science & Biology", "Indian History & Freedom Struggle", "Indian Geography"),
        "Military & Defence Awareness" to listOf("Armed Forces Ranks & Commands", "Defence Missiles & Equipment", "Joint Military Exercises", "National Security Strategy")
      ),
      defaultDurationMinutes = 120,
      defaultMarksPerQuestion = 2.5f,
      defaultNegativeMarking = 0.83f,
      verifiedMarkingScheme = true,
      syllabusOverview = "National Defence Academy and Combined Defence Services officer recruitment examinations."
    )
  )

  fun findExam(idOrName: String): ExamDetail? {
    return allExams.find {
      it.id.equals(idOrName, ignoreCase = true) ||
        it.name.equals(idOrName, ignoreCase = true) ||
        it.name.contains(idOrName, ignoreCase = true) ||
        idOrName.contains(it.name, ignoreCase = true) ||
        (idOrName.contains("ntpc", ignoreCase = true) && it.id == "rrb_ntpc") ||
        (idOrName.contains("upsc", ignoreCase = true) && it.id == "upsc_prelims")
    } ?: allExams.firstOrNull()
  }

  fun getExamById(id: String): ExamDetail? {
    return allExams.find {
      it.id.equals(id, ignoreCase = true) ||
        (id == "upsc_cse" && it.id == "upsc_prelims")
    }
  }
}
