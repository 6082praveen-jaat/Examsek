package com.example.ui.screens.exam

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.TestResult
import com.example.ui.viewmodel.ExamViewModel
import java.util.Locale

@Composable
fun ExamResultScreen(
  viewModel: ExamViewModel,
  onReviewSolutions: () -> Unit,
  onReattempt: () -> Unit,
  onBackToHome: () -> Unit
) {
  val testResult by viewModel.testResult.collectAsState()

  if (testResult == null) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Text("No recent test result available.")
    }
    return
  }

  val res = testResult!!

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .verticalScroll(rememberScrollState())
      .testTag("exam_result_screen")
  ) {
    // 1. Result Header Hero Card
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .background(
          Brush.verticalGradient(
            colors = listOf(
              MaterialTheme.colorScheme.primary,
              Color(0xFF1E3A8A),
              Color(0xFF0F172A)
            )
          )
        )
        .padding(24.dp)
    ) {
      Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(Color(0x33FFFFFF))
        ) {
          Icon(
            imageVector = Icons.Default.EmojiEvents,
            contentDescription = null,
            tint = Color(0xFFFBBF24),
            modifier = Modifier.size(36.dp)
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = "Test Completed!",
          color = Color.White,
          style = MaterialTheme.typography.headlineSmall,
          fontWeight = FontWeight.ExtraBold
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = res.testTitle,
          color = Color(0xFFCBD5E1),
          fontSize = 13.sp,
          fontWeight = FontWeight.Medium
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Main Score Counter Card
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0x22FFFFFF)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = String.format(Locale.US, "%.1f", res.marksObtained),
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold
              )
              Text(
                text = "Score / ${res.totalMarks.toInt()}",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp
              )
            }

            Box(
              modifier = Modifier
                .width(1.dp)
                .height(40.dp)
                .background(Color(0x33FFFFFF))
            )

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = String.format(Locale.US, "%.1f%%", res.accuracyPercentage),
                color = Color(0xFF86EFAC),
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold
              )
              Text(
                text = "Accuracy",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp
              )
            }

            Box(
              modifier = Modifier
                .width(1.dp)
                .height(40.dp)
                .background(Color(0x33FFFFFF))
            )

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = String.format(Locale.US, "%.1f", res.percentileEstimate),
                color = Color(0xFFFDE047),
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold
              )
              Text(
                text = "Est. Percentile",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp
              )
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // 2. Question Performance Breakdown
    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
      Text(
        text = "Performance Breakdown",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        BreakdownCard(
          label = "Correct",
          count = res.correctAnswersCount,
          color = Color(0xFF10B981),
          icon = Icons.Default.CheckCircle,
          modifier = Modifier.weight(1f)
        )
        BreakdownCard(
          label = "Incorrect",
          count = res.incorrectAnswersCount,
          color = Color(0xFFEF4444),
          icon = Icons.Default.Close,
          modifier = Modifier.weight(1f)
        )
        BreakdownCard(
          label = "Skipped",
          count = res.unattemptedCount,
          color = Color(0xFF64748B),
          icon = Icons.Default.HelpOutline,
          modifier = Modifier.weight(1f)
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      // 3. Negative Marking & Time Metrics Card
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Scoring & Timing Details",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )

          Spacer(modifier = Modifier.height(10.dp))

          MetricRow(
            label = "Time Taken:",
            value = "${res.timeSpentSeconds / 60}m ${res.timeSpentSeconds % 60}s of ${res.totalTimeSeconds / 60}m"
          )
          MetricRow(
            label = "Average Speed:",
            value = if (res.totalQuestions > 0) "${res.timeSpentSeconds / res.totalQuestions} sec/question" else "N/A"
          )
          MetricRow(
            label = "Negative Deduction:",
            value = if (res.negativeMarkingApplied) "-${String.format(Locale.US, "%.2f", res.negativeMarksDeducted)} Marks" else "Disabled (0.00)"
          )
          MetricRow(
            label = "Marks Formula:",
            value = "(${res.correctAnswersCount} × 2.0) - (${res.incorrectAnswersCount} × ${if (res.negativeMarkingApplied) "Neg" else "0"})"
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Topic-Wise Performance & Revision Recommendation
      val topicGroups = res.questions.groupBy { it.topic.ifBlank { it.subject } }
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Topic-Wise Analysis & Revision",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "${topicGroups.size} Topics",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.Bold
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          topicGroups.forEach { (topicName, qList) ->
            val totalInTopic = qList.size
            val correctInTopic = qList.count { res.userAnswers[it.id] == it.correctOptionIndex }
            val accuracy = if (totalInTopic > 0) (correctInTopic.toFloat() / totalInTopic) else 0f
            val needsRevision = accuracy < 0.65f

            Column(modifier = Modifier.padding(vertical = 6.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = topicName,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.SemiBold
                )
                Text(
                  text = "$correctInTopic/$totalInTopic (${(accuracy * 100).toInt()}%)",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (needsRevision) Color(0xFFD97706) else Color(0xFF059669)
                )
              }

              Spacer(modifier = Modifier.height(4.dp))

              androidx.compose.material3.LinearProgressIndicator(
                progress = { accuracy },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(5.dp)
                  .clip(RoundedCornerShape(3.dp)),
                color = if (needsRevision) Color(0xFFD97706) else Color(0xFF059669),
                trackColor = MaterialTheme.colorScheme.surfaceVariant
              )

              if (needsRevision) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = "⚠️ Priority Revision: Review concepts & short-tricks in Mistake Vault",
                  fontSize = 10.sp,
                  color = Color(0xFFB45309),
                  fontWeight = FontWeight.Medium
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Reliable Comparison Data Disclosure
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.HelpOutline,
            contentDescription = null,
            tint = Color(0xFF64748B),
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Percentile Disclosure: Estimated against standard academic benchmarks. Official percentile & All-India Rank sync after the live national test window concludes.",
            fontSize = 10.sp,
            color = Color(0xFF475569),
            lineHeight = 14.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // 4. Action Buttons
      Button(
        onClick = onReviewSolutions,
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("view_solutions_button"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
      ) {
        Icon(imageVector = Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text("View Detailed Solutions & Explanations", fontWeight = FontWeight.Bold)
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedButton(
          onClick = onReattempt,
          modifier = Modifier
            .weight(1f)
            .height(46.dp)
            .testTag("reattempt_button"),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Re-attempt")
        }

        OutlinedButton(
          onClick = onBackToHome,
          modifier = Modifier
            .weight(1f)
            .height(46.dp)
            .testTag("back_to_home_button"),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text("Back to Home")
        }
      }

      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}

@Composable
private fun BreakdownCard(
  label: String,
  count: Int,
  color: Color,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 12.dp, horizontal = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
      Spacer(modifier = Modifier.height(4.dp))
      Text(text = "$count", color = color, fontSize = 20.sp, fontWeight = FontWeight.Bold)
      Text(text = label, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
  }
}

@Composable
private fun MetricRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 3.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(text = value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
  }
}
