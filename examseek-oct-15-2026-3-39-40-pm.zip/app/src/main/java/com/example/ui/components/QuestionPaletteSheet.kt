package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.QuestionStatus
import com.example.domain.model.TestQuestion

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun QuestionPaletteSheet(
  questions: List<TestQuestion>,
  currentIndex: Int,
  getQuestionStatus: (String) -> QuestionStatus,
  onQuestionSelect: (Int) -> Unit,
  onSubmitClick: () -> Unit,
  onDismiss: () -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 10.dp)
        .verticalScroll(rememberScrollState())
    ) {
      Text(
        text = "Question Palette",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = "Select any question number to navigate instantly",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(16.dp))

      // Status Legend
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        LegendItem(color = Color(0xFF10B981), label = "Answered")
        LegendItem(color = Color(0xFFEF4444), label = "Unanswered")
        LegendItem(color = Color(0xFF8B5CF6), label = "Marked")
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Grid of Questions
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        questions.forEachIndexed { index, question ->
          val status = getQuestionStatus(question.id)
          val isCurrent = index == currentIndex

          val (bgColor, textColor) = when (status) {
            QuestionStatus.ANSWERED -> Color(0xFF10B981) to Color.White
            QuestionStatus.MARKED_FOR_REVIEW,
            QuestionStatus.ANSWERED_AND_MARKED_FOR_REVIEW -> Color(0xFF8B5CF6) to Color.White
            QuestionStatus.NOT_ANSWERED -> Color(0xFFEF4444) to Color.White
            QuestionStatus.NOT_VISITED -> Color(0xFFE2E8F0) to Color(0xFF475569)
          }

          Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
              .size(44.dp)
              .testTag("palette_q_${index + 1}")
              .clip(CircleShape)
              .background(bgColor)
              .then(
                if (isCurrent) Modifier.border(2.5.dp, MaterialTheme.colorScheme.primary, CircleShape)
                else Modifier
              )
              .clickable {
                onQuestionSelect(index)
                onDismiss()
              }
          ) {
            Text(
              text = "${index + 1}",
              color = textColor,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      Button(
        onClick = {
          onDismiss()
          onSubmitClick()
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("palette_submit_button"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = MaterialTheme.colorScheme.error
        )
      ) {
        Text("Submit Test Now", fontWeight = FontWeight.Bold)
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}

@Composable
private fun LegendItem(color: Color, label: String) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Box(
      modifier = Modifier
        .size(12.dp)
        .clip(CircleShape)
        .background(color)
    )
    Spacer(modifier = Modifier.width(6.dp))
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
  }
}
