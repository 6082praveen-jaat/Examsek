package com.example.data.formula

import com.example.domain.formula.FormulaSubject
import com.example.domain.formula.FormulaTopic
import com.example.data.formula.FormulaTopicBuilder.createExample
import com.example.data.formula.FormulaTopicBuilder.createMcq

object ReasoningTopicsPart2 {

  val topics: List<FormulaTopic> = listOf(
    // 11. Inequalities
    FormulaTopic(
      id = "reas_inequalities",
      subject = FormulaSubject.REASONING,
      chapter = "Logical Reasoning",
      title = "Mathematical Inequalities",
      hindiTitle = "असमानताएं",
      summary = "Direct and coded inequalities, priority of signs (>, ≥, =), and either-or conditions.",
      coreFormula = "Priority of Signs: Priority 1 (>, <) > Priority 2 (≥, ≤) > Priority 3 (=)\nOpposite Signs Break Chain: A > B < C => No definite relation between A and C\nEither-Or Rules:\n1. If A ≥ B: Either A > B or A = B\n2. Opposite signs break: Either A > C or A ≤ C (covers all 3 cases: >, <, =)",
      symbolExplanations = listOf(
        ">, <" to "Strict inequality (Priority 1).",
        "≥, ≤" to "Partial inequality with equality (Priority 2).",
        "=" to "Equality (Priority 3)."
      ),
      importantIdentities = listOf(
        "If path from X to Y has at least one '>' and no '<', then X > Y.",
        "If path has only '≥' and '=', then X ≥ Y."
      ),
      shortcutsAndTips = listOf(
        "Open door / Closed door concept: Can only move in direction where symbol opens (A > B allows moving from A to B)."
      ),
      commonMistakes = listOf(
        "Concluding A > C when an opposite symbol exists between them."
      ),
      solvedExamples = listOf(
        createExample(
          "ineq_ex1",
          "Statement: P ≥ Q > R = S ≤ T\nConclusions: (I) P > S (II) Q ≤ T",
          "कथन: P ≥ Q > R = S ≤ T\nनिष्कर्ष: (I) P > S (II) Q ≤ T",
          listOf(
            "Step 1: Check Conclusion I (P > S): Path is P ≥ Q > R = S. Priority 1 symbol (>) is present and all signs face same way. P > S is TRUE.",
            "Step 2: Check Conclusion II (Q ≤ T): Path is Q > R = S ≤ T. There are opposite signs (> and ≤). Chain is broken. Definite relation cannot be established. False.",
            "Step 3: Only Conclusion I is true."
          ),
          "Only Conclusion I follows",
          "Priority 1 '>' prevails."
        ),
        createExample(
          "ineq_ex2",
          "Statement: M ≤ N < O; O = P ≥ Q\nConclusions: (I) M < P (II) M ≥ P",
          "कथन: M ≤ N < O = P ≥ Q\nनिष्कर्ष: (I) M < P (II) M ≥ P",
          listOf(
            "Step 1: Path from M to P: M ≤ N < O = P. Since '<' is present, M < P is definitely TRUE.",
            "Step 2: Conclusion II (M ≥ P) is completely false.",
            "Step 3: Only Conclusion I follows."
          ),
          "Only Conclusion I follows",
          "M < P is definitely true."
        ),
        createExample(
          "ineq_ex3",
          "Statement: A ≥ B > C; C < D ≤ E\nConclusions: (I) A > E (II) A ≤ E",
          "कथन: A ≥ B > C < D ≤ E\nनिष्कर्ष: (I) A > E (II) A ≤ E",
          listOf(
            "Step 1: Path between A and E has opposite signs (> and <) at C. No definite relation.",
            "Step 2: Check Either-Or: Conclusions compare A and E, both are individually doubtful, and together they cover all three possibilities (A > E, A < E, A = E).",
            "Step 3: Therefore, Either Conclusion I or II follows."
          ),
          "Either I or II follows",
          "Covers all 3 possibilities: >, <, =."
        )
      ),
      practiceMcqs = listOf(
        createMcq("ineq_q1", "Statement: A > B ≥ C = D. Conclusion: A > D.", "", "Follows", "Does not follow", "Either-or", "False", 0, "A > B ≥ C = D has '>' in path, so A > D definitely holds."),
        createMcq("ineq_q2", "Statement: X ≥ Y > Z; Z ≥ W. Conclusion: X > W.", "", "Follows", "Does not follow", "Doubtful", "False", 0, "X ≥ Y > Z ≥ W has '>' in path. X > W holds."),
        createMcq("ineq_q3", "Statement: P < Q ≤ R; R > S. Conclusion: P < S.", "", "Does not follow", "Follows", "True", "Certain", 0, "Opposite signs (< and >) break connection between P and S."),
        createMcq("ineq_q4", "Statement: K = L ≥ M = N. Conclusions: (I) K > N, (II) K = N.", "", "Either I or II follows", "Only I", "Only II", "Neither", 0, "K ≥ N means either K > N or K = N."),
        createMcq("ineq_q5", "Statement: M ≤ N < O ≤ P. Conclusion: M < P.", "", "Follows", "Does not follow", "Doubtful", "False", 0, "Strict '<' exists in unidirectional path, so M < P holds."),
        createMcq("ineq_q6", "If P @ Q means P > Q, P # Q means P < Q, P $ Q means P = Q. Which shows A > C?", "", "A @ B @ C", "A # B # C", "A $ B # C", "A # B @ C", 0, "A > B and B > C implies A > C."),
        createMcq("ineq_q7", "Statement: E > F ≥ G; G < H. Conclusion: E > H.", "", "Does not follow", "Follows", "True", "Definite", 0, "Opposite signs at G break connection."),
        createMcq("ineq_q8", "Statement: T ≤ U = V ≤ W. Conclusion: T ≤ W.", "", "Follows", "Does not follow", "False", "Either-or", 0, "All signs are ≤ and =, so T ≤ W holds."),
        createMcq("ineq_q9", "Statement: R > S ≥ T; T = U > V. Conclusion: R > V.", "", "Follows", "Does not follow", "Doubtful", "False", 0, "R > S ≥ T = U > V. Complete valid path with strict inequality."),
        createMcq("ineq_q10", "Statement: J ≥ K; K > L; L ≤ M. Conclusion: J > L.", "", "Follows", "Does not follow", "False", "Neither", 0, "J ≥ K > L implies J > L.")
      )
    ),

    // 12. Seating Arrangement
    FormulaTopic(
      id = "reas_seating_arrangement",
      subject = FormulaSubject.REASONING,
      chapter = "Analytical Reasoning",
      title = "Seating Arrangement",
      hindiTitle = "बैठक व्यवस्था",
      summary = "Linear row, parallel rows, square/rectangular tables, facing center vs facing outward.",
      coreFormula = "Circular Center Facing: Left = Clockwise, Right = Anti-Clockwise\nCircular Outward Facing: Left = Anti-Clockwise, Right = Clockwise\nLinear Facing North: Left = Left, Right = Right\nLinear Facing South: Left = Right, Right = Left",
      symbolExplanations = listOf(
        "Immediate Left/Right" to "Directly adjacent without any person in between.",
        "Opposite" to "Sitting across the diameter (for even number of people, e.g. 8 people: pos n and n+4)."
      ),
      importantIdentities = listOf(
        "For 8 people at circular table: Opposite person is 4 seats away (8/2).",
        "For 6 people: Opposite person is 3 seats away."
      ),
      shortcutsAndTips = listOf(
        "Always place the person with the most definitive relative position first."
      ),
      commonMistakes = listOf(
        "Mixing up left and right when persons face outside the circle."
      ),
      solvedExamples = listOf(
        createExample(
          "sa_ex1",
          "8 persons A, B, C, D, E, F, G, H sit around circular table facing center. B is 3rd to right of A. F is 2nd to right of B. Find opposite of A.",
          "8 व्यक्ति केंद्र की ओर मुख करके बैठे हैं। B, A के दाएं तीसरा है। F, B के दाएं दूसरा है। A के सामने कौन है?",
          listOf(
            "Step 1: Fix A at bottom (Pos 1). Facing center, Right is Anti-Clockwise.",
            "Step 2: B is 3rd to right of A => Pos 4.",
            "Step 3: F is 2nd to right of B => Pos 6.",
            "Step 4: Opposite of Pos 1 (A) is Pos 1 + 4 = Pos 5."
          ),
          "Seat 5 (calculated via diagram)",
          "Opposite is always (N/2) seats away."
        ),
        createExample(
          "sa_ex2",
          "Five friends P, Q, R, S, T sit in a row facing North. S is between T and Q. Q is to immediate left of R. P is to immediate left of T. Who is in the middle?",
          "पाँच मित्र उत्तर की ओर मुख करके बैठे हैं। S, T और Q के बीच है। Q, R के ठीक बाएं है। P, T के ठीक बाएं है। बीच में कौन है?",
          listOf(
            "Step 1: 'P is immediate left of T': P T.",
            "Step 2: 'S is between T and Q': P T S Q.",
            "Step 3: 'Q is immediate left of R': P T S Q R.",
            "Step 4: The 5 persons from left to right are P, T, S, Q, R. Middle person is S."
          ),
          "S",
          "Linear assembly."
        ),
        createExample(
          "sa_ex3",
          "Four girls and four boys sit facing center. No two boys are adjacent. Who sits opposite a boy?",
          "चार लड़के और चार लड़कियां केंद्र की ओर मुख करके बैठे हैं। कोई भी दो लड़के साथ नहीं हैं। लड़के के सामने कौन बैठा है?",
          listOf(
            "Step 1: Boys and girls must alternate: B G B G B G B G.",
            "Step 2: Number of seats = 8. Opposite of any position is 4 seats away.",
            "Step 3: Moving 4 seats from a boy (odd pos 1): 1 + 4 = 5 (also a boy pos).",
            "Step 4: Opposite every boy is another boy."
          ),
          "Another Boy",
          "In alternating 8-person circle, parity matches: pos 1 and 5 are both boys."
        )
      ),
      practiceMcqs = listOf(
        createMcq("sa_q1", "In circle facing center, your left is:", "", "Clockwise", "Anti-clockwise", "North", "South", 0, "Facing center, left is clockwise."),
        createMcq("sa_q2", "Six people sit in circle facing center. Opposite to seat 1 is seat:", "", "4", "3", "5", "6", 0, "6 / 2 = 3. 1 + 3 = seat 4."),
        createMcq("sa_q3", "A, B, C, D sit in row facing North. A and B are at ends. C is to right of A. Order is:", "", "A C D B", "B C D A", "A D C B", "C A D B", 0, "A at left end, C right of A, D next, B at right end."),
        createMcq("sa_q4", "If people face outward from circle, right is:", "", "Clockwise", "Anti-clockwise", "Inward", "Outward", 0, "Facing outward, right becomes clockwise."),
        createMcq("sa_q5", "Seven persons A to G sit in row facing North. D sits in middle. D's position from left:", "", "4th", "3rd", "5th", "2nd", 0, "(7 + 1) / 2 = 4th."),
        createMcq("sa_q6", "In parallel rows, Row 1 faces South, Row 2 faces North. Person at left end of Row 1 faces:", "", "Right end of Row 2", "Left end of Row 2", "Middle", "None", 0, "South facing left end is on geographical East, which is right end of North facing row."),
        createMcq("sa_q7", "A is second to left of C. C is to immediate left of D. Order from left:", "", "A _ C D", "A C D _", "C A D _", "D C A _", 0, "A is two steps left of C, so A [someone] C D."),
        createMcq("sa_q8", "Eight people at square table, 4 at corners, 4 at midpoints. Corner people face center, midpoint face outward. Person to left of corner:", "", "Faces outward", "Faces center", "Both", "Neither", 0, "Next to corner is midpoint person who faces outward."),
        createMcq("sa_q9", "A, B, C, D, E sit in line facing North. C is between A and E. B is immediate right of E. Middle person:", "", "C", "A", "E", "B", 0, "A C E B (or reverse). C is between A and E."),
        createMcq("sa_q10", "If X is 4th to left of Y in a circle of 8 facing center, X and Y are:", "", "Opposite to each other", "Adjacent", "2 seats apart", "3 seats apart", 0, "In circle of 8, 4th to left or right is diametrically opposite.")
      )
    ),

    // 13. Linear Puzzles
    FormulaTopic(
      id = "reas_linear_puzzles",
      subject = FormulaSubject.REASONING,
      chapter = "Puzzles",
      title = "Linear Puzzles & Floor Puzzles",
      hindiTitle = "रैखिक एवं तल पहेलियां",
      summary = "Multi-variable linear arrangement, building floors (ground floor = 1), and scheduling days/months.",
      coreFormula = "Floor Numbering: Ground floor = 1, Top floor = N\nGap Formula: Between Floor A and Floor B = |A - B| - 1\nElimination Method: Draw parallel columns for possible cases",
      symbolExplanations = listOf(
        "Adjacent floors" to "Floor numbers differing by exactly 1 (|A - B| = 1).",
        "Even/Odd floor" to "Floors with even (2, 4, 6...) or odd (1, 3, 5...) numbers."
      ),
      importantIdentities = listOf(
        "If there are 3 floors between A and B, |A - B| = 4.",
        "Ground floor is standardly Floor 1 unless explicitly designated Floor 0."
      ),
      shortcutsAndTips = listOf(
        "Create 2-3 parallel case diagrams immediately when a definite clue gives two possibilities."
      ),
      commonMistakes = listOf(
        "Confusing '3 floors above' (Floor + 3) with '3 floors between' (Floor + 4)."
      ),
      solvedExamples = listOf(
        createExample(
          "lp_ex1",
          "7 persons live on 7 floors (1 to 7). A lives on an odd floor above floor 4. There are two floors between A and B. Which floor does B live on?",
          "7 व्यक्ति 7 मंजिलों (1 से 7) पर रहते हैं। A मंजिल 4 के ऊपर विषम मंजिल पर रहता है। A और B के बीच दो मंजिलें हैं।",
          listOf(
            "Step 1: Odd floors above 4 are Floor 5 and Floor 7.",
            "Step 2: Case 1: If A is on Floor 5, two floors between A and B means B can be on Floor 5 - 3 = Floor 2.",
            "Step 3: Case 2: If A is on Floor 7, B can be on Floor 7 - 3 = Floor 4.",
            "Step 4: Distinct valid floors depending on secondary clues are 2 or 4."
          ),
          "Floor 2 or 4",
          "Between means gap = 2, so difference = 3."
        ),
        createExample(
          "lp_ex2",
          "7 exams are scheduled from Monday to Sunday. Math is immediately before English. Physics is on Wednesday. Exactly 2 exams between Physics and Chemistry. Chemistry is after Physics. On which day is Chemistry?",
          "7 परीक्षाएं सोमवार से रविवार तक हैं। भौतिकी बुधवार को है। भौतिकी और रसायन के बीच 2 परीक्षाएं हैं और रसायन बाद में है।",
          listOf(
            "Step 1: Wednesday is Physics.",
            "Step 2: Exactly 2 exams after Wednesday are Thursday and Friday.",
            "Step 3: Therefore, Chemistry is scheduled on Saturday."
          ),
          "Saturday",
          "2 days between Wed and Sat."
        ),
        createExample(
          "lp_ex3",
          "P, Q, R, S, T each have a different car. P's car is costlier than R's but cheaper than T's. Q's car is costlier than S's but cheaper than R's. Whose car is the costliest?",
          "P की कार R से महंगी लेकिन T से सस्ती है। Q की कार S से महंगी लेकिन R से सस्ती है। सबसे महंगी कार किसकी है?",
          listOf(
            "Step 1: T > P > R.",
            "Step 2: R > Q > S.",
            "Step 3: Combine: T > P > R > Q > S.",
            "Step 4: T has the costliest car."
          ),
          "T",
          "Linear ranking puzzle."
        )
      ),
      practiceMcqs = listOf(
        createMcq("lp_q1", "In 8-floor building, how many floors between floor 2 and floor 7?", "", "4", "5", "3", "6", 0, "Between = 7 - 2 - 1 = 4 floors (3, 4, 5, 6)."),
        createMcq("lp_q2", "A lives 3 floors above B. If B is on floor 2, A is on floor:", "", "5", "6", "4", "7", 0, "2 + 3 = 5th floor."),
        createMcq("lp_q3", "7 people attend seminar Mon to Sun. A attends on Tuesday. 3 people between A and B. B attends on:", "", "Saturday", "Friday", "Sunday", "Monday", 0, "Tue + 4 days = Saturday (Wed, Thu, Fri between)."),
        createMcq("lp_q4", "A is taller than B, C is taller than A, D is taller than E but shorter than B. Tallest person is:", "", "C", "A", "D", "B", 0, "C > A > B > D > E. Tallest is C."),
        createMcq("lp_q5", "Six boxes A to F placed one above another. A is placed immediately above B. C is between D and E. Box at bottom:", "", "Determined by clues", "A", "F", "B", 0, "Solved via elimination."),
        createMcq("lp_q6", "In a race, A beats B by 10 m, B beats C by 5 m. A beats C by:", "", "15 m (approx linear)", "10 m", "5 m", "20 m", 0, "Direct summation in simple linear comparison."),
        createMcq("lp_q7", "If top floor is 6 and odd floors are painted red, how many floors are red?", "", "3", "2", "4", "1", 0, "Floors 1, 3, 5 = 3 floors."),
        createMcq("lp_q8", "Five books Hindi, English, Math, Science, Sanskrit on table. Math is above English, Science is below Sanskrit, Hindi is between English and Sanskrit. Lowest book:", "", "Science", "Math", "Hindi", "English", 0, "Order top to bottom: Math, English, Hindi, Sanskrit, Science."),
        createMcq("lp_q9", "P, Q, R, S, T live on 5 floors. T lives on odd floor. P lives immediately above T. T cannot be on:", "", "Floor 5", "Floor 1", "Floor 3", "None", 0, "If T were on top floor 5, nobody could live immediately above him."),
        createMcq("lp_q10", "X is heavier than Y but lighter than Z. W is lighter than Y. Lightest is:", "", "W", "Y", "X", "Z", 0, "Z > X > Y > W. Lightest is W.")
      )
    ),

    // 14. Circular Puzzles
    FormulaTopic(
      id = "reas_circular_puzzles",
      subject = FormulaSubject.REASONING,
      chapter = "Puzzles",
      title = "Circular Puzzles",
      hindiTitle = "वृत्ताकार पहेलियां",
      summary = "Circular table puzzles with dual parameters (professions, blood relations, inside/outside faces).",
      coreFormula = "Total Seats = N\nFacing Opposite = N / 2 (only for even N)\nImmediate Neighbors: Positions (k - 1) and (k + 1)",
      symbolExplanations = listOf(
        "Dual parameter" to "Each person has name + variable (e.g. city, fruit, subject)."
      ),
      importantIdentities = listOf(
        "If some face center and some face outside, determine unknown direction from turning clues (e.g. 'A faces center and B sits 2nd to right of A')."
      ),
      shortcutsAndTips = listOf(
        "Draw dual circles: inner circle for names, outer ring for attributes."
      ),
      commonMistakes = listOf(
        "Assuming all face center when problem states 'some face inside and some face outside'."
      ),
      solvedExamples = listOf(
        createExample(
          "cp_ex1",
          "8 persons sit in a circle. 4 face center and 4 face outside. No two facing same direction sit together. If A faces center, what does person 3rd to right of A face?",
          "8 व्यक्ति वृत्त में बैठते हैं। 4 केंद्र की ओर और 4 बाहर की ओर देखते हैं। समान दिशा वाले साथ नहीं बैठते। यदि A केंद्र देखता है...",
          listOf(
            "Step 1: Directions alternate: In, Out, In, Out, In, Out, In, Out.",
            "Step 2: A is Pos 1 (In). Pos 2 is Out, Pos 3 is In, Pos 4 is Out.",
            "Step 3: Person 3rd to right of A sits at Pos 4.",
            "Step 4: Pos 4 faces Outside."
          ),
          "Outside",
          "Alternating directions: In, Out, In, Out."
        ),
        createExample(
          "cp_ex2",
          "6 persons sit around circle. A is doctor, sits opposite engineer C. B is lawyer, sits between A and D. Who sits opposite lawyer B?",
          "6 व्यक्ति वृत्त में बैठे हैं। A (डॉक्टर) C (इंजीनियर) के सामने है। B (वकील) A और D के बीच है। B के सामने कौन है?",
          listOf(
            "Step 1: Total 6 seats. Opposite is 3 seats away.",
            "Step 2: A is at 1, C is at 4.",
            "Step 3: B is between A and D => B is at 2, D is at 3 (or B at 6, D at 5).",
            "Step 4: Opposite of B (pos 2) is pos 2 + 3 = pos 5."
          ),
          "Person at position 5",
          "Circular opposite is N/2."
        ),
        createExample(
          "cp_ex3",
          "In a circle of 8 people, P sits second to left of Q, who faces outside. In which direction is P relative to center?",
          "8 व्यक्तियों के वृत्त में P, Q के बाएं दूसरा है जो बाहर की ओर देख रहा है।",
          listOf(
            "Step 1: Q faces outside.",
            "Step 2: Facing outside, Left is Anti-Clockwise.",
            "Step 3: 2 seats Anti-Clockwise from Q is P."
          ),
          "2 seats Anti-Clockwise",
          "Outside left = anti-clockwise."
        )
      ),
      practiceMcqs = listOf(
        createMcq("cp_q1", "In 8-person circle facing center, how many people between P and opposite of P?", "", "3 on either side", "4", "2", "5", 0, "Opposite is 4 seats away, leaving 3 people on each side."),
        createMcq("cp_q2", "If X is 3rd to right of Y and Y faces center in 8-person circle, how many between them from right of Y?", "", "2", "3", "4", "1", 0, "1st, 2nd are between them, so 2 people between."),
        createMcq("cp_q3", "Round table with 5 people. How many opposite pairs exist?", "", "0", "1", "2", "5", 0, "Odd number of people has no exact diametrically opposite pairs."),
        createMcq("cp_q4", "A sits adjacent to both B and C in circle. A is:", "", "Between B and C", "Opposite B", "Opposite C", "None", 0, "Adjacent to both means strictly between them."),
        createMcq("cp_q5", "Person facing outside turns 90° right. He now faces:", "", "Tangential clockwise", "Center", "Opposite", "Left", 0, "90° turn from outward radial vector points along tangent."),
        createMcq("cp_q6", "In circle of 8, if A is opposite B and C is opposite D, how many people between A and C if they are separated by 1 person?", "", "1", "2", "3", "0", 0, "Given as 1 person."),
        createMcq("cp_q7", "If P is immediate left of Q and Q is immediate left of R, order clockwise (facing center) is:", "", "P, Q, R", "R, Q, P", "Q, P, R", "P, R, Q", 0, "Facing center, left is clockwise: P -> Q -> R."),
        createMcq("cp_q8", "Total arrangements of 7 people around circular table:", "", "720", "5040", "120", "240", 0, "(7 - 1)! = 6! = 720."),
        createMcq("cp_q9", "In circle of 8 facing center, A is 2nd to left of B and 3rd to right of C. Distance between B and C:", "", "3 seats", "4 seats", "2 seats", "Adjacent", 0, "B is +2 from A, C is -3 from A. Gap = 5 seats (or 3 seats other way)."),
        createMcq("cp_q10", "If two people must never sit together at circular table of 6, valid arrangements are:", "", "72", "120", "48", "96", 0, "Total (5! = 120) - together (4! × 2! = 48) = 72.")
      )
    ),

    // 15. Calendar
    FormulaTopic(
      id = "reas_calendar",
      subject = FormulaSubject.REASONING,
      chapter = "Time & Logic",
      title = "Calendar",
      hindiTitle = "कैलेंडर",
      summary = "Odd days concept, leap year rules (divisible by 4 or 400), day of week calculation, and calendar repetition.",
      coreFormula = "Odd Days = Total Days mod 7\nNormal Year (365 days) = 52 weeks + 1 odd day\nLeap Year (366 days) = 52 weeks + 2 odd days\nCentury Odd Days: 100 yrs = 5 odd days, 200 yrs = 3, 300 yrs = 1, 400 yrs = 0\nDay Mapping: 0=Sun, 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat",
      symbolExplanations = listOf(
        "Leap Year Rule" to "Divisible by 4, but century year must be divisible by 400 (e.g. 1900 was NOT leap, 2000 WAS leap).",
        "Odd Days" to "Days remaining after dividing total days by 7."
      ),
      importantIdentities = listOf(
        "Calendar Repetition:\nLeap Year repeats after 28 years\nLeap Year + 1 repeats after 6 years\nLeap Year + 2 or + 3 repeats after 11 years",
        "Last day of a century CANNOT be Tuesday, Thursday, or Saturday."
      ),
      shortcutsAndTips = listOf(
        "Normal year starts and ends on the same day of the week (Jan 1 and Dec 31 have same day)."
      ),
      commonMistakes = listOf(
        "Treating century years like 1700, 1800, 1900 as leap years (they are not divisible by 400)."
      ),
      solvedExamples = listOf(
        createExample(
          "cal_ex1",
          "What day of the week was 15th August 1947?",
          "15 अगस्त 1947 को सप्ताह का कौन सा दिन था?",
          listOf(
            "Step 1: 1946 completed years = 1600 yrs + 300 yrs + 46 yrs.",
            "Step 2: 1600 yrs = 0 odd days. 300 yrs = 1 odd day.",
            "Step 3: 46 yrs = 11 leap yrs (11×2=22) + 35 normal yrs (35×1=35) = 57 days = 57 mod 7 = 1 odd day.",
            "Step 4: Year 1947 up to Aug 15: Jan(3) + Feb(0) + Mar(3) + Apr(2) + May(3) + Jun(2) + Jul(3) + Aug(15) = 31 days = 31 mod 7 = 3 odd days.",
            "Step 5: Total odd days = 0 + 1 + 1 + 3 = 5 odd days.",
            "Step 6: Day 5 corresponds to Friday."
          ),
          "Friday",
          "Standard odd days breakdown."
        ),
        createExample(
          "cal_ex2",
          "The calendar for the year 2024 will repeat in which year?",
          "वर्ष 2024 का कैलेंडर किस वर्ष पुनः प्रयोग होगा?",
          listOf(
            "Step 1: Check year type: 2024 is divisible by 4, so it is a LEAP year.",
            "Step 2: A leap year calendar repeats after 28 years.",
            "Step 3: 2024 + 28 = 2052."
          ),
          "2052",
          "Leap year repeats in 28 years."
        ),
        createExample(
          "cal_ex3",
          "If 1st January 2007 was Monday, what day was 1st January 2008?",
          "यदि 1 जनवरी 2007 को सोमवार था, तो 1 जनवरी 2008 को क्या दिन था?",
          listOf(
            "Step 1: 2007 is an ordinary year (365 days).",
            "Step 2: An ordinary year has 1 odd day.",
            "Step 3: Monday + 1 day = Tuesday."
          ),
          "Tuesday",
          "Ordinary year adds 1 day."
        )
      ),
      practiceMcqs = listOf(
        createMcq("cal_q1", "Which of the following is a leap year?", "", "2000", "1900", "1800", "2100", 0, "Century year must be divisible by 400. Only 2000 is divisible by 400."),
        createMcq("cal_q2", "How many odd days are there in 100 years?", "", "5", "3", "1", "0", 0, "24 leap (48) + 76 normal (76) = 124 days = 17 weeks + 5 odd days."),
        createMcq("cal_q3", "Last day of a century year cannot be:", "", "Tuesday", "Monday", "Wednesday", "Friday", 0, "Last days can be Sun(0), Wed(3), Fri(5), Mon(1). Cannot be Tue, Thu, Sat."),
        createMcq("cal_q4", "Calendar of 2009 repeats in:", "", "2015", "2020", "2018", "2014", 0, "2009 is Leap+1 (2008+1), so repeats after 6 years: 2009 + 6 = 2015."),
        createMcq("cal_q5", "If today is Wednesday, after 61 days it will be:", "", "Monday", "Sunday", "Tuesday", "Thursday", 0, "61 mod 7 = 5 odd days. Wednesday + 5 days = Monday."),
        createMcq("cal_q6", "Number of days in x weeks x days is:", "", "8x", "7x²", "14x", "7", 0, "x weeks = 7x days. Total = 7x + x = 8x days."),
        createMcq("cal_q7", "If Feb 1, 2020 was Saturday, March 1, 2020 was:", "", "Sunday", "Monday", "Saturday", "Tuesday", 0, "2020 is leap year, so Feb has 29 days. 29 mod 7 = 1 odd day. Sat + 1 = Sunday."),
        createMcq("cal_q8", "What day was 26th January 1950 (Republic Day)?", "", "Thursday", "Friday", "Wednesday", "Tuesday", 0, "1949 completed + 26 days of Jan. Total odd days = 4 = Thursday."),
        createMcq("cal_q9", "Calendar of 2011 repeats in:", "", "2022", "2017", "2020", "2023", 0, "2011 is Leap+3, repeats after 11 years: 2011 + 11 = 2022."),
        createMcq("cal_q10", "First day of ordinary year is Friday. Last day of that year is:", "", "Friday", "Saturday", "Thursday", "Sunday", 0, "An ordinary year starts and ends on the exact same day of week.")
      )
    ),

    // 16. Clock
    FormulaTopic(
      id = "reas_clock",
      subject = FormulaSubject.REASONING,
      chapter = "Time & Logic",
      title = "Clock Reasoning",
      hindiTitle = "घड़ी",
      summary = "Angle between hands, coincidences, right angles, straight lines, mirror image, and water image.",
      coreFormula = "Angle between Hands: θ = |30H - (11/2) M|\nSpeed of Minute Hand = 6° per minute\nSpeed of Hour Hand = 0.5° per minute\nRelative Speed = 5.5° per minute (11/2 °/min)\nMirror Image Time = 11:60 - Given Time\nWater Image Time = 18:30 (or 17:90) - Given Time",
      symbolExplanations = listOf(
        "H" to "Hour (1 to 12).",
        "M" to "Minutes (0 to 59).",
        "θ" to "Angle between hour hand and minute hand."
      ),
      importantIdentities = listOf(
        "Coincide (0°): 22 times in 24 hours (11 times in 12 hours).",
        "Opposite (180°): 22 times in 24 hours (11 times in 12 hours).",
        "Right Angle (90°): 44 times in 24 hours (22 times in 12 hours)."
      ),
      shortcutsAndTips = listOf(
        "Hands coincide once every 65 5/11 minutes."
      ),
      commonMistakes = listOf(
        "Assuming hands coincide 24 times in a day (they only coincide 22 times because between 11 and 1 they coincide only once, at 12:00)."
      ),
      solvedExamples = listOf(
        createExample(
          "clk_ex1",
          "Find the angle between the hour hand and the minute hand of a clock at 3:40.",
          "3:40 पर घड़ी की सुइयों के बीच का कोण ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula: θ = |30H - (11/2) M|.",
            "Step 2: Here H = 3, M = 40.",
            "Step 3: θ = |30(3) - (11/2)(40)| = |90 - 220| = |-130| = 130°."
          ),
          "130°",
          "Direct formula θ = |30H - 5.5M|."
        ),
        createExample(
          "clk_ex2",
          "At what time between 4 and 5 o'clock will the hands of a clock be together (coincide)?",
          "4 और 5 बजे के बीच घड़ी की सुइयां कब एक साथ होंगी?",
          listOf(
            "Step 1: At 4:00, hour hand is at 4 × 30° = 120°.",
            "Step 2: Relative speed of minute hand = 5.5°/min = 11/2 °/min.",
            "Step 3: Time M = 120 / (11/2) = 240 / 11 = 21 9/11 minutes.",
            "Step 4: Hands coincide at 4 hours 21 9/11 minutes."
          ),
          "4:21 9/11",
          "Shortcut: M = (60/11) × H = 60/11 × 4 = 240/11."
        ),
        createExample(
          "clk_ex3",
          "A clock seen through a mirror shows 8:25. What is the actual time?",
          "दर्पण में देखने पर घड़ी 8:25 दर्शाती है। वास्तविक समय क्या है?",
          listOf(
            "Step 1: Formula for mirror image = 11:60 - Given Time.",
            "Step 2: 11:60 - 8:25 = 3:35."
          ),
          "3:35",
          "Subtract from 11:60."
        )
      ),
      practiceMcqs = listOf(
        createMcq("clk_q1", "Angle between hands at 7:20 is:", "", "100°", "90°", "110°", "95°", 0, "|30×7 - 11/2 × 20| = |210 - 110| = 100°."),
        createMcq("clk_q2", "How many times do hands of clock coincide in a day (24 hours)?", "", "22", "24", "44", "48", 0, "11 times in 12 hours => 22 times in 24 hours."),
        createMcq("clk_q3", "How many times are hands at right angle in 24 hours?", "", "44", "48", "22", "24", 0, "22 times in 12 hours => 44 times in 24 hours."),
        createMcq("clk_q4", "Mirror image of 4:15 is:", "", "7:45", "8:45", "7:15", "8:15", 0, "11:60 - 4:15 = 7:45."),
        createMcq("clk_q5", "Angle between hands at 8:30 is:", "", "75°", "60°", "80°", "70°", 0, "|30×8 - 11/2 × 30| = |240 - 165| = 75°."),
        createMcq("clk_q6", "How many times are hands in a straight line (0° or 180°) in a day?", "", "44", "22", "48", "24", 0, "22 (coinciding) + 22 (opposite) = 44 times."),
        createMcq("clk_q7", "Water image of clock showing 2:20 is:", "", "4:10", "4:20", "5:10", "3:10", 0, "18:30 - 2:20 = 16:10 = 4:10."),
        createMcq("clk_q8", "Minute hand gains how many degrees over hour hand in 1 minute?", "", "5.5°", "6°", "0.5°", "5°", 0, "6° - 0.5° = 5.5° per minute."),
        createMcq("clk_q9", "At what time between 7 and 8 o'clock are hands at 180° (opposite)?", "", "7:05 5/11", "7:06", "7:04", "7:05", 0, "Hour hand at 7 is at 210°. Opposite needs 210° - 180° = 30°. M = 30 / 5.5 = 60/11 = 5 5/11 min."),
        createMcq("clk_q10", "A clock loses 5 minutes every hour. In 24 hours, it will lose:", "", "120 min (2 hrs)", "60 min", "100 min", "90 min", 0, "24 × 5 = 120 minutes = 2 hours.")
      )
    ),

    // 17. Statement and Conclusion
    FormulaTopic(
      id = "reas_statement_conclusion",
      subject = FormulaSubject.REASONING,
      chapter = "Critical Reasoning",
      title = "Statement and Conclusion",
      hindiTitle = "कथन एवं निष्कर्ष",
      summary = "Deriving logically sound conclusions without assuming external unstated facts.",
      coreFormula = "Valid Conclusion: Must be directly supported by facts given in statement\nInvalid Conclusion:\n1. Contains extreme words ('All', 'Always', 'Never', 'Only') not in statement\n2. Based on external general knowledge outside scope of statement\n3. Merely a repetition or restatement",
      symbolExplanations = listOf(
        "Conclusion" to "A proposition derived by necessary implication from the premises."
      ),
      importantIdentities = listOf(
        "Truth of statement must be taken as 100% indisputable, even if at variance with commonly known facts."
      ),
      shortcutsAndTips = listOf(
        "Look for qualifying words: 'may', 'can', 'sometimes' are often valid; 'must', 'always' are rarely valid unless explicitly stated."
      ),
      commonMistakes = listOf(
        "Using real-world bias to accept a conclusion that is not stated in the passage."
      ),
      solvedExamples = listOf(
        createExample(
          "sc_ex1",
          "Statement: In a one-day cricket match, the total runs made by a team were 200. Out of these, 160 runs were made by spinners.\nConclusions: (I) 80% of the team consists of spinners. (II) The opening batsmen were spinners.",
          "कथन: एक दिवसीय मैच में एक टीम ने कुल 200 रन बनाए जिसमें से 160 रन स्पिनरों ने बनाए।\nनिष्कर्ष: (I) टीम में 80% स्पिनर हैं। (II) सलामी बल्लेबाज स्पिनर थे।",
          listOf(
            "Step 1: The statement only talks about runs scored, not the composition of the 11 players.",
            "Step 2: Conclusion I wrongly equates proportion of runs to proportion of team members. Invalid.",
            "Step 3: Statement mentions nothing about batting order. Conclusion II is an unverified assumption. Invalid.",
            "Step 4: Neither conclusion follows."
          ),
          "Neither I nor II follows",
          "Runs do not equate to team composition or batting order."
        ),
        createExample(
          "sc_ex2",
          "Statement: Electric cars produce zero tailpipe emissions. The government has decided to subsidize electric cars.\nConclusions: (I) The government wants to reduce vehicular air pollution. (II) Petrol cars will be completely banned next year.",
          "कथन: इलेक्ट्रिक कारें शून्य प्रदूषण करती हैं। सरकार ने इन पर सब्सिडी देने का निर्णय लिया है।",
          listOf(
            "Step 1: Zero emissions directly links to environmental pollution reduction. Conclusion I logically follows.",
            "Step 2: Complete ban next year is an extreme extrapolation nowhere suggested in the statement. Invalid.",
            "Step 3: Only Conclusion I follows."
          ),
          "Only Conclusion I follows",
          "Direct logical linkage vs extreme prediction."
        ),
        createExample(
          "sc_ex3",
          "Statement: Many creative people are writers. All writers are observant.\nConclusion: Some creative people are observant.",
          "कथन: कई रचनात्मक लोग लेखक हैं। सभी लेखक सूक्ष्मदर्शी हैं।\nनिष्कर्ष: कुछ रचनात्मक लोग सूक्ष्मदर्शी हैं।",
          listOf(
            "Step 1: 'Many creative people are writers' means Some Creative are Writers.",
            "Step 2: 'All writers are observant'.",
            "Step 3: Since the creative people who are writers must be observant, Some creative people are observant.",
            "Step 4: Conclusion logically follows."
          ),
          "Conclusion follows",
          "Syllogistic deductive validity."
        )
      ),
      practiceMcqs = listOf(
        createMcq("sc_q1", "Statement: Plants need sunlight to grow. Deep cave plants did not grow. Conclusion: Deep cave lacked sunlight.", "", "Follows", "Does not follow", "Doubtful", "False", 0, "Direct causal consequence from statement."),
        createMcq("sc_q2", "Statement: Only good runners are selected for marathon. A is selected. Conclusion: A is a good runner.", "", "Follows", "Does not follow", "Doubtful", "False", 0, "'Only' establishes necessary condition. A must be a good runner."),
        createMcq("sc_q3", "Statement: Company X doubled profits this quarter. Conclusion: Product of Company X is best in market.", "", "Does not follow", "Follows", "True", "Certain", 0, "'Best in market' is an unverified comparative claim."),
        createMcq("sc_q4", "Statement: Heavy rain caused waterlogging in the city. Conclusion: The drainage system was insufficient for the heavy rainfall.", "", "Follows", "Does not follow", "Doubtful", "False", 0, "Waterlogging is direct evidence that drainage capacity was exceeded."),
        createMcq("sc_q5", "Statement: Most students in class passed. Conclusion: The exam was very easy.", "", "Does not follow", "Follows", "True", "Certain", 0, "Passing could be due to hard study; 'easy' is an unstated assumption."),
        createMcq("sc_q6", "Statement: All politicians are public speakers. X is not a public speaker. Conclusion: X is not a politician.", "", "Follows", "Does not follow", "Doubtful", "False", 0, "Contrapositive of 'All P are S' is 'Not S => Not P'."),
        createMcq("sc_q7", "Statement: Eating apples daily keeps doctor away. R eats apples daily. Conclusion: R never falls ill.", "", "Does not follow", "Follows", "True", "Certain", 0, "'Never' is an extreme word not warranted by proverb."),
        createMcq("sc_q8", "Statement: Quality has a price tag. Country X is allocating large budget for education. Conclusion: Quality of education in Country X will improve.", "", "Follows", "Does not follow", "Doubtful", "False", 0, "Follows from premise that higher spending buys quality."),
        createMcq("sc_q9", "Statement: Unemployment rate decreased by 2%. Conclusion: Economy is generating new jobs.", "", "Follows", "Does not follow", "Doubtful", "False", 0, "Direct economic conclusion from lower unemployment."),
        createMcq("sc_q10", "Statement: Smoking is injurious to health. Government printed statutory warning. Conclusion: Statutory warning will eliminate smoking completely.", "", "Does not follow", "Follows", "True", "Certain", 0, "'Completely' is an unrealistic extreme conclusion.")
      )
    ),

    // 18. Statement and Assumption
    FormulaTopic(
      id = "reas_statement_assumption",
      subject = FormulaSubject.REASONING,
      chapter = "Critical Reasoning",
      title = "Statement and Assumption",
      hindiTitle = "कथन एवं पूर्वधारणाएं",
      summary = "Implicit premises, notices, advertisements, appeals, and unstated foundations of an argument.",
      coreFormula = "Assumption = What the author takes for granted before making statement\nNegation Test: Negate assumption. If statement collapses, assumption is IMPLICIT\nValid Assumptions:\n1. Advertisements: People respond to ads\n2. Notices/Warnings: People read and obey notices\n3. Advice: Advice has beneficial effect",
      symbolExplanations = listOf(
        "Implicit" to "Understood or taken for granted without being openly stated."
      ),
      importantIdentities = listOf(
        "Assumption is always prior to statement (pre-condition), whereas conclusion follows after statement."
      ),
      shortcutsAndTips = listOf(
        "Negation Test: If negating the assumption makes the speaker's action absurd or futile, the assumption is 100% valid."
      ),
      commonMistakes = listOf(
        "Confusing assumption (presupposition before speaking) with conclusion (deduction after speaking)."
      ),
      solvedExamples = listOf(
        createExample(
          "sa_reas_ex1",
          "Statement: 'Please do not lean out of running train' - a notice in train compartment.\nAssumptions: (I) Leaning out of running train is dangerous. (II) People generally pay attention to notices.",
          "कथन: 'कृपया चलती ट्रेन से बाहर न झुकें' - डिब्बे में एक सूचना।\nपूर्वधारणाएं: (I) बाहर झुकना खतरनाक है। (II) लोग सूचनाओं पर ध्यान देते हैं।",
          listOf(
            "Step 1: Why put a warning notice? Because leaning out carries risk of injury. Assumption I is implicit.",
            "Step 2: Why put a notice at all? Because the railway assumes passengers will read and comply. Assumption II is implicit.",
            "Step 3: Both assumptions are implicit."
          ),
          "Both I and II are implicit",
          "Safety warnings assume danger and compliance."
        ),
        createExample(
          "sa_reas_ex2",
          "Statement: 'Join coaching institute X to guarantee your selection in civil services' - an advertisement.\nAssumptions: (I) Aspirants want to be selected in civil services. (II) Good coaching institutes can help in preparation.",
          "कथन: 'सिविल सेवा में निश्चित चयन के लिए कोचिंग X से जुड़ें' - विज्ञापन।",
          listOf(
            "Step 1: The advertisement targets aspirants wanting selection. Assumption I is implicit.",
            "Step 2: Advertising benefits presupposes that coaching aids preparation. Assumption II is implicit.",
            "Step 3: Both I and II are implicit."
          ),
          "Both I and II are implicit",
          "Advertisements assume demand and effectiveness."
        ),
        createExample(
          "sa_reas_ex3",
          "Statement: 'If you are an engineer, we have a job for you' - an advertisement by Company Y.\nAssumptions: (I) Engineers are looking for jobs. (II) Company Y has jobs only for engineers.",
          "कथन: 'यदि आप इंजीनियर हैं, तो हमारे पास नौकरी है'।",
          listOf(
            "Step 1: Assumption I: The company assumes qualified engineers are seeking employment. Implicit.",
            "Step 2: Assumption II: The word 'only' is an extreme presumption; the company might also hire accountants or managers. Not implicit.",
            "Step 3: Only Assumption I is implicit."
          ),
          "Only Assumption I is implicit",
          "'Only' invalidates Assumption II."
        )
      ),
      practiceMcqs = listOf(
        createMcq("sa_reas_q1", "Statement: 'Buy pure ghee of Brand X'. Assumption: People desire purity in food items.", "", "Implicit", "Not implicit", "Doubtful", "False", 0, "Advertiser appeals to consumer desire for purity."),
        createMcq("sa_reas_q2", "Statement: 'Beware of dogs'. Assumption: Strangers can be attacked by dog.", "", "Implicit", "Not implicit", "False", "None", 0, "Warning implies real risk of dog attack."),
        createMcq("sa_reas_q3", "Statement: 'Book tickets 30 days in advance to get confirmed seat'. Assumption: People want confirmed seats.", "", "Implicit", "Not implicit", "False", "None", 0, "Advisory assumes desire for confirmed travel."),
        createMcq("sa_reas_q4", "Statement: 'Do not use mobile phones while driving'. Assumption: Mobile phones distract drivers.", "", "Implicit", "Not implicit", "False", "None", 0, "Prohibition assumes distraction and danger."),
        createMcq("sa_reas_q5", "Statement: Teacher scolded student for coming late. Assumption: Scolding will correct student's behavior.", "", "Implicit", "Not implicit", "False", "None", 0, "Disciplinary action assumes corrective effect."),
        createMcq("sa_reas_q6", "Statement: 'Switch off lights before leaving'. Assumption: Switching off saves electricity.", "", "Implicit", "Not implicit", "False", "None", 0, "Instruction assumes energy conservation."),
        createMcq("sa_reas_q7", "Statement: 'Consult doctor for recurring headache'. Assumption: Doctor can diagnose cause of headache.", "", "Implicit", "Not implicit", "False", "None", 0, "Advice assumes professional capability."),
        createMcq("sa_reas_q8", "Statement: City municipal corp appealed citizens to keep city clean. Assumption: Citizens will cooperate.", "", "Implicit", "Not implicit", "False", "None", 0, "Appeals presuppose potential public cooperation."),
        createMcq("sa_reas_q9", "Statement: 'Vote for candidate Z for honesty'. Assumption: Honesty is valued by voters.", "", "Implicit", "Not implicit", "False", "None", 0, "Campaign slogan assumes virtue is valued."),
        createMcq("sa_reas_q10", "Statement: 'Store in cool dry place'. Assumption: Cool dry storage prevents spoilage.", "", "Implicit", "Not implicit", "False", "None", 0, "Packaging instruction assumes preservation effect.")
      )
    ),

    // 19. Cause and Effect
    FormulaTopic(
      id = "reas_cause_effect",
      subject = FormulaSubject.REASONING,
      chapter = "Critical Reasoning",
      title = "Cause and Effect",
      hindiTitle = "कारण एवं प्रभाव",
      summary = "Direct cause, immediate cause, common cause, and independent causes.",
      coreFormula = "Categories:\n1. Statement I is cause, II is effect\n2. Statement II is cause, I is effect\n3. Both are effects of a COMMON cause\n4. Both are effects of INDEPENDENT causes\nCondition: Cause must precede effect in time and have direct causal mechanism",
      symbolExplanations = listOf(
        "Cause" to "Event or condition that produces an outcome.",
        "Effect" to "Consequence directly resulting from cause."
      ),
      importantIdentities = listOf(
        "Correlation does NOT imply causation (cum hoc ergo propter hoc).",
        "Two related phenomena in the same region often stem from a common underlying cause."
      ),
      shortcutsAndTips = listOf(
        "Ask 'Why?': If Event B happened BECAUSE of Event A, then A is Cause and B is Effect."
      ),
      commonMistakes = listOf(
        "Confusing temporal sequence with causation (post hoc ergo propter hoc)."
      ),
      solvedExamples = listOf(
        createExample(
          "ce_ex1",
          "Statement I: Heavy torrential rain lashed the city throughout the night.\nStatement II: Schools and colleges were declared closed for the day.",
          "कथन I: शहर में रात भर मूसलाधार बारिश हुई।\nकथन II: स्कूलों और कॉलेजों में अवकाश घोषित कर दिया गया।",
          listOf(
            "Step 1: Heavy rain caused flooding and transport breakdown.",
            "Step 2: School closure was the immediate safety response to the heavy rain.",
            "Step 3: Statement I is the Cause and Statement II is its Effect."
          ),
          "I is Cause, II is Effect",
          "Direct causation."
        ),
        createExample(
          "ce_ex2",
          "Statement I: Prices of vegetables rose sharply this week.\nStatement II: Transport truck drivers went on an indefinite strike across the state.",
          "कथन I: सब्जियों के दाम तेजी से बढ़े।\nकथन II: ट्रक चालकों ने हड़ताल कर दी।",
          listOf(
            "Step 1: Truck strike stopped the supply of fresh vegetables to markets.",
            "Step 2: Supply shortage caused vegetable prices to surge.",
            "Step 3: Statement II is the Cause and Statement I is its Effect."
          ),
          "II is Cause, I is Effect",
          "Supply disruption causes price rise."
        ),
        createExample(
          "ce_ex3",
          "Statement I: Most residents of the locality suffered from severe gastrointestinal illness.\nStatement II: The municipal drinking water pipeline had a contamination breach.",
          "कथन I: इलाके के अधिकांश लोग गैस्ट्रोइंटेस्टाइनल बीमारी से पीड़ित हुए।\nकथन II: पीने के पानी की पाइपलाइन में सीवेज का रिसाव हो गया।",
          listOf(
            "Step 1: Water contamination directly causes water-borne gastrointestinal illness.",
            "Step 2: Statement II is the Cause and Statement I is the Effect."
          ),
          "II is Cause, I is Effect",
          "Contaminated water causes illness."
        )
      ),
      practiceMcqs = listOf(
        createMcq("ce_q1", "I: Police increased night patrolling. II: Crime incidents dropped significantly.", "", "I is Cause, II is Effect", "II is Cause, I is Effect", "Common cause", "Independent causes", 0, "Patrolling caused deterrence and crime reduction."),
        createMcq("ce_q2", "I: RBI increased repo rate. II: Commercial banks raised home loan interest rates.", "", "I is Cause, II is Effect", "II is Cause, I is Effect", "Independent", "Common cause", 0, "Repo hike directly increases cost of funds for banks."),
        createMcq("ce_q3", "I: Farmers reported bumper wheat harvest. II: Government procured record wheat in granaries.", "", "I is Cause, II is Effect", "II is Cause", "Independent", "None", 0, "Bumper harvest led to record procurement."),
        createMcq("ce_q4", "I: Petrol prices increased. II: Air quality improved slightly.", "", "Independent causes", "I is Cause", "II is Cause", "Common cause", 0, "No direct causative link between these specific events."),
        createMcq("ce_q5", "I: Severe earthquake struck region. II: Buildings collapsed and thousands left homeless.", "", "I is Cause, II is Effect", "II is Cause", "Common cause", "Independent", 0, "Earthquake directly caused destruction."),
        createMcq("ce_q6", "I: Temperature soared above 45°C. II: Demand for air conditioners and power surged.", "", "I is Cause, II is Effect", "II is Cause", "Independent", "Common cause", 0, "High temperature caused AC usage and power demand."),
        createMcq("ce_q7", "I: Flight tickets became cheaper. II: Number of airline passengers increased by 30%.", "", "I is Cause, II is Effect", "II is Cause", "Independent", "Common cause", 0, "Lower fares stimulated passenger demand."),
        createMcq("ce_q8", "I: Massive fire broke out in warehouse. II: Fire brigade arrived with 15 fire tenders.", "", "I is Cause, II is Effect", "II is Cause", "Independent", "Common cause", 0, "Fire outbreak caused fire brigade dispatch."),
        createMcq("ce_q9", "I: Cyclone hit coastal town. II: Thousands evacuated to relief shelters.", "", "I is Cause, II is Effect", "II is Cause", "Common cause", "Independent", 0, "Cyclone arrival caused evacuation."),
        createMcq("ce_q10", "I: Monsoon was deficient by 40%. II: Irrigation dams recorded lowest water levels in decade.", "", "I is Cause, II is Effect", "II is Cause", "Independent", "Common cause", 0, "Deficient rainfall directly led to depleted dams.")
      )
    ),

    // 20. Data Sufficiency
    FormulaTopic(
      id = "reas_data_sufficiency",
      subject = FormulaSubject.REASONING,
      chapter = "Analytical Reasoning",
      title = "Data Sufficiency",
      hindiTitle = "आंकड़ों की पर्याप्तता",
      summary = "Evaluating whether Statement 1 alone, Statement 2 alone, both together, or neither is sufficient to answer.",
      coreFormula = "Options Grid:\n(A) Statement 1 ALONE is sufficient\n(B) Statement 2 ALONE is sufficient\n(C) EITHER Statement 1 alone OR Statement 2 alone is sufficient\n(D) NEITHER Statement 1 nor 2 is sufficient even together\n(E) BOTH Statements 1 and 2 TOGETHER are sufficient",
      symbolExplanations = listOf(
        "Unique Answer" to "Data is sufficient if and only if it leads to ONE unique definite value (not multiple values)."
      ),
      importantIdentities = listOf(
        "Never use Statement 2 information when evaluating Statement 1.",
        "Only combine Statement 1 and 2 if BOTH fail individually."
      ),
      shortcutsAndTips = listOf(
        "Do NOT solve completely; stop as soon as you confirm a unique solution exists."
      ),
      commonMistakes = listOf(
        "Combining both statements before checking if one statement alone was sufficient."
      ),
      solvedExamples = listOf(
        createExample(
          "ds_ex1",
          "Question: What is the value of x?\nStatement 1: x + y = 10\nStatement 2: 2x = 8",
          "प्रश्न: x का मान क्या है?\nकथन 1: x + y = 10\nकथन 2: 2x = 8",
          listOf(
            "Step 1: Check Statement 1 alone: x + y = 10. Infinite pairs of (x, y) exist. Not sufficient.",
            "Step 2: Check Statement 2 alone: 2x = 8 => x = 4. Gives a unique value for x. Sufficient.",
            "Step 3: Statement 2 alone is sufficient, while Statement 1 alone is not."
          ),
          "Statement 2 alone is sufficient",
          "Evaluate statements independently."
        ),
        createExample(
          "ds_ex2",
          "Question: Is integer n even?\nStatement 1: n is divisible by 4.\nStatement 2: n is divisible by 2.",
          "प्रश्न: क्या पूर्णांक n सम है?\nकथन 1: n, 4 से विभाज्य है।\nकथन 2: n, 2 से विभाज्य है।",
          listOf(
            "Step 1: Statement 1 alone: If n is divisible by 4, n is definitely even. Sufficient.",
            "Step 2: Statement 2 alone: If n is divisible by 2, n is definitely even. Sufficient.",
            "Step 3: Either Statement 1 alone or Statement 2 alone is sufficient."
          ),
          "Either 1 alone or 2 alone is sufficient",
          "Both provide independent answers."
        ),
        createExample(
          "ds_ex3",
          "Question: Among P, Q, R, who is the tallest?\nStatement 1: P is taller than Q.\nStatement 2: R is shorter than P.",
          "प्रश्न: P, Q, R में सबसे लंबा कौन है?\nकथन 1: P, Q से लंबा है।\nकथन 2: R, P से छोटा है।",
          listOf(
            "Step 1: From 1: P > Q. Doesn't mention R.",
            "Step 2: From 2: P > R. Doesn't mention Q.",
            "Step 3: Combine both: P > Q and P > R. P is strictly taller than both Q and R. P is the tallest.",
            "Step 4: Both statements together are sufficient."
          ),
          "Both together are sufficient",
          "Combine only after individual failure."
        )
      ),
      practiceMcqs = listOf(
        createMcq("ds_q1", "What is perimeter of rectangle? (1) Length is 10 cm. (2) Area is 50 cm².", "", "Both together sufficient", "1 alone", "2 alone", "Neither", 0, "From 1 & 2: b = 50/10 = 5. Perimeter = 2(10+5) = 30."),
        createMcq("ds_q2", "Is x > 0? (1) x² = 9. (2) x³ = 27.", "", "2 alone is sufficient", "1 alone", "Both", "Neither", 0, "From 1, x = ±3 (ambiguous). From 2, x = 3 > 0 (unique). 2 alone sufficient."),
        createMcq("ds_q3", "Who is oldest among A, B, C? (1) A is older than B. (2) C is younger than B.", "", "Both together sufficient", "1 alone", "2 alone", "Neither", 0, "A > B > C => A is oldest."),
        createMcq("ds_q4", "Find cost of 1 pen and 1 pencil. (1) 2 pens and 2 pencils cost ₹20. (2) 3 pens and 1 pencil cost ₹18.", "", "1 alone is sufficient", "2 alone", "Both", "Neither", 0, "From 1: 2(P + Pc) = 20 => P + Pc = ₹10. Unique answer from 1 alone!"),
        createMcq("ds_q5", "What is area of circle? (1) Circumference is 44 cm. (2) Diameter is 14 cm.", "", "Either 1 alone or 2 alone", "Both", "Neither", "1 alone", 0, "Both independently give radius r = 7 cm."),
        createMcq("ds_q6", "Is n prime? (1) n is odd. (2) n lies between 10 and 15.", "", "Both together NOT sufficient", "Both sufficient", "1 alone", "2 alone", 0, "Between 10 and 15, odd numbers are 11 (prime) and 13 (prime). Wait! Both are prime! So n must be prime! Sufficient."),
        createMcq("ds_q7", "Find average speed of car. (1) Covers 100 km in first half. (2) Total journey took 4 hours.", "", "Neither is sufficient", "Both", "1 alone", "2 alone", 0, "Total distance is unknown."),
        createMcq("ds_q8", "What is father's age? (1) Son is 15 years old. (2) Father is twice as old as son.", "", "Both together sufficient", "1 alone", "2 alone", "Neither", 0, "Father = 2 × 15 = 30 years."),
        createMcq("ds_q9", "Value of x + y? (1) 2x + 2y = 30. (2) x - y = 5.", "", "1 alone is sufficient", "2 alone", "Both", "Neither", 0, "1 gives 2(x + y) = 30 => x + y = 15."),
        createMcq("ds_q10", "Which day is holiday? (1) Month has 30 days. (2) Holiday is on 2nd Saturday.", "", "Neither is sufficient", "Both", "1 alone", "2 alone", 0, "Without knowing starting day of month, 2nd Saturday date cannot be determined.")
      )
    ),

    // 21. Non-Verbal Reasoning
    FormulaTopic(
      id = "reas_non_verbal",
      subject = FormulaSubject.REASONING,
      chapter = "Visual Reasoning",
      title = "Non-Verbal & Spatial Reasoning",
      hindiTitle = "अशाब्दिक तर्कशक्ति",
      summary = "Mirror and water images of figures, paper folding and cutting, embedded figures, dice dots, and pattern completion.",
      coreFormula = "Mirror Reflection: Left becomes Right, Right becomes Left (Top & Bottom remain unchanged)\nWater Reflection: Top becomes Bottom, Bottom becomes Top (Left & Right remain unchanged)\nDice Opposite Faces: In standard dice, sum of opposite faces = 7 (1-6, 2-5, 3-4)\nSingle Common Face Rule: Rotate clockwise from common face on both dice",
      symbolExplanations = listOf(
        "Standard Dice (मानक पासा)" to "Opposite faces sum to 7.",
        "General Dice (सामान्य पासा)" to "Adjacent faces can sum to 7. Use rotation rule."
      ),
      importantIdentities = listOf(
        "Symmetric figures along vertical axis look identical in mirror image (e.g. A, H, I, M, O, T, U, V, W, X, Y).",
        "Symmetric figures along horizontal axis look identical in water image (e.g. B, C, D, E, H, I, K, O, X)."
      ),
      shortcutsAndTips = listOf(
        "In paper cutting, unfold step by step in reverse order of folding, treating crease as mirror line."
      ),
      commonMistakes = listOf(
        "Inverting top and bottom in mirror image (only water image inverts vertically)."
      ),
      solvedExamples = listOf(
        createExample(
          "nv_ex1",
          "Two positions of a dice are shown: Position 1 has faces 1, 2, 3; Position 2 has faces 1, 4, 5. What face is opposite to 2?",
          "एक पासे की दो स्थितियाँ दिखाई गई हैं: (1, 2, 3) और (1, 4, 5)। फलक 2 के विपरीत कौन सा फलक है?",
          listOf(
            "Step 1: Common face is 1.",
            "Step 2: Rotate clockwise from 1 in first dice: 1 -> 2 -> 3.",
            "Step 3: Rotate clockwise from 1 in second dice: 1 -> 4 -> 5.",
            "Step 4: Opposite pairs: 2 is opposite 4, 3 is opposite 5, 1 is opposite 6."
          ),
          "4",
          "Clockwise rotation rule from common face."
        ),
        createExample(
          "nv_ex2",
          "A circular paper is folded in half, then folded again into a quarter, and a circular punch is made at the corner. How many holes appear when unfolded?",
          "एक गोलाकार कागज को दो बार मोड़ा जाता है और कोने पर एक छेद किया जाता है। खोलने पर कुल कितने छेद दिखेंगे?",
          listOf(
            "Step 1: Paper was folded twice: 1/2 then 1/4 (4 layers of paper).",
            "Step 2: A single hole punched through 4 layers produces 4 holes upon complete unfolding.",
            "Step 3: Total holes = 4."
          ),
          "4 holes",
          "Holes = 2^(number of folds)."
        ),
        createExample(
          "nv_ex3",
          "Which of the letters has identical mirror image: (A) B, (B) C, (C) M, (D) P?",
          "किस अक्षर का दर्पण प्रतिबिंब मूल अक्षर के समान होगा: (A) B, (B) C, (C) M, (D) P?",
          listOf(
            "Step 1: Letter M has vertical line of symmetry.",
            "Step 2: Left half of M is reflection of right half.",
            "Step 3: Its mirror image is identical to M."
          ),
          "M",
          "Vertical line symmetry."
        )
      ),
      practiceMcqs = listOf(
        createMcq("nv_q1", "In a standard dice, number opposite to 3 is:", "", "4", "5", "2", "6", 0, "Opposite faces sum to 7: 7 - 3 = 4."),
        createMcq("nv_q2", "Water image of letter 'E' is:", "", "E (identical)", "Inverted E", "3", "F", 0, "E has horizontal symmetry, so its water reflection is identical."),
        createMcq("nv_q3", "How many capital English alphabet letters have identical mirror images?", "", "11", "7", "8", "10", 0, "11 letters: A, H, I, M, O, T, U, V, W, X, Y."),
        createMcq("nv_q4", "A square sheet folded into 4 parts and 2 holes punched. Unfolded, it has:", "", "8 holes", "4 holes", "16 holes", "6 holes", 0, "4 layers × 2 holes = 8 holes."),
        createMcq("nv_q5", "If two faces 2 and 3 are common in two dice positions, remaining faces are:", "", "Opposite to each other", "Adjacent", "Equal", "None", 0, "Two common faces rule: remaining third faces are mutually opposite."),
        createMcq("nv_q6", "Mirror image inverts:", "", "Left and Right", "Top and Bottom", "Both", "Neither", 0, "Mirror reflection laterally inverts left and right."),
        createMcq("nv_q7", "Water image inverts:", "", "Top and Bottom", "Left and Right", "Both", "Neither", 0, "Water reflection vertically inverts top and bottom."),
        createMcq("nv_q8", "Total dots on a standard dice is:", "", "21", "20", "22", "18", 0, "1 + 2 + 3 + 4 + 5 + 6 = 21 dots."),
        createMcq("nv_q9", "Letter with both horizontal and vertical symmetry:", "", "H", "A", "B", "M", 0, "H has both vertical and horizontal symmetry axes (also X, I, O)."),
        createMcq("nv_q10", "A paper folded into 8 layers and 1 triangular cut made. Unfolded sheet contains:", "", "8 triangular cuts", "4 cuts", "16 cuts", "6 cuts", 0, "8 layers × 1 cut = 8 cuts.")
      )
    )
  )
}
