package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun VerifiedBadge(
  isVerified: Boolean,
  modifier: Modifier = Modifier
) {
  if (isVerified) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = modifier
        .testTag("verified_badge")
        .clip(RoundedCornerShape(6.dp))
        .background(Color(0xFFE0F2FE))
        .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
      Icon(
        imageVector = Icons.Default.CheckCircle,
        contentDescription = "Verified Content",
        tint = Color(0xFF0284C7),
        modifier = Modifier.size(13.dp)
      )
      Text(
        text = "VERIFIED EXAM SERIES",
        color = Color(0xFF0369A1),
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 4.dp),
        letterSpacing = 0.5.sp
      )
    }
  } else {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = modifier
        .testTag("demo_badge")
        .clip(RoundedCornerShape(6.dp))
        .background(Color(0xFFFFE4E6))
        .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
      Icon(
        imageVector = Icons.Default.Info,
        contentDescription = "Demo Content",
        tint = Color(0xFFE11D48),
        modifier = Modifier.size(13.dp)
      )
      Text(
        text = "DEMO PRACTICE SET",
        color = Color(0xFFBE123C),
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 4.dp),
        letterSpacing = 0.5.sp
      )
    }
  }
}

@Composable
fun SourceLabelBadge(
  sourceLabel: String,
  modifier: Modifier = Modifier
) {
  val (bgColor, textColor, labelText, iconTint) = when (sourceLabel) {
    "OFFICIAL_VERIFIED_PYQ" -> Quadruple(
      Color(0xFFE0F2FE),
      Color(0xFF0369A1),
      "OFFICIAL VERIFIED PYQ",
      Color(0xFF0284C7)
    )
    "AI_GENERATED",
    "AI_GENERATED_PRACTICE" -> Quadruple(
      Color(0xFFF3E8FF),
      Color(0xFF7E22CE),
      "AI-GENERATED PRACTICE",
      Color(0xFF9333EA)
    )
    else -> Quadruple(
      Color(0xFFFEF3C7),
      Color(0xFFB45309),
      "NEEDS REVIEW",
      Color(0xFFD97706)
    )
  }

  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = modifier
      .testTag("source_label_badge_${sourceLabel.lowercase()}")
      .clip(RoundedCornerShape(6.dp))
      .background(bgColor)
      .padding(horizontal = 7.dp, vertical = 2.5.dp)
  ) {
    Icon(
      imageVector = if (sourceLabel == "OFFICIAL_VERIFIED_PYQ") Icons.Default.CheckCircle else Icons.Default.Info,
      contentDescription = labelText,
      tint = iconTint,
      modifier = Modifier.size(11.dp)
    )
    Text(
      text = labelText,
      color = textColor,
      fontSize = 9.5.sp,
      fontWeight = FontWeight.Bold,
      modifier = Modifier.padding(start = 4.dp),
      letterSpacing = 0.4.sp
    )
  }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
