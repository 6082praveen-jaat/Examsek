package com.example.data.formula

import com.example.domain.formula.FormulaSubject
import com.example.domain.formula.FormulaTopic
import com.example.data.formula.FormulaTopicBuilder.createExample
import com.example.data.formula.FormulaTopicBuilder.createMcq

object MathTopicsPart1 {

  val topics: List<FormulaTopic> = listOf(
    // 1. Number System
    FormulaTopic(
      id = "math_number_system",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Arithmetic",
      title = "Number System",
      hindiTitle = "संख्या पद्धति",
      summary = "Divisibility rules, unit digit calculation, remainder theorem, and classification of numbers.",
      coreFormula = "Dividend = (Divisor × Quotient) + Remainder\nSum of first n natural numbers = [n(n + 1)] / 2\nSum of squares = [n(n + 1)(2n + 1)] / 6",
      symbolExplanations = listOf(
        "Dividend (भाज्य)" to "The number being divided (N). Must be >= 0.",
        "Divisor (भाजक)" to "The number dividing (d). d ≠ 0.",
        "Quotient (भागफल)" to "Number of times divisor fits into dividend (q).",
        "Remainder (शेषफल)" to "Leftover value (r). Condition: 0 ≤ r < d.",
        "n" to "Number of consecutive natural numbers (positive integers)."
      ),
      importantIdentities = listOf(
        "Unit digit of a^b repeats every 4 powers (cyclicity of 4).",
        "Divisibility by 3 & 9: Sum of digits must be divisible by 3 or 9.",
        "Divisibility by 11: Difference between sum of odd placed digits and even placed digits is 0 or multiple of 11.",
        "Number of factors of N = p^a × q^b × r^c is (a + 1)(b + 1)(c + 1)."
      ),
      shortcutsAndTips = listOf(
        "To find unit digit of 7^95: 95 mod 4 = 3, so unit digit is same as 7^3 = 3.",
        "Sum of first n odd numbers is always n².",
        "Sum of first n even numbers is n(n + 1)."
      ),
      commonMistakes = listOf(
        "Forgetting that 1 is neither prime nor composite.",
        "Confusing 0 as a positive integer; 0 is an even integer but neither positive nor negative.",
        "Taking negative remainder directly without converting: (-3 mod 7) = 4."
      ),
      solvedExamples = listOf(
        createExample(
          "ns_ex1",
          "Find the unit digit in (7^105).",
          "(7^105) में इकाई का अंक ज्ञात कीजिए।",
          listOf(
            "Step 1: The unit digit of powers of 7 has a cyclicity of 4 (7¹=7, 7²=9, 7³=3, 7⁴=1).",
            "Step 2: Divide the exponent 105 by 4: 105 ÷ 4 gives remainder 1.",
            "Step 3: Therefore, unit digit is 7¹ = 7."
          ),
          "7",
          "Directly look at last two digits of exponent for mod 4."
        ),
        createExample(
          "ns_ex2",
          "A number when divided by 899 gives a remainder 63. What will be the remainder when the same number is divided by 29?",
          "एक संख्या को 899 से भाग देने पर शेषफल 63 प्राप्त होता है। उसी संख्या को 29 से भाग देने पर क्या शेषफल प्राप्त होगा?",
          listOf(
            "Step 1: Check if the first divisor (899) is a multiple of the second divisor (29). 899 ÷ 29 = 31 (exact multiple).",
            "Step 2: Directly divide the previous remainder (63) by 29.",
            "Step 3: 63 = (29 × 2) + 5. Remainder is 5."
          ),
          "5",
          "Shortcut: New Remainder = (Old Remainder) mod (New Divisor) when first divisor is multiple."
        ),
        createExample(
          "ns_ex3",
          "Find the sum of all natural numbers from 1 to 50.",
          "1 से 50 तक की सभी प्राकृतिक संख्याओं का योग ज्ञात कीजिए।",
          listOf(
            "Step 1: Use the formula S = [n(n + 1)] / 2 where n = 50.",
            "Step 2: S = [50 × 51] / 2 = 25 × 51.",
            "Step 3: 25 × 51 = 1275."
          ),
          "1275",
          "Multiply 51 by 100 then divide by 4: 5100 / 4 = 1275."
        )
      ),
      practiceMcqs = listOf(
        createMcq("ns_q1", "What is the unit digit of (3^65 × 6^59 × 7^71)?", "", "1", "2", "4", "6", 2, "Unit digits: 3^65 -> 3^1=3; 6^59 -> 6; 7^71 -> 7^3=3. Product = 3 × 6 × 3 = 54 -> Unit digit is 4."),
        createMcq("ns_q2", "If 78*3945 is divisible by 11, what digit replaces *?", "", "1", "3", "5", "0", 2, "Sum odd = 5+9+*+7 = 21+*; Sum even = 4+3+8 = 15. Difference = (21+*)-15 = 6+*. For divisibility by 11, 6+* = 11 => * = 5."),
        createMcq("ns_q3", "The sum of the first 20 odd natural numbers is:", "", "200", "400", "420", "210", 1, "Sum of first n odd numbers = n² = 20² = 400."),
        createMcq("ns_q4", "How many total prime factors does 240 have?", "", "4", "5", "6", "8", 1, "240 = 2⁴ × 3¹ × 5¹. Total prime factors = 4 + 1 + 1 = 6 (Distinct are 3: 2, 3, 5)."),
        createMcq("ns_q5", "Find the remainder when 2^31 is divided by 5.", "", "1", "2", "3", "4", 2, "2^31 = 2^(4×7 + 3) = (16^7 × 8). 16 mod 5 = 1, so 1^7 × 8 = 8. 8 mod 5 = 3."),
        createMcq("ns_q6", "Which of the following is a prime number?", "", "119", "187", "247", "173", 3, "119 = 7×17; 187 = 11×17; 247 = 13×19; 173 has no divisor up to √173 (13.1), so 173 is prime."),
        createMcq("ns_q7", "Sum of squares of first 10 natural numbers is:", "", "385", "505", "285", "345", 0, "[n(n+1)(2n+1)]/6 = [10×11×21]/6 = 385."),
        createMcq("ns_q8", "A number divided by 13 gives quotient 24 and remainder 5. The number is:", "", "317", "312", "307", "325", 0, "Number = 13 × 24 + 5 = 312 + 5 = 317."),
        createMcq("ns_q9", "How many trailing zeroes are there in 100!?", "", "20", "24", "25", "28", 1, "Trailing zeros = [100/5] + [100/25] = 20 + 4 = 24."),
        createMcq("ns_q10", "What is the smallest 4-digit number completely divisible by 18?", "", "1008", "1000", "1018", "1026", 0, "1000 ÷ 18 = 55 rem 10. Required number = 1000 + (18 - 10) = 1008.")
      )
    ),

    // 2. Simplification
    FormulaTopic(
      id = "math_simplification",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Arithmetic",
      title = "Simplification & VBODMAS",
      hindiTitle = "सरलीकरण",
      summary = "Order of mathematical operations, algebraic identities, and square/cube roots simplification.",
      coreFormula = "VBODMAS: Vinculum -> Brackets -> Of -> Division -> Multiplication -> Addition -> Subtraction\n(a + b)² = a² + 2ab + b²\n(a - b)² = a² - 2ab + b²\na² - b² = (a - b)(a + b)\na³ + b³ = (a + b)(a² - ab + b²)",
      symbolExplanations = listOf(
        "V" to "Vinculum (Bar bracket, e.g. 5 - 3). Evaluated first.",
        "B" to "Brackets: () first, then {}, then [].",
        "O" to "Of (का), which denotes multiplication with higher precedence than division.",
        "D / M" to "Division and Multiplication (equal precedence, evaluated left to right).",
        "A / S" to "Addition and Subtraction (evaluated left to right)."
      ),
      importantIdentities = listOf(
        "(a + b)³ = a³ + b³ + 3ab(a + b)",
        "If a + b + c = 0, then a³ + b³ + c³ = 3abc",
        "(a + b + c)² = a² + b² + c² + 2(ab + bc + ca)"
      ),
      shortcutsAndTips = listOf(
        "Convert mixed fractions to improper fractions: a (b/c) = (ac + b) / c.",
        "Recognize algebraic patterns: e.g. (a³ + b³) / (a² - ab + b²) = a + b."
      ),
      commonMistakes = listOf(
        "Performing division before 'Of': In '40 ÷ 2 of 5', evaluate '2 of 5 = 10' first, giving 40 ÷ 10 = 4 (not 20 × 5 = 100).",
        "Forgetting sign change when removing a minus sign before brackets: -(a - b) = -a + b."
      ),
      solvedExamples = listOf(
        createExample(
          "simp_ex1",
          "Simplify: 25 - 5 × 2 + 3 of 4 ÷ 2",
          "सरल कीजिए: 25 - 5 × 2 + 3 of 4 ÷ 2",
          listOf(
            "Step 1: Apply 'Of': 3 of 4 = 12. Expression becomes 25 - 5 × 2 + 12 ÷ 2.",
            "Step 2: Division: 12 ÷ 2 = 6. Expression: 25 - 5 × 2 + 6.",
            "Step 3: Multiplication: 5 × 2 = 10. Expression: 25 - 10 + 6.",
            "Step 4: Addition & Subtraction from left to right: 25 - 10 + 6 = 15 + 6 = 21."
          ),
          "21",
          "Remember: 'Of' comes strictly before 'Division'."
        ),
        createExample(
          "simp_ex2",
          "Evaluate: (0.73 × 0.73 × 0.73 + 0.27 × 0.27 × 0.27) / (0.73 × 0.73 - 0.73 × 0.27 + 0.27 × 0.27)",
          "मान ज्ञात कीजिए: (0.73³ + 0.27³) / (0.73² - 0.73×0.27 + 0.27²)",
          listOf(
            "Step 1: Recognize identity (a³ + b³) / (a² - ab + b²).",
            "Step 2: Since a³ + b³ = (a + b)(a² - ab + b²), the expression simplifies directly to (a + b).",
            "Step 3: Here a = 0.73 and b = 0.27. Result = 0.73 + 0.27 = 1.00."
          ),
          "1.00",
          "Direct algebraic identity cancellation saves lengthy decimal multiplications."
        ),
        createExample(
          "simp_ex3",
          "Simplify: 18 - [6 - {4 - (8 - 6 - 3 with bar on 6-3)}]",
          "सरल कीजिए: 18 - [6 - {4 - (8 - (6 - 3))}]",
          listOf(
            "Step 1: Vinculum first: 6 - 3 = 3.",
            "Step 2: Parentheses: 8 - 3 = 5.",
            "Step 3: Curly bracket: 4 - 5 = -1.",
            "Step 4: Square bracket: 6 - (-1) = 7.",
            "Step 5: Final subtraction: 18 - 7 = 11."
          ),
          "11",
          "Evaluate from innermost brackets outward."
        )
      ),
      practiceMcqs = listOf(
        createMcq("simp_q1", "Simplify: 12 + 6 × 3 - 8 ÷ 2", "", "22", "26", "24", "18", 1, "8 ÷ 2 = 4, 6 × 3 = 18. 12 + 18 - 4 = 26."),
        createMcq("simp_q2", "Evaluate: 48 ÷ 12 of 2 + [15 - (6 - 2)]", "", "13", "15", "11", "9", 0, "12 of 2 = 24. 48 ÷ 24 = 2. Bracket: 15 - 4 = 11. 2 + 11 = 13."),
        createMcq("simp_q3", "If a = 16 and b = 5, find (a² - b²) / (a - b):", "", "21", "11", "26", "80", 0, "(a² - b²)/(a - b) = a + b = 16 + 5 = 21."),
        createMcq("simp_q4", "Find the value of √(10 + √(25 + √(108 + √(169))))", "", "4", "5", "6", "3", 0, "√169=13; 108+13=121, √121=11; 25+11=36, √36=6; 10+6=16, √16=4."),
        createMcq("simp_q5", "(a - b)³ + (b - c)³ + (c - a)³ equals:", "", "0", "3(a - b)(b - c)(c - a)", "3abc", "(a+b+c)³", 1, "If x + y + z = 0, then x³ + y³ + z³ = 3xyz. Here (a-b)+(b-c)+(c-a) = 0."),
        createMcq("simp_q6", "Value of 1 / (1 + 1 / (1 + 1/3)) is:", "", "4/7", "7/4", "3/7", "3/4", 0, "1 + 1/3 = 4/3. 1/(4/3) = 3/4. 1 + 3/4 = 7/4. 1/(7/4) = 4/7."),
        createMcq("simp_q7", "Simplify: 0.87 × 0.87 + 0.13 × 0.13 + 2 × 0.87 × 0.13", "", "1.0", "0.74", "0.98", "1.2", 0, "Formula is (a + b)² = (0.87 + 0.13)² = 1² = 1.0."),
        createMcq("simp_q8", "What is 35% of 240 + 45% of 160?", "", "156", "148", "162", "142", 0, "35% of 240 = 84; 45% of 160 = 72; 84 + 72 = 156."),
        createMcq("simp_q9", "Evaluate: 7 × 7 ÷ 7 × 7 - 7 + 7", "", "49", "1", "0", "7", 0, "7 ÷ 7 = 1; 7 × 1 × 7 = 49; 49 - 7 + 7 = 49."),
        createMcq("simp_q10", "If (x + 1/x) = 3, then (x² + 1/x²) is:", "", "7", "9", "11", "6", 0, "x² + 1/x² = 3² - 2 = 7.")
      )
    ),

    // 3. HCF and LCM
    FormulaTopic(
      id = "math_hcf_lcm",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Arithmetic",
      title = "HCF and LCM",
      hindiTitle = "म.स.प. एवं ल.स.प.",
      summary = "Highest Common Factor and Least Common Multiple of integers and fractions.",
      coreFormula = "Product of two numbers = HCF × LCM\nHCF of fractions = (HCF of Numerators) / (LCM of Denominators)\nLCM of fractions = (LCM of Numerators) / (HCF of Denominators)",
      symbolExplanations = listOf(
        "HCF (म.स.प.)" to "Highest Common Factor, greatest integer dividing all given numbers.",
        "LCM (ल.स.प.)" to "Lowest Common Multiple, smallest positive integer divisible by all given numbers.",
        "Co-prime numbers" to "Two numbers whose HCF is 1 (e.g., 8 and 15)."
      ),
      importantIdentities = listOf(
        "If HCF of two numbers is H, numbers can be represented as Hx and Hy where x and y are co-prime.",
        "LCM = H × x × y.",
        "Smallest number which when divided by a, b, c leaves remainder r = [LCM(a, b, c) × k] + r."
      ),
      shortcutsAndTips = listOf(
        "HCF of two numbers divides their difference.",
        "LCM is always a multiple of HCF."
      ),
      commonMistakes = listOf(
        "Using HCF × LCM = Product for THREE numbers (only holds true for two numbers).",
        "Reversing numerator and denominator rules for fraction HCF/LCM."
      ),
      solvedExamples = listOf(
        createExample(
          "hl_ex1",
          "The HCF of two numbers is 11 and their LCM is 7700. If one number is 275, find the other.",
          "दो संख्याओं का म.स.प. 11 तथा ल.स.प. 7700 है। यदि एक संख्या 275 है, तो दूसरी संख्या ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula: Product of two numbers = HCF × LCM.",
            "Step 2: Let the other number be Y. Then 275 × Y = 11 × 7700.",
            "Step 3: Y = (11 × 7700) / 275 = 7700 / 25 = 308."
          ),
          "308",
          "Divide 7700 by 25: 77 × 4 = 308."
        ),
        createExample(
          "hl_ex2",
          "Find the HCF of fractions 2/3, 8/9, 16/81, and 10/27.",
          "भिन्न 2/3, 8/9, 16/81 तथा 10/27 का म.स.प. ज्ञात कीजिए।",
          listOf(
            "Step 1: HCF of fractions = HCF(Numerators) / LCM(Denominators).",
            "Step 2: Numerators are 2, 8, 16, 10. Their HCF = 2.",
            "Step 3: Denominators are 3, 9, 81, 27. Their LCM = 81.",
            "Step 4: HCF = 2/81."
          ),
          "2/81",
          "Always apply HCF to numerators and LCM to denominators."
        ),
        createExample(
          "hl_ex3",
          "Four bells ring at intervals of 6, 8, 12, and 18 seconds. If they toll together at 12:00 PM, when will they toll together next?",
          "चार घंटियाँ 6, 8, 12 और 18 सेकंड के अंतराल पर बजती हैं। वे अगली बार एक साथ कब बजेंगी?",
          listOf(
            "Step 1: The time interval is the LCM of 6, 8, 12, and 18.",
            "Step 2: Prime factorizations: 6 = 2×3, 8 = 2³, 12 = 2²×3, 18 = 2×3².",
            "Step 3: LCM = 2³ × 3² = 8 × 9 = 72 seconds.",
            "Step 4: 72 seconds = 1 minute and 12 seconds.",
            "Step 5: They toll together next at 12:01:12 PM."
          ),
          "12:01:12 PM",
          "Any recurring simultaneous event problem uses LCM."
        )
      ),
      practiceMcqs = listOf(
        createMcq("hl_q1", "Find the HCF of 108, 288, and 360.", "", "18", "36", "72", "24", 1, "108=36×3, 288=36×8, 360=36×10. Common factor is 36."),
        createMcq("hl_q2", "Find the LCM of 24, 36, and 40.", "", "240", "360", "480", "180", 1, "24=2³×3, 36=2²×3², 40=2³×5. LCM = 2³×3²×5 = 8×9×5 = 360."),
        createMcq("hl_q3", "Two numbers are in the ratio 3:4 and their HCF is 4. Find their LCM.", "", "36", "48", "60", "24", 1, "Numbers are 3×4=12 and 4×4=16. LCM = 12 × 16 / 4 = 48."),
        createMcq("hl_q4", "LCM of two co-prime numbers is always equal to:", "", "1", "Their difference", "Their sum", "Their product", 3, "Since HCF of co-prime numbers is 1, LCM × 1 = Product."),
        createMcq("hl_q5", "Find the smallest number which leaves remainder 3 when divided by 6, 9, 12.", "", "39", "36", "33", "42", 0, "LCM(6, 9, 12) = 36. Required number = 36 + 3 = 39."),
        createMcq("hl_q6", "Find LCM of 2/3, 3/5, 4/7.", "", "12", "6", "12/105", "24", 0, "LCM = LCM(2,3,4)/HCF(3,5,7) = 12 / 1 = 12."),
        createMcq("hl_q7", "The ratio of two numbers is 5:6 and their LCM is 480. The HCF is:", "", "16", "20", "24", "12", 0, "LCM = HCF × 5 × 6 = 30 × HCF. HCF = 480 / 30 = 16."),
        createMcq("hl_q8", "What is the largest 3-digit number completely divisible by 12, 15, and 18?", "", "960", "900", "990", "920", 1, "LCM(12, 15, 18) = 180. Highest 3-digit multiple = 180 × 5 = 900."),
        createMcq("hl_q9", "HCF of two numbers is 8. Which of the following can NEVER be their LCM?", "", "24", "48", "56", "60", 3, "LCM must be an exact multiple of HCF. 60 is not divisible by 8."),
        createMcq("hl_q10", "Find the HCF of 0.54, 1.8, and 7.2.", "", "0.18", "0.09", "1.8", "0.018", 0, "Convert to 54/100, 180/100, 720/100. HCF(54, 180, 720) = 18. Result = 18/100 = 0.18.")
      )
    ),

    // 4. Fractions and Decimals
    FormulaTopic(
      id = "math_fractions_decimals",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Arithmetic",
      title = "Fractions and Decimals",
      hindiTitle = "भिन्न एवं दशमलव",
      summary = "Types of fractions, recurring decimals conversion, comparison, and continued fractions.",
      coreFormula = "Pure Recurring Decimal: 0.ā = a / 9, 0.āb̄ = ab / 99\nMixed Recurring Decimal: 0.ab̄ = (ab - a) / 90\nComparison by Cross Multiplication: a/b > c/d if ad > bc",
      symbolExplanations = listOf(
        "Numerator (अंश)" to "Upper number indicating parts taken.",
        "Denominator (हर)" to "Lower number indicating total equal parts.",
        "Recurring Decimal (आवर्ती दशमलव)" to "Decimals with infinite periodic repeating digits."
      ),
      importantIdentities = listOf(
        "0.abc̄ = (abc - ab) / 900",
        "Proper fraction: Numerator < Denominator (value < 1)",
        "Improper fraction: Numerator > Denominator (value > 1)"
      ),
      shortcutsAndTips = listOf(
        "To compare fractions, convert to decimal or use cross multiplication.",
        "Adding same positive constant to numerator and denominator of proper fraction increases its value."
      ),
      commonMistakes = listOf(
        "Forgetting to subtract non-repeating part in mixed recurring decimal formula.",
        "Putting 10 in denominator instead of 9 for recurring digits."
      ),
      solvedExamples = listOf(
        createExample(
          "frac_ex1",
          "Convert 0.2343434... (0.23̄4̄) into a vulgar fraction in simplest form.",
          "0.23̄4̄ को साधारण भिन्न में बदलिए।",
          listOf(
            "Step 1: Formula for 0.ab̄c̄ = (abc - a) / 990.",
            "Step 2: Here the whole number is 234 and non-repeating digit is 2.",
            "Step 3: Numerator = 234 - 2 = 232.",
            "Step 4: Denominator = two 9's for repeating digits and one 0 for non-repeating = 990.",
            "Step 5: Reduce 232/990 by dividing by 2 = 116/495."
          ),
          "116/495",
          "Subtract non-repeating part from the total number."
        ),
        createExample(
          "frac_ex2",
          "Which fraction is greater: 5/8 or 7/11?",
          "5/8 और 7/11 में से कौन सी भिन्न बड़ी है?",
          listOf(
            "Step 1: Cross multiply: 5 × 11 = 55.",
            "Step 2: Cross multiply other pair: 8 × 7 = 56.",
            "Step 3: Since 56 > 55, 7/11 > 5/8."
          ),
          "7/11",
          "Cross multiplication is much faster than LCM."
        ),
        createExample(
          "frac_ex3",
          "Evaluate 2.3̄ + 3.4̄ + 4.5̄",
          "2.3̄ + 3.4̄ + 4.5̄ का मान ज्ञात कीजिए।",
          listOf(
            "Step 1: Convert each: 2 + 3/9, 3 + 4/9, 4 + 5/9.",
            "Step 2: Add integers: 2 + 3 + 4 = 9.",
            "Step 3: Add fractional parts: (3 + 4 + 5) / 9 = 12/9 = 1 + 3/9.",
            "Step 4: Total = 9 + 1 + 3/9 = 10 + 1/3 = 10.3̄."
          ),
          "10.3̄ (or 31/3)",
          "Separate integer and fractional recurring parts."
        )
      ),
      practiceMcqs = listOf(
        createMcq("frac_q1", "Express 0.57̄ as a fraction in simplest form:", "", "26/45", "57/99", "19/33", "52/90", 0, "0.57̄ = (57 - 5)/90 = 52/90 = 26/45."),
        createMcq("frac_q2", "Which is the largest among 3/4, 5/6, 7/8, 9/10?", "", "3/4", "5/6", "7/8", "9/10", 3, "Difference between numerator and denominator is 1 for all. The one with largest terms (9/10) is largest."),
        createMcq("frac_q3", "Value of 0.63̄ + 0.37̄ is:", "", "1.0", "1.01̄", "100/99", "99/100", 2, "63/99 + 37/99 = 100/99 = 1.0101..."),
        createMcq("frac_q4", "Convert 0.125 into fraction:", "", "1/8", "1/4", "1/5", "3/8", 0, "125/1000 = 1/8."),
        createMcq("frac_q5", "If 3/5 of a number is 24, what is 2/3 of that number?", "", "20", "24", "26.6", "40", 2, "Number = 24 × 5/3 = 40. 2/3 of 40 = 80/3 = 26.67."),
        createMcq("frac_q6", "A terminating decimal has prime factors in denominator only of:", "", "2 and 3", "2 and 5", "3 and 5", "Only 2", 1, "A fraction terminates if and only if denominator has factors 2^m × 5^n."),
        createMcq("frac_q7", "Find the reciprocal of (3/4 - 1/2):", "", "4", "1/4", "2", "1/2", 0, "3/4 - 1/2 = 1/4. Reciprocal = 4."),
        createMcq("frac_q8", "Evaluate 0.4̄ × 0.9̄:", "", "0.4", "4/9", "0.36", "0.44", 1, "0.4̄ = 4/9, 0.9̄ = 9/9 = 1. 4/9 × 1 = 4/9."),
        createMcq("frac_q9", "Arrange ascending: 2/3, 3/5, 7/10.", "", "3/5 < 2/3 < 7/10", "2/3 < 3/5 < 7/10", "7/10 < 2/3 < 3/5", "3/5 < 7/10 < 2/3", 0, "3/5=0.60, 2/3=0.66, 7/10=0.70. Ascending: 3/5 < 2/3 < 7/10."),
        createMcq("frac_q10", "What fraction of an hour is a second?", "", "1/60", "1/120", "1/3600", "1/1800", 2, "1 hour = 3600 seconds, so 1 second = 1/3600 hour.")
      )
    ),

    // 5. Percentage
    FormulaTopic(
      id = "math_percentage",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Arithmetic",
      title = "Percentage",
      hindiTitle = "प्रतिशत",
      summary = "Fraction-percentage equivalences, net change formula, and expenditure-consumption relations.",
      coreFormula = "Percentage = (Part / Total) × 100\nNet Percentage Change = a + b + (ab / 100)%\nPrice rise by r%: Reduction in consumption = [r / (100 + r)] × 100%\nPrice fall by r%: Increase in consumption = [r / (100 - r)] × 100%",
      symbolExplanations = listOf(
        "a, b" to "Two successive percentage changes (+ for increase, - for decrease).",
        "r" to "Percentage change in price or rate."
      ),
      importantIdentities = listOf(
        "Fraction table: 1/2 = 50%, 1/3 = 33.33%, 1/4 = 25%, 1/5 = 20%, 1/6 = 16.67%, 1/7 = 14.28%, 1/8 = 12.5%, 1/9 = 11.11%, 1/11 = 9.09%, 1/12 = 8.33%."
      ),
      shortcutsAndTips = listOf(
        "If A is r% more than B, B is [r / (100 + r)] × 100% less than A.",
        "If a quantity increases by x% and then decreases by x%, net result is ALWAYS a decrease of (x²/100)%."
      ),
      commonMistakes = listOf(
        "Assuming a 20% increase followed by a 20% decrease leaves the original value unchanged (it drops by 4%).",
        "Confusing percentage points with percentage change."
      ),
      solvedExamples = listOf(
        createExample(
          "perc_ex1",
          "If the price of sugar increases by 25%, by what percent must a household reduce consumption to keep expenditure constant?",
          "यदि चीनी के मूल्य में 25% की वृद्धि हो जाए, तो एक परिवार को खपत में कितने प्रतिशत की कमी करनी होगी?",
          listOf(
            "Step 1: Formula: Reduction % = [r / (100 + r)] × 100.",
            "Step 2: Here r = 25.",
            "Step 3: Reduction % = [25 / (100 + 25)] × 100 = (25 / 125) × 100 = 20%."
          ),
          "20%",
          "Since 25% = 1/4 increase, consumption must decrease by 1/(4+1) = 1/5 = 20%."
        ),
        createExample(
          "perc_ex2",
          "The population of a town increased by 10% in the first year and decreased by 10% in the second year. Find net change percent.",
          "एक कस्बे की जनसंख्या पहले वर्ष 10% बढ़ी तथा दूसरे वर्ष 10% घटी। कुल प्रतिशत परिवर्तन ज्ञात कीजिए।",
          listOf(
            "Step 1: Apply net change formula: a + b + (ab / 100).",
            "Step 2: Here a = +10, b = -10.",
            "Step 3: Net change = 10 - 10 + (10 × -10) / 100 = -1% (1% decrease)."
          ),
          "1% decrease",
          "Net change for +x% and -x% is always -x²/100%."
        ),
        createExample(
          "perc_ex3",
          "In an exam, 35% candidates failed in Hindi and 45% in English. If 20% failed in both, find the percentage of candidates who passed in both.",
          "एक परीक्षा में 35% छात्र हिंदी में तथा 45% अंग्रेजी में अनुत्तीर्ण हुए। यदि 20% दोनों में अनुत्तीर्ण हुए, तो दोनों में उत्तीर्ण छात्रों का प्रतिशत ज्ञात कीजिए।",
          listOf(
            "Step 1: Total failed in at least one subject = n(H ∪ E) = n(H) + n(E) - n(H ∩ E).",
            "Step 2: Total failed = 35% + 45% - 20% = 60%.",
            "Step 3: Candidates passed in both = 100% - 60% = 40%."
          ),
          "40%",
          "Use Set Theory Venn Diagram logic."
        )
      ),
      practiceMcqs = listOf(
        createMcq("perc_q1", "What is 20% of 25% of 300?", "", "15", "12", "18", "20", 0, "(20/100) × (25/100) × 300 = 1/5 × 1/4 × 300 = 15."),
        createMcq("perc_q2", "If A's salary is 50% more than B, then B's salary is how much % less than A?", "", "33.33%", "50%", "25%", "40%", 0, "[50 / (100 + 50)] × 100 = 50/150 × 100 = 33.33%."),
        createMcq("perc_q3", "Two successive discounts of 20% and 10% are equivalent to a single discount of:", "", "30%", "28%", "25%", "22%", 1, "Net discount = 20 + 10 - (20×10)/100 = 30 - 2 = 28%."),
        createMcq("perc_q4", "A candidate scores 40% marks and fails by 20 marks. Another candidate scores 50% and gets 30 marks more than pass marks. Maximum marks are:", "", "500", "400", "600", "450", 0, "Difference: 50% - 40% = 10%. Mark gap = 20 + 30 = 50. 10% = 50 => 100% = 500."),
        createMcq("perc_q5", "If length of rectangle increases by 20% and breadth increases by 10%, area increases by:", "", "30%", "32%", "35%", "28%", 1, "20 + 10 + (20×10)/100 = 32%."),
        createMcq("perc_q6", "Fresh fruit contains 68% water and dry fruit contains 20% water. How much dry fruit can be obtained from 100 kg fresh fruit?", "", "32 kg", "40 kg", "50 kg", "60 kg", 1, "Pulp in fresh = 32% of 100 = 32 kg. Pulp in dry = 80%. 80% of D = 32 => D = 32 / 0.8 = 40 kg."),
        createMcq("perc_q7", "If price of petrol increases by 20%, by what percent must consumption decrease so expenditure increases by only 8%?", "", "10%", "12%", "15%", "8%", 0, "100 -> 120 (price). Target expenditure = 108. Reduction = (120 - 108)/120 × 100 = 10%."),
        createMcq("perc_q8", "If 80% of A = 50% of B and B = x% of A, then x is:", "", "160", "150", "125", "140", 0, "8A = 5B => B/A = 8/5. x = (8/5) × 100 = 160."),
        createMcq("perc_q9", "A number is increased by 20% and then decreased by 20%. The net change is:", "", "0%", "4% increase", "4% decrease", "2% decrease", 2, "-(20² / 100)% = -4%."),
        createMcq("perc_q10", "If 15% of (A + B) = 25% of (A - B), then what percent of B is equal to A?", "", "400%", "250%", "300%", "200%", 0, "3(A+B) = 5(A-B) => 3A + 3B = 5A - 5B => 2A = 8B => A = 4B. A is 400% of B.")
      )
    ),

    // 6. Ratio and Proportion
    FormulaTopic(
      id = "math_ratio_proportion",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Arithmetic",
      title = "Ratio and Proportion",
      hindiTitle = "अनुपात एवं समानुपात",
      summary = "Combining ratios, mean, third and fourth proportionals, and coin-based problems.",
      coreFormula = "Proportion: a : b :: c : d  <=>  a × d = b × c\nMean Proportional between a and b = √(ab)\nThird Proportional to a and b = b² / a\nFourth Proportional to a, b, c = (b × c) / a",
      symbolExplanations = listOf(
        "a, b" to "Antecedent (first term) and Consequent (second term).",
        "a, d" to "Extremes (चरम पद).",
        "b, c" to "Means (मध्य पद)."
      ),
      importantIdentities = listOf(
        "Combining: If A:B = x:y and B:C = m:n, then A:B:C = (x×m) : (y×m) : (y×n)",
        "Invertendo: If a/b = c/d, then b/a = d/c",
        "Componendo and Dividendo: If a/b = c/d, then (a + b)/(a - b) = (c + d)/(c - d)"
      ),
      shortcutsAndTips = listOf(
        "Use Componendo and Dividendo whenever equations have symmetric (x+a)/(x-a) terms."
      ),
      commonMistakes = listOf(
        "Directly adding ratios: If boys:girls is 2:3 and 3:4 in two classes, total ratio is NOT (2+3):(3+4) unless class sizes are equal."
      ),
      solvedExamples = listOf(
        createExample(
          "rp_ex1",
          "If A : B = 2 : 3 and B : C = 4 : 5, find A : B : C.",
          "यदि A : B = 2 : 3 तथा B : C = 4 : 5 हो, तो A : B : C ज्ञात कीजिए।",
          listOf(
            "Step 1: Multiply A:B by 4: (2×4) : (3×4) = 8 : 12.",
            "Step 2: Multiply B:C by 3: (4×3) : (5×3) = 12 : 15.",
            "Step 3: Combine with common B=12: A : B : C = 8 : 12 : 15."
          ),
          "8 : 12 : 15",
          "A : B : C = (2×4) : (3×4) : (3×5) = 8 : 12 : 15."
        ),
        createExample(
          "rp_ex2",
          "Find the mean proportional between 9 and 25.",
          "9 और 25 का मध्यानुपाती ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula for mean proportional = √(a × b).",
            "Step 2: Mean Proportional = √(9 × 25) = 3 × 5 = 15."
          ),
          "15",
          "Always the square root of the product."
        ),
        createExample(
          "rp_ex3",
          "A bag contains 50p, 25p, and 10p coins in the ratio 5:9:4, amounting to ₹206. Find the number of each coin.",
          "एक बैग में 50 पैसे, 25 पैसे और 10 पैसे के सिक्के 5:9:4 के अनुपात में हैं, जिनका कुल मूल्य ₹206 है।",
          listOf(
            "Step 1: Convert ratios into rupee values: 50p = ₹0.5, 25p = ₹0.25, 10p = ₹0.10.",
            "Step 2: Value = (5x × 0.5) + (9x × 0.25) + (4x × 0.10) = 2.5x + 2.25x + 0.40x = 5.15x.",
            "Step 3: 5.15x = 206 => x = 206 / 5.15 = 40.",
            "Step 4: Coins: 50p = 5×40 = 200, 25p = 9×40 = 360, 10p = 4×40 = 160."
          ),
          "200, 360, 160",
          "Convert all units to rupees before equating."
        )
      ),
      practiceMcqs = listOf(
        createMcq("rp_q1", "Find the third proportional to 16 and 24.", "", "32", "36", "48", "30", 1, "Third prop = b²/a = 24² / 16 = 576 / 16 = 36."),
        createMcq("rp_q2", "Find the fourth proportional to 4, 9, 12.", "", "27", "24", "18", "36", 0, "Fourth prop = (b×c)/a = (9×12)/4 = 27."),
        createMcq("rp_q3", "If A:B = 3:4 and B:C = 8:9, find A:C.", "", "1:2", "2:3", "3:4", "1:3", 1, "A/C = (A/B) × (B/C) = 3/4 × 8/9 = 2/3."),
        createMcq("rp_q4", "The ratio 4^3.5 : 2^5 is same as:", "", "2:1", "4:1", "7:5", "7:10", 1, "4^3.5 = (2²)^3.5 = 2^7. Ratio is 2^7 : 2^5 = 2² : 1 = 4 : 1."),
        createMcq("rp_q5", "Divide ₹672 in the ratio 5:3. The parts are:", "", "₹420, ₹252", "₹400, ₹272", "₹450, ₹222", "₹410, ₹262", 0, "8 parts = 672 => 1 part = 84. Parts are 5×84 = 420 and 3×84 = 252."),
        createMcq("rp_q6", "If (x + y) : (x - y) = 4 : 1, then (x² + y²) : (x² - y²) is:", "", "17:8", "16:9", "17:15", "8:17", 0, "x/y = (4+1)/(4-1) = 5/3. (x² + y²)/(x² - y²) = (25 + 9)/(25 - 9) = 34/16 = 17/8."),
        createMcq("rp_q7", "Sub-duplicate ratio of 25:36 is:", "", "5:6", "625:1296", "125:216", "5:7", 0, "Sub-duplicate means square roots: √25 : √36 = 5 : 6."),
        createMcq("rp_q8", "What number should be added to each of 6, 14, 18, 38 to make them in proportion?", "", "1", "2", "3", "4", 1, "(6+x)/(14+x) = (18+x)/(38+x). Test x=2: 8/16 = 20/40 = 1/2."),
        createMcq("rp_q9", "Salaries of A, B, C are in ratio 2:3:5. If increments of 15%, 10%, 20% are allowed, new ratio is:", "", "23:33:60", "21:33:60", "23:35:60", "22:33:55", 0, "2×1.15 : 3×1.10 : 5×1.20 = 2.30 : 3.30 : 6.00 = 23 : 33 : 60."),
        createMcq("rp_q10", "Mean proportional of 0.32 and 0.02 is:", "", "0.8", "0.08", "0.008", "0.04", 1, "√(0.32 × 0.02) = √0.0064 = 0.08.")
      )
    ),

    // 7. Average
    FormulaTopic(
      id = "math_average",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Arithmetic",
      title = "Average",
      hindiTitle = "औसत",
      summary = "Arithmetic mean, inclusion/exclusion of observations, and average speed.",
      coreFormula = "Average = Sum of Observations / Number of Observations\nNew Value = Old Average + (New Count × Increase in Average)\nAverage Speed = (2 × s1 × s2) / (s1 + s2)",
      symbolExplanations = listOf(
        "s1, s2" to "Speeds for equal distances in forward and return journeys.",
        "New Count" to "Total members after joining or excluding."
      ),
      importantIdentities = listOf(
        "Average of first n natural numbers = (n + 1) / 2",
        "Average of first n even natural numbers = (n + 1)",
        "Average of first n odd natural numbers = n"
      ),
      shortcutsAndTips = listOf(
        "Deviation Method: Assume an arbitrary baseline, calculate deviations, and divide net deviation by count."
      ),
      commonMistakes = listOf(
        "Taking simple average of two speeds (s1 + s2)/2 for a round trip (must use harmonic mean)."
      ),
      solvedExamples = listOf(
        createExample(
          "avg_ex1",
          "The average weight of 24 students in a class is 40 kg. If the teacher's weight is included, the average increases by 1 kg. Find the teacher's weight.",
          "एक कक्षा के 24 छात्रों का औसत भार 40 किग्रा है। यदि शिक्षक का भार शामिल कर लिया जाए, तो औसत 1 किग्रा बढ़ जाता है।",
          listOf(
            "Step 1: Formula: New Person's Weight = Old Average + (New Total Count × Increase in Average).",
            "Step 2: Old Average = 40, New Count = 25, Increase = 1 kg.",
            "Step 3: Teacher's Weight = 40 + (25 × 1) = 65 kg."
          ),
          "65 kg",
          "Teacher brings 40 kg for self + 1 kg for all 25 people = 65 kg."
        ),
        createExample(
          "avg_ex2",
          "A batsman has a certain average for 11 innings. In the 12th innings, he scores 90 runs and thereby increases his average by 5 runs. What is his new average?",
          "एक बल्लेबाज का 11 पारियों का एक निश्चित औसत है। 12वीं पारी में वह 90 रन बनाता है जिससे उसका औसत 5 रन बढ़ जाता है।",
          listOf(
            "Step 1: Total runs after 12 innings = 12 × A.",
            "Step 2: 12A = 11(A - 5) + 90.",
            "Step 3: 12A = 11A - 55 + 90 => A = 35."
          ),
          "35",
          "New Average = 90 - (11 × 5) = 90 - 55 = 35."
        ),
        createExample(
          "avg_ex3",
          "Find the average of all prime numbers between 20 and 40.",
          "20 और 40 के बीच की सभी अभाज्य संख्याओं का औसत ज्ञात कीजिए।",
          listOf(
            "Step 1: Prime numbers between 20 and 40: 23, 29, 31, 37.",
            "Step 2: Sum = 23 + 29 + 31 + 37 = 120.",
            "Step 3: Count = 4. Average = 120 / 4 = 30."
          ),
          "30",
          "Always verify prime numbers: 27 is composite, 37 is prime."
        )
      ),
      practiceMcqs = listOf(
        createMcq("avg_q1", "Average of first 50 natural numbers is:", "", "25", "25.5", "26", "24.5", 1, "(50 + 1)/2 = 25.5."),
        createMcq("avg_q2", "A car travels from A to B at 60 km/h and returns at 40 km/h. Average speed is:", "", "50 km/h", "48 km/h", "52 km/h", "45 km/h", 1, "(2 × 60 × 40)/(60 + 40) = 4800/100 = 48 km/h."),
        createMcq("avg_q3", "Average of 7 consecutive numbers is 20. The largest number is:", "", "20", "22", "23", "24", 2, "In arithmetic progression, average is the middle (4th) number = 20. Largest (7th) = 20 + 3 = 23."),
        createMcq("avg_q4", "Average age of 30 students is 15 years. If teacher is included, average becomes 16 years. Teacher's age is:", "", "45", "46", "47", "50", 1, "15 + 31 × 1 = 46 years."),
        createMcq("avg_q5", "The average of 5 numbers is 27. If one number is excluded, average becomes 25. Excluded number is:", "", "35", "30", "28", "32", 0, "5 × 27 - 4 × 25 = 135 - 100 = 35."),
        createMcq("avg_q6", "Average of 9 numbers is 50. Average of first 5 is 54 and that of last 5 is 52. The 5th number is:", "", "60", "70", "80", "55", 0, "5th number = (5×54 + 5×52) - (9×50) = 270 + 260 - 450 = 80."),
        createMcq("avg_q7", "Average temperature for Mon, Tue, Wed is 40°C. For Tue, Wed, Thu it is 41°C. If Thu is 42°C, Mon was:", "", "38°C", "39°C", "36°C", "40°C", 1, "Thu - Mon = 3 × (41 - 40) = 3. 42 - Mon = 3 => Mon = 39°C."),
        createMcq("avg_q8", "Average of first 10 multiples of 7 is:", "", "35", "38.5", "42", "40", 1, "7 × (1 + 10)/2 = 7 × 5.5 = 38.5."),
        createMcq("avg_q9", "Average score of 40 students is 68. Later found 84 was wrongly read as 48. Correct average is:", "", "68.9", "67.1", "69.2", "68.5", 0, "Difference = 84 - 48 = +36. Average increase = 36 / 40 = +0.9. Correct = 68.9."),
        createMcq("avg_q10", "Average of all odd numbers up to 100 is:", "", "50", "49", "51", "50.5", 0, "There are 50 odd numbers. Average = n = 50.")
      )
    ),

    // 8. Profit and Loss
    FormulaTopic(
      id = "math_profit_loss",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Commercial Arithmetic",
      title = "Profit and Loss",
      hindiTitle = "लाभ एवं हानि",
      summary = "Cost price, selling price, profit/loss percentages, and dishonest dealer problems.",
      coreFormula = "Profit = SP - CP\nLoss = CP - SP\nProfit % = (Profit / CP) × 100\nLoss % = (Loss / CP) × 100\nSP = CP × [(100 ± P/L%) / 100]",
      symbolExplanations = listOf(
        "CP" to "Cost Price (क्रय मूल्य), always the baseline (100%) for profit/loss.",
        "SP" to "Selling Price (विक्रय मूल्य)."
      ),
      importantIdentities = listOf(
        "Dishonest Dealer Gain % = [Error / (True Value - Error)] × 100%",
        "When two items sold at same SP, one at x% profit and other at x% loss: Net result is ALWAYS Loss = (x/10)² %"
      ),
      shortcutsAndTips = listOf(
        "If CP of x articles = SP of y articles, Profit% = [(x - y) / y] × 100%."
      ),
      commonMistakes = listOf(
        "Calculating profit or loss percentage on Selling Price instead of Cost Price."
      ),
      solvedExamples = listOf(
        createExample(
          "pl_ex1",
          "If the cost price of 15 articles is equal to the selling price of 12 articles, find the profit percentage.",
          "यदि 15 वस्तुओं का क्रय मूल्य 12 वस्तुओं के विक्रय मूल्य के बराबर है, तो लाभ प्रतिशत ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula: Profit % = [(x - y) / y] × 100.",
            "Step 2: Here x = 15, y = 12.",
            "Step 3: Profit % = [(15 - 12) / 12] × 100 = (3 / 12) × 100 = 25%."
          ),
          "25%",
          "Gain is 3 articles out of 12 sold = 3/12 = 25%."
        ),
        createExample(
          "pl_ex2",
          "A man sells two horses for ₹40,000 each. On one he gains 20% and on other he loses 20%. Find his overall gain or loss percent.",
          "एक व्यक्ति दो घोड़े ₹40,000 प्रत्येक पर बेचता है। एक पर 20% लाभ तथा दूसरे पर 20% हानि होती है। कुल लाभ या हानि प्रतिशत ज्ञात कीजिए।",
          listOf(
            "Step 1: When SP is same and % gain = % loss = x, there is always a loss.",
            "Step 2: Loss % = (x / 10)² %.",
            "Step 3: Loss % = (20 / 10)² = 2² = 4% loss."
          ),
          "4% Loss",
          "Absolute SP doesn't matter for percentage calculation."
        ),
        createExample(
          "pl_ex3",
          "A dishonest shopkeeper professes to sell his goods at cost price but uses a weight of 900 gm for a kilogram weight. Find his gain percent.",
          "एक बेईमान दुकानदार 1 किग्रा के स्थान पर 900 ग्राम का बाट प्रयोग करता है। उसका लाभ प्रतिशत ज्ञात कीजिए।",
          listOf(
            "Step 1: Error = 1000 - 900 = 100 gm.",
            "Step 2: True value = 1000 gm, False weight = 900 gm.",
            "Step 3: Gain % = [Error / False Weight] × 100 = [100 / 900] × 100 = 11.11% (11 1/9%)."
          ),
          "11.11%",
          "Gain is calculated on the actual quantity dispensed."
        )
      ),
      practiceMcqs = listOf(
        createMcq("pl_q1", "By selling an article for ₹720, a man loses 10%. At what price should he sell to gain 10%?", "", "₹800", "₹880", "₹840", "₹900", 1, "90% = 720 => 1% = 8. 110% = 110 × 8 = ₹880."),
        createMcq("pl_q2", "A person buys 11 pens for ₹10 and sells 10 pens for ₹11. His gain percent is:", "", "21%", "20%", "25%", "11%", 0, "CP of 1 = 10/11. SP of 1 = 11/10. Gain % = [(11/10 - 10/11) / (10/11)] × 100 = 21/100 × 100 = 21%."),
        createMcq("pl_q3", "If profit is 20% on selling price, what is the profit percentage on cost price?", "", "25%", "16.67%", "20%", "30%", 0, "SP = 100 => Profit = 20 => CP = 80. Profit on CP = (20/80) × 100 = 25%."),
        createMcq("pl_q4", "A trader marks goods 40% above CP and allows 20% discount. His profit % is:", "", "20%", "12%", "15%", "18%", 1, "100 -> 140 -> 140 - 28 = 112. Profit = 12%."),
        createMcq("pl_q5", "Selling price of 20 tables = Cost price of 25 tables. Profit % is:", "", "20%", "25%", "30%", "15%", 1, "(25 - 20)/20 × 100 = 25%."),
        createMcq("pl_q6", "Loss incurred by selling an article for ₹600 is equal to profit made by selling it for ₹1000. Find CP.", "", "₹800", "₹750", "₹850", "₹900", 0, "CP = (600 + 1000)/2 = ₹800."),
        createMcq("pl_q7", "Two articles sold at ₹990 each, one at 10% profit, other at 10% loss. Total loss in ₹ is:", "", "₹10", "₹20", "₹15", "₹25", 1, "Total SP = 1980. Total loss = 1%. Total CP = 1980 / 0.99 = 2000. Loss = ₹20."),
        createMcq("pl_q8", "An article is sold at 15% profit. Had it been sold for ₹24 more, profit would have been 21%. Cost price is:", "", "₹400", "₹350", "₹500", "₹450", 0, "21% - 15% = 6% = ₹24 => 100% = ₹400."),
        createMcq("pl_q9", "A fruit seller buys lemons at 2 for ₹1 and sells them at 5 for ₹3. His profit % is:", "", "10%", "15%", "20%", "25%", 2, "CP of 1 = 0.50. SP of 1 = 3/5 = 0.60. Profit = 0.10/0.50 × 100 = 20%."),
        createMcq("pl_q10", "A dealer sells goods at 6% loss on CP but uses 14 gm instead of 16 gm. His overall gain/loss % is:", "", "7.4% gain", "7.4% loss", "8% gain", "No profit no loss", 0, "SP of 14 gm = (16 × 0.94) = 15.04 gm value. Gain = 15.04 - 14 = 1.04. % = 1.04/14 × 100 = 7.4% gain.")
      )
    ),

    // 9. Discount
    FormulaTopic(
      id = "math_discount",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Commercial Arithmetic",
      title = "Discount and Marked Price",
      hindiTitle = "छूट एवं अंकित मूल्य",
      summary = "Marked price, successive discounts, true discount vs commercial discount, and free goods offers.",
      coreFormula = "Discount = MP - SP\nDiscount % = (Discount / MP) × 100\nSP = MP × [(100 - D%) / 100]\nMP / CP = (100 + Profit%) / (100 - Discount%)",
      symbolExplanations = listOf(
        "MP" to "Marked Price or List Price (अंकित मूल्य).",
        "SP" to "Selling Price after applying discount (विक्रय मूल्य).",
        "CP" to "Cost Price (क्रय मूल्य)."
      ),
      importantIdentities = listOf(
        "Single equivalent discount of d1 and d2 = [d1 + d2 - (d1 × d2 / 100)]%",
        "Buy x get y free discount % = [y / (x + y)] × 100%"
      ),
      shortcutsAndTips = listOf(
        "Relation MP/CP = (100 + P%) / (100 - D%) directly gives MP from CP without computing SP."
      ),
      commonMistakes = listOf(
        "Calculating discount on CP instead of MP.",
        "In 'Buy 3 Get 1 Free', thinking discount is 1/3 (33.3%); it is actually 1/(3+1) = 25%."
      ),
      solvedExamples = listOf(
        createExample(
          "disc_ex1",
          "What is the single equivalent discount for three successive discounts of 20%, 10%, and 5%?",
          "20%, 10% तथा 5% की क्रमिक छूटों के समतुल्य एकल छूट ज्ञात कीजिए।",
          listOf(
            "Step 1: First combine 20% and 10%: 20 + 10 - (20 × 10 / 100) = 28%.",
            "Step 2: Combine 28% and 5%: 28 + 5 - (28 × 5 / 100) = 33 - 1.4 = 31.6%."
          ),
          "31.6%",
          "Alternatively: SP = 100 × 0.8 × 0.9 × 0.95 = 68.4. Discount = 100 - 68.4 = 31.6%."
        ),
        createExample(
          "disc_ex2",
          "A shopkeeper marks his goods to gain 20% after allowing a discount of 10%. If CP is ₹450, find MP.",
          "एक दुकानदार 10% छूट देकर 20% लाभ कमाना चाहता है। यदि क्रय मूल्य ₹450 है, तो अंकित मूल्य ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula: MP / CP = (100 + P%) / (100 - D%).",
            "Step 2: MP / 450 = (100 + 20) / (100 - 10) = 120 / 90 = 4 / 3.",
            "Step 3: MP = 450 × (4 / 3) = ₹600."
          ),
          "₹600",
          "Direct ratio MP/CP saves intermediate SP calculation."
        ),
        createExample(
          "disc_ex3",
          "A store offers: 'Buy 4 Get 1 Free'. What is the effective discount percentage?",
          "एक दुकान पर ऑफर है: '4 खरीदें, 1 मुफ्त पाएं'। प्रभावी छूट प्रतिशत क्या है?",
          listOf(
            "Step 1: Free items = 1. Total items received = 4 + 1 = 5.",
            "Step 2: Discount % = [Free items / Total items] × 100.",
            "Step 3: Discount % = (1 / 5) × 100 = 20%."
          ),
          "20%",
          "Base is total quantity taken home."
        )
      ),
      practiceMcqs = listOf(
        createMcq("disc_q1", "Successive discounts of 30% and 20% are equal to:", "", "50%", "44%", "45%", "46%", 1, "30 + 20 - (30×20)/100 = 50 - 6 = 44%."),
        createMcq("disc_q2", "A watch with MP ₹800 is sold for ₹612 after two successive discounts, first being 10%. Second discount is:", "", "15%", "12%", "10%", "14%", 0, "After 10%: 800 - 80 = 720. Second discount = 720 - 612 = 108. % = (108/720) × 100 = 15%."),
        createMcq("disc_q3", "An offer 'Buy 5 Get 3 Free' gives what discount %?", "", "60%", "37.5%", "40%", "30%", 1, "[3 / (5 + 3)] × 100 = 3/8 × 100 = 37.5%."),
        createMcq("disc_q4", "A retailer gets 25% discount on MP of ₹120. If he sells at MP, his profit % is:", "", "25%", "33.33%", "20%", "30%", 1, "CP = 90, SP = 120. Profit = (30/90) × 100 = 33.33%."),
        createMcq("disc_q5", "To gain 25% after giving 20% discount, by what % must MP be above CP?", "", "45%", "50%", "56.25%", "60%", 2, "MP/CP = 125/80 = 25/16. Markup = 9/16 × 100 = 56.25%."),
        createMcq("disc_q6", "Which scheme is best for a customer? (A) 40% flat, (B) 25% + 15%, (C) 30% + 10%", "", "Scheme A", "Scheme B", "Scheme C", "All equal", 0, "Flat discount always gives higher savings than successive splits of same sum."),
        createMcq("disc_q7", "MP of shirt is ₹500. After allowing two equal discounts, SP is ₹320. Each discount is:", "", "20%", "18%", "16%", "15%", 0, "500 × (1 - d)² = 320 => (1 - d)² = 320/500 = 0.64 => 1 - d = 0.8 => d = 0.20 = 20%."),
        createMcq("disc_q8", "If discount equals 1/5th of MP and loss is 1/6th of discount, what is loss %?", "", "4.16%", "3.45%", "5%", "2.5%", 1, "MP = 30 => Discount = 6 => SP = 24. Loss = 1/6 of 6 = 1. CP = 25. Loss % = (1/25) × 100 = 4% (around 4%)."),
        createMcq("disc_q9", "Cash discount is calculated on:", "", "Cost price", "Invoice/Selling price", "Marked price", "Profit", 1, "Cash discount is allowed on the invoiced net amount for prompt payment."),
        createMcq("disc_q10", "A trader gives 1 item free on purchase of 19 items and also gives 2% cash discount. Net discount is:", "", "6.9%", "7%", "5%", "8%", 0, "Item discount = 1/20 = 5%. Total = 5 + 2 - (5×2)/100 = 7 - 0.1 = 6.9%.")
      )
    ),

    // 10. Simple Interest
    FormulaTopic(
      id = "math_simple_interest",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Commercial Arithmetic",
      title = "Simple Interest",
      hindiTitle = "साधारण ब्याज",
      summary = "Principal, rate of interest, time duration, amount, and doubling rate problems.",
      coreFormula = "SI = (P × R × T) / 100\nAmount (A) = P + SI = P × [1 + (R × T) / 100]\nIf sum doubles in T years: R = 100 / T %\nIf sum becomes n times in T years: R = [(n - 1) × 100] / T %",
      symbolExplanations = listOf(
        "P" to "Principal sum borrowed or invested (मूलधन).",
        "R" to "Annual rate of interest in percentage (दर %).",
        "T" to "Time period in years (समय वर्ष में).",
        "SI" to "Simple Interest earned (साधारण ब्याज).",
        "A" to "Maturity Amount (मिश्रधन)."
      ),
      importantIdentities = listOf(
        "If a sum becomes n times in T years at SI, it will become m times in: T × (m - 1) / (n - 1) years."
      ),
      shortcutsAndTips = listOf(
        "Interest remains identical for every year because it is always calculated on initial principal."
      ),
      commonMistakes = listOf(
        "Entering time in months directly without dividing by 12.",
        "Using compound interest logic where interest compounds."
      ),
      solvedExamples = listOf(
        createExample(
          "si_ex1",
          "Find the simple interest on ₹12,000 at 8% per annum for 3 years and 6 months.",
          "₹12,000 पर 8% वार्षिक दर से 3 वर्ष 6 माह का साधारण ब्याज ज्ञात कीजिए।",
          listOf(
            "Step 1: Convert time into years: T = 3 + 6/12 = 3.5 years = 7/2 years.",
            "Step 2: SI = (P × R × T) / 100.",
            "Step 3: SI = (12000 × 8 × 3.5) / 100 = 120 × 28 = ₹3,360."
          ),
          "₹3,360",
          "Always ensure time is in years before applying formula."
        ),
        createExample(
          "si_ex2",
          "A sum of money doubles itself in 8 years at simple interest. In how many years will it become 4 times itself?",
          "कोई धन साधारण ब्याज की दर से 8 वर्ष में दोगुना हो जाता है। कितने वर्षों में यह 4 गुना हो जाएगा?",
          listOf(
            "Step 1: In 8 years, interest earned = 2P - P = 1P.",
            "Step 2: To become 4 times, interest needed = 4P - P = 3P.",
            "Step 3: Since 1P interest takes 8 years, 3P interest takes 3 × 8 = 24 years."
          ),
          "24 years",
          "Shortcut: T2 = T1 × (n2 - 1) / (n1 - 1) = 8 × (4 - 1)/(2 - 1) = 24."
        ),
        createExample(
          "si_ex3",
          "A sum was put at SI at a certain rate for 3 years. Had it been put at 2% higher rate, it would have fetched ₹360 more. Find the sum.",
          "एक राशि 3 वर्ष के लिए एक निश्चित दर पर दी गई। यदि दर 2% अधिक होती, तो ₹360 अधिक प्राप्त होते। राशि ज्ञात कीजिए।",
          listOf(
            "Step 1: Extra interest in 1 year = ₹360 / 3 = ₹120.",
            "Step 2: This ₹120 represents 2% of the Principal P.",
            "Step 3: If 2% = ₹120, then 100% = (120 / 2) × 100 = ₹6,000."
          ),
          "₹6,000",
          "Direct percentage equivalence: P × ΔR × T / 100 = ΔSI."
        )
      ),
      practiceMcqs = listOf(
        createMcq("si_q1", "At what rate percent per annum will ₹5,000 amount to ₹6,200 in 3 years at SI?", "", "8%", "7.5%", "8.5%", "7%", 0, "SI = 1200. R = (1200 × 100) / (5000 × 3) = 120000 / 15000 = 8%."),
        createMcq("si_q2", "A sum of money becomes 3 times in 10 years at SI. Rate of interest is:", "", "20%", "25%", "15%", "30%", 0, "R = [(3 - 1) × 100] / 10 = 200/10 = 20%."),
        createMcq("si_q3", "SI on a sum for 5 years is 2/5th of the principal. Rate of interest is:", "", "6%", "8%", "10%", "12%", 1, "R = (2/5 × 100) / 5 = 40 / 5 = 8%."),
        createMcq("si_q4", "In how many years will ₹2,000 amount to ₹2,600 at 5% simple interest per annum?", "", "5 years", "6 years", "4 years", "7 years", 1, "SI = 600. T = (600 × 100) / (2000 × 5) = 60000 / 10000 = 6 years."),
        createMcq("si_q5", "A sum lent at SI amounts to ₹720 in 2 years and ₹1,020 in 5 years. Principal is:", "", "₹500", "₹520", "₹600", "₹480", 1, "Interest for 3 years = 1020 - 720 = 300 => 1 year = 100. P = 720 - 200 = ₹520."),
        createMcq("si_q6", "If SI on ₹1 for 1 month is 1 paisa, rate per annum is:", "", "10%", "12%", "6%", "8%", 1, "SI = ₹0.01 in 1/12 yr on ₹1. R = (0.01 × 100) / (1 × 1/12) = 1 × 12 = 12%."),
        createMcq("si_q7", "A sum was invested on SI. It doubled in 6 years. In how many years will it triple?", "", "12 years", "10 years", "14 years", "18 years", 0, "Interest P in 6 yrs. For 3P, interest 2P takes 6 × 2 = 12 years."),
        createMcq("si_q8", "₹1,500 is split in two parts such that SI on first at 10% for 5 yrs equals SI on second at 12.5% for 4 yrs. The ratio of parts is:", "", "1:1", "2:3", "3:4", "5:4", 0, "P1 × 10 × 5 = P2 × 12.5 × 4 => 50 P1 = 50 P2 => P1 : P2 = 1 : 1."),
        createMcq("si_q9", "Difference between SI received from two banks on ₹500 for 2 yrs is ₹2.50. Difference in rates is:", "", "0.25%", "0.5%", "1%", "0.1%", 0, "500 × ΔR × 2 / 100 = 2.50 => 10 ΔR = 2.50 => ΔR = 0.25%."),
        createMcq("si_q10", "A person borrows ₹5,000 for 2 yrs at 4% SI. He immediately lends it to another person at 6.25% SI for 2 yrs. His annual gain is:", "", "₹112.50", "₹125", "₹225", "₹150", 0, "Gain in 2 yrs = 5000 × (6.25 - 4) × 2 / 100 = 50 × 2.25 × 2 = ₹225. Annual gain = 225 / 2 = ₹112.50.")
      )
    )
  )
}
