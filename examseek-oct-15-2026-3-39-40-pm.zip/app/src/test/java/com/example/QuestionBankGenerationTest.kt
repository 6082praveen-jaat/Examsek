package com.example

import com.example.data.ai.ExamQuestionGeneratorService
import com.example.domain.model.ExamRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class QuestionBankGenerationTest {

  @Test
  fun testExamRegistryContainsRequiredExams() {
    val exams = ExamRegistry.allExams
    assertTrue(exams.isNotEmpty())

    val sscCgl = ExamRegistry.getExamById("ssc_cgl")
    assertNotNull(sscCgl)
    assertEquals("SSC CGL", sscCgl?.name)
    assertTrue(sscCgl!!.subjects.contains("Quantitative Aptitude (Maths)"))

    val rrbNtpc = ExamRegistry.getExamById("rrb_ntpc")
    assertNotNull(rrbNtpc)
    assertEquals("RRB NTPC", rrbNtpc?.name)

    val upsc = ExamRegistry.getExamById("upsc_cse")
    assertNotNull(upsc)
  }

  @Test
  fun testSha256ContentHashConsistency() {
    val service = ExamQuestionGeneratorService()
    val hash1 = service.generateContentHash("What is the capital of India?", "New Delhi")
    val hash2 = service.generateContentHash("what is the capital of india?", "new delhi")
    val hash3 = service.generateContentHash("Different question?", "New Delhi")

    assertEquals(hash1, hash2)
    assertFalse(hash1 == hash3)
  }

  @Test
  fun testQuestionValidationRequiresFourOptionsAndSingleCorrectAnswer() {
    val service = ExamQuestionGeneratorService()

    val validJson = """
      [
        {
          "questionText": "What is 25 * 4?",
          "hindiQuestionText": "25 * 4 क्या है?",
          "options": ["100", "90", "110", "120"],
          "hindiOptions": ["100", "90", "110", "120"],
          "correctAnswerIndex": 0,
          "explanation": "25 multiplied by 4 equals 100.",
          "hindiExplanation": "25 गुणा 4 बराबर 100 होता है।"
        }
      ]
    """.trimIndent()

    val parsed = service.parseAndValidateQuestions(
      jsonText = validJson,
      examId = "ssc_cgl",
      stage = "Tier-1",
      subject = "Quantitative Aptitude (Maths)",
      topic = "Arithmetic",
      difficulty = "MEDIUM",
      language = "Bilingual"
    )

    assertEquals(1, parsed.size)
    assertEquals("What is 25 * 4?", parsed[0].questionText)
    assertEquals("A", parsed[0].correctAnswer)
    assertEquals("AI_GENERATED", parsed[0].sourceLabel)
    assertFalse(parsed[0].isVerified)
  }

  @Test
  fun testInvalidOptionCountIsRejected() {
    val service = ExamQuestionGeneratorService()

    val invalidJson = """
      [
        {
          "questionText": "Invalid Question with only 2 options?",
          "options": ["Option 1", "Option 2"],
          "correctAnswerIndex": 0,
          "explanation": "Missing options."
        }
      ]
    """.trimIndent()

    val parsed = service.parseAndValidateQuestions(
      jsonText = invalidJson,
      examId = "ssc_cgl",
      stage = "Tier-1",
      subject = "General Awareness",
      topic = "History",
      difficulty = "EASY",
      language = "English"
    )

    assertEquals(0, parsed.size)
  }

  @Test
  fun testFallbackGeneratorProducesCurriculumAlignedBatch() {
    val service = ExamQuestionGeneratorService()
    val exam = ExamRegistry.getExamById("ssc_cgl")!!

    val batch = service.generateCurriculumFallbackBatch(
      exam = exam,
      stage = "Tier-1",
      subject = "Quantitative Aptitude (Maths)",
      topic = "Percentage & Profit Loss",
      difficulty = "MEDIUM",
      language = "Bilingual",
      count = 5
    )

    assertEquals(5, batch.size)
    for (q in batch) {
      assertEquals("ssc_cgl", q.targetExam)
      assertEquals("Tier-1", q.stage)
      assertEquals("Quantitative Aptitude (Maths)", q.subject)
      assertTrue(listOf("A", "B", "C", "D").contains(q.correctAnswer))
      assertEquals("AI_GENERATED", q.sourceLabel)
      assertFalse(q.isVerified)
    }
  }
}
