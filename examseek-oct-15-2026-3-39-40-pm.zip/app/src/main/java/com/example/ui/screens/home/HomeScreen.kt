package com.example.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ExamCategory
import com.example.domain.model.TestItem
import com.example.domain.model.TestType
import com.example.ui.components.TestCard
import com.example.ui.viewmodel.MainViewModel
import java.util.concurrent.TimeUnit

@Composable
fun HomeScreen(
  viewModel: MainViewModel,
  onStartTest: (TestItem) -> Unit,
  onNavigateToPractice: () -> Unit,
  onNavigateToDailyLearning: () -> Unit,
  onNavigateToAiSolver: () -> Unit,
  onNavigateToExamGenerator: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val currentUser by viewModel.currentUser.collectAsState()
  val filteredTests by viewModel.filteredTests.collectAsState()
  val searchQuery by viewModel.searchQuery.collectAsState()
  val selectedCategory by viewModel.selectedCategoryFilter.collectAsState()
  val selectedType by viewModel.selectedTypeFilter.collectAsState()
  val activeSession by viewModel.activeSession.collectAsState()
  val attempts by viewModel.attempts.collectAsState()

  var showTargetExamDialog by remember { mutableStateOf(false) }

  val targetExamsList = listOf(
    "SSC CGL", "SSC CHSL", "SSC MTS", "RRB NTPC", "RRB Group D",
    "IBPS PO", "SBI Clerk", "UPSC Prelims", "UP Police SI", "NDA / CDS", "CTET", "State PCS"
  )

  // Calculate days left to target exam
  val examDateMillis = currentUser?.targetExamDate ?: (System.currentTimeMillis() + 68L * 24 * 3600 * 1000)
  val diffDays = maxOf(0L, TimeUnit.MILLISECONDS.toDays(examDateMillis - System.currentTimeMillis()))

  // Calculate questions attempted today for daily goals
  val totalSolved = attempts.sumOf { it.totalQuestions }
  val goalTarget = currentUser?.dailyGoalQuestions ?: 20
  val goalProgress = minOf(1.0f, totalSolved.toFloat() / goalTarget)

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("home_screen"),
    contentPadding = PaddingValues(bottom = 80.dp)
  ) {
    // 1. Top Header Banner with Aspirant greeting, target countdown, language switcher
    item {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .background(
            Brush.verticalGradient(
              colors = listOf(
                MaterialTheme.colorScheme.primary,
                Color(0xFF1E3A8A),
                Color(0xFF0F172A)
              )
            )
          )
          .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 24.dp)
      ) {
        Column(modifier = Modifier.fillMaxWidth()) {
          // Greeting & Target Exam Selector Row
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "ExamSeek",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.5.sp
              )
              Text(
                text = if (currentUser != null) "Hello, ${currentUser?.name?.split(" ")?.firstOrNull() ?: "Aspirant"}!" else "Hello, Aspirant!",
                color = Color(0xFFE2E8F0),
                fontSize = 14.sp
              )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
              // Language Switcher Chip
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                  .clip(RoundedCornerShape(16.dp))
                  .background(Color(0x33FFFFFF))
                  .clickable {
                    val nextLang = if (currentUser?.preferredLanguage == "HINDI") "ENGLISH" else "HINDI"
                    viewModel.updateLanguage(nextLang)
                  }
                  .padding(horizontal = 8.dp, vertical = 5.dp)
              ) {
                Icon(imageVector = Icons.Default.Translate, contentDescription = null, tint = Color(0xFF93C5FD), modifier = Modifier.size(13.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (currentUser?.preferredLanguage == "HINDI") "हिंदी" else "EN",
                  color = Color.White,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }

              Spacer(modifier = Modifier.width(8.dp))

              // Target Exam Badge / Button
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                  .testTag("target_exam_chip")
                  .clip(RoundedCornerShape(20.dp))
                  .background(Color(0x33FFFFFF))
                  .clickable { showTargetExamDialog = true }
                  .padding(horizontal = 10.dp, vertical = 5.dp)
              ) {
                Text(
                  text = currentUser?.targetExam ?: "SSC CGL",
                  color = Color.White,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                  imageVector = Icons.Default.EditCalendar,
                  contentDescription = "Change target exam",
                  tint = Color(0xFFFBBF24),
                  modifier = Modifier.size(13.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Exam Countdown & Study Streak Row
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(Color(0x22FFFFFF))
              .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Days Left Countdown
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.HourglassBottom,
                contentDescription = null,
                tint = Color(0xFF38BDF8),
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Column {
                Text(
                  text = "$diffDays Days to ${currentUser?.targetExam ?: "Exam"}",
                  color = Color.White,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "Exam date tracker active",
                  color = Color(0xFFCBD5E1),
                  fontSize = 10.sp
                )
              }
            }

            // Streak
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.LocalFireDepartment,
                contentDescription = null,
                tint = Color(0xFFF59E0B),
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "${currentUser?.streakDays ?: 5}-Day Streak",
                color = Color(0xFFFDE047),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Live Search Bar
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            placeholder = { Text("Search tests, PYQs, topics, subjects...", fontSize = 13.sp) },
            leadingIcon = {
              Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF94A3B8))
            },
            trailingIcon = {
              if (searchQuery.isNotBlank()) {
                IconButton(onClick = { viewModel.setSearchQuery("") }) {
                  Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = Color.White)
                }
              }
            },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("home_search_bar"),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = Color(0xFF1E293B),
              unfocusedContainerColor = Color(0xFF1E293B),
              focusedBorderColor = MaterialTheme.colorScheme.primaryContainer,
              unfocusedBorderColor = Color(0xFF334155),
              focusedTextColor = Color.White,
              unfocusedTextColor = Color.White,
              focusedPlaceholderColor = Color(0xFF94A3B8),
              unfocusedPlaceholderColor = Color(0xFF94A3B8)
            ),
            singleLine = true
          )
        }
      }
    }

    // 2. Active In-Progress Test Resume Banner
    if (activeSession != null) {
      item {
        val session = activeSession!!
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("resume_in_progress_banner")
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Unfinished Test In Progress!",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color(0xFFB45309)
              )
              Text(
                text = "${session.timeRemainingSeconds / 60}m remaining • Question ${session.currentIndex + 1}",
                fontSize = 11.sp,
                color = Color(0xFF92400E)
              )
            }

            Row {
              TextButton(onClick = { viewModel.dismissActiveSession(session.testId) }) {
                Text("Discard", fontSize = 11.sp, color = Color(0xFF991B1B))
              }
              Spacer(modifier = Modifier.width(4.dp))
              Button(
                onClick = {
                  val test = filteredTests.find { it.id == session.testId }
                    ?: filteredTests.firstOrNull()
                  if (test != null) {
                    onStartTest(test)
                  }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(36.dp)
              ) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Resume", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }

    // 3. Student Dashboard Quick Tools Grid
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // AI Doubt Solver Button
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
          modifier = Modifier
            .weight(1f)
            .clickable(onClick = onNavigateToAiSolver)
            .testTag("quick_ai_solver_card")
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text("AI Doubt Guru", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF1E3A8A))
            Text("Instant Hindi/EN Math solutions", fontSize = 10.sp, color = Color(0xFF475569))
          }
        }

        // Daily Learning & Mistake Vault Button
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
          modifier = Modifier
            .weight(1f)
            .clickable(onClick = onNavigateToDailyLearning)
            .testTag("quick_daily_learning_card")
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Icon(imageVector = Icons.Default.Newspaper, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text("Daily Vault & CA", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF15803D))
            Text("Mistakes, formulas & briefs", fontSize = 10.sp, color = Color(0xFF475569))
          }
        }

        // Unlimited AI Question Generator Button
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFFAF5FF)),
          modifier = Modifier
            .weight(1f)
            .clickable(onClick = onNavigateToExamGenerator)
            .testTag("quick_ai_generator_card")
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF9333EA), modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text("AI Bank & Tests", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF7E22CE))
            Text("Expandable question engine", fontSize = 10.sp, color = Color(0xFF475569))
          }
        }
      }
    }

    // 4. Daily Goals & Syllabus Progress Card
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Today's Practice Goal", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("${(goalProgress * 100).toInt()}% Done ($totalSolved / $goalTarget Qs)", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
          }

          Spacer(modifier = Modifier.height(8.dp))

          LinearProgressIndicator(
            progress = { goalProgress },
            modifier = Modifier
              .fillMaxWidth()
              .height(6.dp)
              .clip(RoundedCornerShape(3.dp)),
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Weak subjects warning & recommendation
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFFFFBEB))
              .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.WarningAmber, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Column {
                Text("Weak Topic Alert: Time & Work", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                Text("Accuracy below 65%. Recommended practice set ready.", fontSize = 10.sp, color = Color(0xFFB45309))
              }
            }

            TextButton(onClick = onNavigateToPractice) {
              Text("Practice", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    // 5. Exam Categories Carousel
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 10.dp, bottom = 4.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Exam Categories",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          if (selectedCategory != null) {
            TextButton(onClick = { viewModel.selectCategoryFilter(null) }) {
              Text("Clear Filter", fontSize = 12.sp)
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
          contentPadding = PaddingValues(horizontal = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          items(ExamCategory.entries) { category ->
            val isSelected = selectedCategory == category
            CategoryPill(
              category = category,
              isSelected = isSelected,
              onClick = {
                if (isSelected) viewModel.selectCategoryFilter(null)
                else viewModel.selectCategoryFilter(category)
              }
            )
          }
        }
      }
    }

    // 6. Test Type Filter Chips
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp)
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        FilterChip(
          selected = selectedType == null,
          onClick = { viewModel.selectTypeFilter(null) },
          label = { Text("All Tests (${filteredTests.size})") }
        )
        FilterChip(
          selected = selectedType == TestType.FULL_MOCK,
          onClick = { viewModel.selectTypeFilter(TestType.FULL_MOCK) },
          label = { Text("Full Mocks") }
        )
        FilterChip(
          selected = selectedType == TestType.PYQ_PAPER,
          onClick = { viewModel.selectTypeFilter(TestType.PYQ_PAPER) },
          label = { Text("Official PYQ") }
        )
        FilterChip(
          selected = selectedType == TestType.SECTIONAL_TEST,
          onClick = { viewModel.selectTypeFilter(TestType.SECTIONAL_TEST) },
          label = { Text("Sectionals") }
        )
        FilterChip(
          selected = selectedType == TestType.TOPIC_TEST,
          onClick = { viewModel.selectTypeFilter(TestType.TOPIC_TEST) },
          label = { Text("Topic Tests") }
        )
        FilterChip(
          selected = selectedType == TestType.DAILY_QUIZ,
          onClick = { viewModel.selectTypeFilter(TestType.DAILY_QUIZ) },
          label = { Text("Daily Quizzes") }
        )
      }
    }

    // 7. Test Cards List
    if (filteredTests.isEmpty()) {
      item {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(40.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Icon(
            imageVector = Icons.Default.FilterList,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(48.dp)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text("No tests found", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(8.dp))
          Button(onClick = {
            viewModel.setSearchQuery("")
            viewModel.selectCategoryFilter(null)
            viewModel.selectTypeFilter(null)
          }) {
            Text("Reset Filters")
          }
        }
      }
    } else {
      items(filteredTests, key = { it.id }) { test ->
        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
          TestCard(
            test = test,
            onStartClick = { onStartTest(test) }
          )
        }
      }
    }
  }

  // Dialog for switching target exam, exam date & language
  if (showTargetExamDialog) {
    var selectedExamName by remember { mutableStateOf(currentUser?.targetExam ?: "SSC CGL") }
    var selectedTimelineDays by remember { mutableStateOf(diffDays.toInt().coerceIn(30, 180)) }
    var selectedLang by remember { mutableStateOf(currentUser?.preferredLanguage ?: "ENGLISH") }

    AlertDialog(
      onDismissRequest = { showTargetExamDialog = false },
      title = { Text("Configure Target Exam & Study Plan", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
      text = {
        Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
          Text(
            text = "Set your target competitive exam, study timeline, and preferred question language.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(12.dp))

          Text("1. Target Exam", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Spacer(modifier = Modifier.height(6.dp))
          targetExamsList.chunked(2).forEach { rowExams ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              rowExams.forEach { exam ->
                val isSelected = selectedExamName == exam
                FilterChip(
                  selected = isSelected,
                  onClick = { selectedExamName = exam },
                  label = { Text(exam, fontSize = 12.sp) },
                  modifier = Modifier.weight(1f)
                )
              }
              if (rowExams.size == 1) {
                Spacer(modifier = Modifier.weight(1f))
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          Text("2. Target Exam Timeline (Days to Exam)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            listOf(30, 45, 60, 75, 90, 120).forEach { days ->
              val isSel = selectedTimelineDays == days
              FilterChip(
                selected = isSel,
                onClick = { selectedTimelineDays = days },
                label = { Text("${days}d", fontSize = 11.sp) }
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          Text("3. Preferred Medium", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            FilterChip(
              selected = selectedLang == "ENGLISH",
              onClick = { selectedLang = "ENGLISH" },
              label = { Text("English (EN)", fontSize = 12.sp) },
              modifier = Modifier.weight(1f)
            )
            FilterChip(
              selected = selectedLang == "HINDI",
              onClick = { selectedLang = "HINDI" },
              label = { Text("हिंदी (Hindi)", fontSize = 12.sp) },
              modifier = Modifier.weight(1f)
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val newDate = System.currentTimeMillis() + (selectedTimelineDays.toLong() * 24 * 3600 * 1000)
            viewModel.updateTargetExamAndDate(selectedExamName, newDate)
            viewModel.updateLanguage(selectedLang)
            showTargetExamDialog = false
          }
        ) {
          Text("Save Target Plan")
        }
      },
      dismissButton = {
        TextButton(onClick = { showTargetExamDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }
}

@Composable
fun CategoryPill(
  category: ExamCategory,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  val icon: ImageVector = when (category) {
    ExamCategory.SSC -> Icons.AutoMirrored.Filled.MenuBook
    ExamCategory.RAILWAY -> Icons.Default.Train
    ExamCategory.BANKING -> Icons.Default.AccountBalance
    ExamCategory.UPSC -> Icons.Default.Public
    ExamCategory.STATE_PCS -> Icons.Default.School
    ExamCategory.POLICE -> Icons.Default.Shield
    ExamCategory.DEFENCE -> Icons.Default.Shield
    ExamCategory.TEACHING -> Icons.Default.Psychology
  }

  Card(
    modifier = Modifier
      .testTag("cat_pill_${category.id}")
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp)
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = category.displayName,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
        fontSize = 13.sp,
        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
      )
    }
  }
}
