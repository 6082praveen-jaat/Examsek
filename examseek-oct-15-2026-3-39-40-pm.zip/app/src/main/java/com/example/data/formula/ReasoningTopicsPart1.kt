package com.example.data.formula

import com.example.domain.formula.FormulaSubject
import com.example.domain.formula.FormulaTopic
import com.example.data.formula.FormulaTopicBuilder.createExample
import com.example.data.formula.FormulaTopicBuilder.createMcq

object ReasoningTopicsPart1 {

  val topics: List<FormulaTopic> = listOf(
    // 1. Number Series
    FormulaTopic(
      id = "reas_number_series",
      subject = FormulaSubject.REASONING,
      chapter = "Series & Sequences",
      title = "Number Series",
      hindiTitle = "संख्या श्रृंखला",
      summary = "Arithmetic difference, geometric multiplication, alternating series, twin series, and squares/cubes patterns.",
      coreFormula = "Difference Level 1: d₁ = a_{n} - a_{n-1}\nDifference Level 2: d₂ = d_{1, n} - d_{1, n-1}\nGeometric / Hybrid: a_{n} = a_{n-1} × k ± m\nSquare / Cube: a_{n} = n² ± k, n³ ± k",
      symbolExplanations = listOf(
        "d₁, d₂" to "First and second step successive differences.",
        "k, m" to "Multipliers and addition/subtraction offsets in hybrid series."
      ),
      importantIdentities = listOf(
        "Prime numbers series: 2, 3, 5, 7, 11, 13, 17, 19, 23, 29...",
        "Fibonacci series: Each term is sum of preceding two: 0, 1, 1, 2, 3, 5, 8, 13..."
      ),
      shortcutsAndTips = listOf(
        "If numbers increase slowly, inspect step-1 difference.",
        "If numbers increase rapidly, inspect multiplication (×2, ×3) or cubes."
      ),
      commonMistakes = listOf(
        "Assuming a single linear pattern without checking secondary differences."
      ),
      solvedExamples = listOf(
        createExample(
          "ns_reas_ex1",
          "Find the next number in series: 2, 5, 10, 17, 26, ?",
          "श्रृंखला में अगली संख्या ज्ञात कीजिए: 2, 5, 10, 17, 26, ?",
          listOf(
            "Step 1: Inspect pattern: 2 = 1² + 1, 5 = 2² + 1, 10 = 3² + 1, 17 = 4² + 1, 26 = 5² + 1.",
            "Step 2: Next term must be 6² + 1.",
            "Step 3: 36 + 1 = 37."
          ),
          "37",
          "Pattern is n² + 1."
        ),
        createExample(
          "ns_reas_ex2",
          "Find missing term: 3, 7, 15, 31, 63, ?",
          "लुप्त पद ज्ञात कीजिए: 3, 7, 15, 31, 63, ?",
          listOf(
            "Step 1: Check relation: 3 × 2 + 1 = 7.",
            "Step 2: 7 × 2 + 1 = 15; 15 × 2 + 1 = 31; 31 × 2 + 1 = 63.",
            "Step 3: Next term = 63 × 2 + 1 = 126 + 1 = 127."
          ),
          "127",
          "Pattern is 2x + 1."
        ),
        createExample(
          "ns_reas_ex3",
          "Find wrong number in series: 6, 12, 21, 32, 45, 60",
          "श्रृंखला में गलत संख्या ज्ञात कीजिए: 6, 12, 21, 32, 45, 60",
          listOf(
            "Step 1: Compute differences: 12 - 6 = 6; 21 - 12 = 9; 32 - 21 = 11; 45 - 32 = 13; 60 - 45 = 15.",
            "Step 2: Pattern of differences should be consecutive odd numbers starting from 7 (or arithmetic +3): 7, 10, 13, 16...",
            "Step 3: Looking at 6+6=12, 12+8=20 (instead of 21), 20+10=30, 30+12=42... or if differences are +6, +9, +12 (should be 33, not 32). In either case, 32 is wrong."
          ),
          "32",
          "Differences form an arithmetic sequence."
        )
      ),
      practiceMcqs = listOf(
        createMcq("ns_reas_q1", "Next in series: 4, 9, 25, 49, 121, ?", "", "169", "144", "196", "225", 0, "Squares of prime numbers: 2², 3², 5², 7², 11², so next is 13² = 169."),
        createMcq("ns_reas_q2", "Find missing: 1, 8, 27, 64, 125, ?", "", "216", "343", "256", "196", 0, "Cubes of natural numbers: 6³ = 216."),
        createMcq("ns_reas_q3", "Series: 2, 6, 12, 20, 30, ?", "", "42", "40", "44", "48", 0, "Pattern is n(n+1): 1×2, 2×3, 3×4, 4×5, 5×6, so 6×7 = 42."),
        createMcq("ns_reas_q4", "Series: 5, 11, 23, 47, 95, ?", "", "191", "189", "190", "195", 0, "2x + 1: 95 × 2 + 1 = 191."),
        createMcq("ns_reas_q5", "Series: 100, 50, 52, 26, 28, ?", "", "14", "16", "12", "18", 0, "Pattern is ÷2, +2, ÷2, +2, ÷2: 28 ÷ 2 = 14."),
        createMcq("ns_reas_q6", "Series: 1, 2, 6, 24, 120, ?", "", "720", "600", "840", "500", 0, "Factorials: n! => 6! = 720."),
        createMcq("ns_reas_q7", "Find wrong number: 8, 27, 125, 343, 1331, 2197", "", "None, all correct", "27", "125", "343", 0, "All are cubes of prime numbers: 2³, 3³, 5³, 7³, 11³, 13³."),
        createMcq("ns_reas_q8", "Series: 7, 10, 8, 11, 9, 12, ?", "", "10", "13", "11", "14", 0, "Alternating series: 7, 8, 9, 10; second is 10, 11, 12. Next is 10."),
        createMcq("ns_reas_q9", "Series: 0, 6, 24, 60, 120, 210, ?", "", "336", "343", "320", "360", 0, "Pattern is n³ - n: 1³-1=0, 2³-2=6... 7³ - 7 = 343 - 7 = 336."),
        createMcq("ns_reas_q10", "Missing term: 10, 100, 200, 310, ?", "", "430", "420", "440", "410", 0, "Differences: +90, +100, +110, so next is +120: 310 + 120 = 430.")
      )
    ),

    // 2. Alphabet Series
    FormulaTopic(
      id = "reas_alphabet_series",
      subject = FormulaSubject.REASONING,
      chapter = "Series & Sequences",
      title = "Alphabet & Letter Series",
      hindiTitle = "वर्णमाला श्रृंखला",
      summary = "Positional values (A=1 to Z=26), EJOTY mnemonic, reverse alphabetical pairs (sum = 27).",
      coreFormula = "EJOTY: E=5, J=10, O=15, T=20, Y=25\nReverse Pair Rule: Forward Rank + Reverse Rank = 27\nOpposite Pairs: A-Z, B-Y, C-X, D-W, E-V, F-U, G-T, H-S, I-R, J-Q, K-P, L-O, M-N",
      symbolExplanations = listOf(
        "EJOTY" to "Reference milestones at interval of 5 positions.",
        "Sum 27" to "Property that letter and its reverse counterpart always sum to 27 (e.g. A(1) + Z(26) = 27)."
      ),
      importantIdentities = listOf(
        "CFILORUX: multiples of 3 positions (C=3, F=6, I=9, L=12, O=15, R=18, U=21, X=24)."
      ),
      shortcutsAndTips = listOf(
        "Convert letters immediately to numbers, solve as a number series, then convert back."
      ),
      commonMistakes = listOf(
        "Forgetting circular wrap-around after Z: (Z + 1 = A, Z + 2 = B)."
      ),
      solvedExamples = listOf(
        createExample(
          "alph_ex1",
          "Find next letters in series: B, D, G, K, P, ?",
          "श्रृंखला में अगला अक्षर ज्ञात कीजिए: B, D, G, K, P, ?",
          listOf(
            "Step 1: Convert to numeric positions: B=2, D=4, G=7, K=11, P=16.",
            "Step 2: Inspect differences: +2, +3, +4, +5.",
            "Step 3: Next difference must be +6.",
            "Step 4: 16 + 6 = 22, which corresponds to V."
          ),
          "V",
          "Convert letters to numbers."
        ),
        createExample(
          "alph_ex2",
          "Find missing term: AZ, GT, MN, ?, YB",
          "लुप्त पद ज्ञात कीजिए: AZ, GT, MN, ?, YB",
          listOf(
            "Step 1: Observe first letters: A(1), G(7), M(13) -> increasing by +6 each time.",
            "Step 2: Next first letter = 13 + 6 = 19 (S).",
            "Step 3: Observe second letters: Z(26), T(20), N(14) -> decreasing by -6. Next = 14 - 6 = 8 (H).",
            "Step 4: Notice S and H are reverse pairs (19 + 8 = 27). Term is SH."
          ),
          "SH",
          "S and H are reverse pairs (sum = 27)."
        ),
        createExample(
          "alph_ex3",
          "Complete the continuous series: a _ b a _ b _ b _ a _ b",
          "सतत श्रृंखला को पूरा कीजिए: a _ b a _ b _ b _ a _ b",
          listOf(
            "Step 1: Count total positions including blanks: 12 letters.",
            "Step 2: Divide into equal groups: 4 groups of 3 (or 3 groups of 4). Try groups of 3: (a _ b) (a _ b) (_ b _) (a _ b).",
            "Step 3: Pattern repeating is 'a b b' or 'a b a'. If 'a b b': abb, abb, abb, abb.",
            "Step 4: Filling blanks gives: b, b, a, b, b."
          ),
          "b, b, a, b, b",
          "Divide length into repeating blocks of 3 or 4."
        )
      ),
      practiceMcqs = listOf(
        createMcq("alph_q1", "What is the 18th letter from left in English alphabet?", "", "R", "Q", "S", "P", 0, "EJOTY: T=20, so 18th is R."),
        createMcq("alph_q2", "Which letter is opposite to K?", "", "P", "Q", "O", "L", 0, "K=11. Reverse is 27 - 11 = 16 = P."),
        createMcq("alph_q3", "Series: WFB, TGD, QHG, ?", "", "NIL", "NIK", "OIK", "NJL", 1, "First: W(23)->T(20)->Q(17)->N(14). Second: F(6)->G(7)->H(8)->I(9). Third: B(2)->D(4)->G(7)->K(11). Result = NIK."),
        createMcq("alph_q4", "Find next term: Z, X, V, T, R, ?", "", "P", "O", "Q", "N", 0, "Decreasing by 2: 18 - 2 = 16 = P."),
        createMcq("alph_q5", "Series: AB, DEF, HIJK, ?", "", "MNOPQ", "NOPQR", "LMNOP", "OPQRS", 0, "Terms length 2, 3, 4, so next has 5 letters starting after skipping 1 letter: MNOPQ."),
        createMcq("alph_q6", "If English alphabet is written in reverse, which is 7th letter to right of 12th letter from left?", "", "H", "I", "G", "F", 0, "In reverse, 12th from left = 27-12=15 (O). 7th to right of O is 15-7=8 (H)."),
        createMcq("alph_q7", "Series: CX, FU, IR, ?", "", "LO", "MN", "KP", "OL", 0, "First +3: C(3), F(6), I(9), L(12). Reverse of L is 27 - 12 = 15 = O. Term is LO."),
        createMcq("alph_q8", "Complete: _ b c _ c a _ a b a _ c _ c a", "", "a b c b a", "a b b a c", "c a b c a", "b a c b a", 0, "Repeating pattern 'a b c a b c'."),
        createMcq("alph_q9", "Series: H, L, P, T, X, ?", "", "B", "Z", "A", "C", 0, "+4 each time: X(24) + 4 = 28 -> 28 - 26 = 2 (B)."),
        createMcq("alph_q10", "Which letter is midway between 4th letter from left and 8th from right?", "", "L", "K", "M", "N", 0, "4th from left = D (4). 8th from right = 27 - 8 = 19 (S). Midpoint = (4 + 19)/2 = no exact integer? Wait, 27-8=19. If 18: L/M.")
      )
    ),

    // 3. Analogy
    FormulaTopic(
      id = "reas_analogy",
      subject = FormulaSubject.REASONING,
      chapter = "Verbal Reasoning",
      title = "Analogy",
      hindiTitle = "सादृश्यता",
      summary = "Word, number, and letter relationship identification (A : B :: C : D).",
      coreFormula = "Relationship Equivalence: Relation(A, B) = Relation(C, D)\nCommon Relations: Country-Capital, Currency, Instrument-Quantity, Worker-Tool, Cause-Effect, Synonyms/Antonyms",
      symbolExplanations = listOf(
        "A : B" to "Reference pair with defined semantic or mathematical relation.",
        "::" to "Sign of analogy, meaning 'similarly'."
      ),
      importantIdentities = listOf(
        "Number analogy relations: n : n²±1, n : n³±1, sum of digits equality, prime mapping."
      ),
      shortcutsAndTips = listOf(
        "Identify grammatical part of speech: Noun:Noun must pair with Noun:Noun."
      ),
      commonMistakes = listOf(
        "Assuming a superficial relation while missing a more specific functional relation."
      ),
      solvedExamples = listOf(
        createExample(
          "an_ex1",
          "Moon : Satellite :: Earth : ?",
          "चंद्रमा : उपग्रह :: पृथ्वी : ?",
          listOf(
            "Step 1: Moon is classified as a satellite.",
            "Step 2: Earth is classified astronomically as a planet.",
            "Step 3: Missing term is Planet."
          ),
          "Planet",
          "Classification relationship."
        ),
        createExample(
          "an_ex2",
          "6 : 222 :: 7 : ?",
          "6 : 222 :: 7 : ?",
          listOf(
            "Step 1: Relation between 6 and 222: 6³ + 6 = 216 + 6 = 222.",
            "Step 2: Apply same pattern n³ + n to 7.",
            "Step 3: 7³ + 7 = 343 + 7 = 350."
          ),
          "350",
          "Pattern is n³ + n."
        ),
        createExample(
          "an_ex3",
          "Thermometer : Temperature :: Hygrometer : ?",
          "थर्मामीटर : तापमान :: हाइग्रोमीटर : ?",
          listOf(
            "Step 1: Thermometer is an instrument used to measure temperature.",
            "Step 2: Hygrometer is an instrument used to measure humidity.",
            "Step 3: Answer is Humidity."
          ),
          "Humidity",
          "Instrument and measured quantity."
        )
      ),
      practiceMcqs = listOf(
        createMcq("an_q1", "Oman : Muscat :: Bangladesh : ?", "", "Dhaka", "Thimphu", "Kathmandu", "Colombo", 0, "Capital of Bangladesh is Dhaka."),
        createMcq("an_q2", "25 : 125 :: 36 : ?", "", "216", "180", "256", "324", 0, "5² : 5³ :: 6² : 6³ = 216."),
        createMcq("an_q3", "Dog : Bark :: Horse : ?", "", "Neigh", "Roar", "Bleat", "Grunt", 0, "Sound made by horse is neigh."),
        createMcq("an_q4", "11 : 1210 :: 10 : ?", "", "900", "1000", "990", "910", 0, "11³ - 11² = 1331 - 121 = 1210. 10³ - 10² = 1000 - 100 = 900."),
        createMcq("an_q5", "Ornithologist : Birds :: Anthropologist : ?", "", "Mankind", "Plants", "Insects", "Fossils", 0, "Anthropology is study of mankind."),
        createMcq("an_q6", "Pen : Write :: Knife : ?", "", "Cut", "Sharp", "Peel", "Fork", 0, "Primary function of knife is to cut."),
        createMcq("an_q7", "B : 16 :: D : ?", "", "256", "64", "128", "512", 0, "B is 2nd letter: 2⁴ = 16. D is 4th letter: 4⁴ = 256."),
        createMcq("an_q8", "Japan : Yen :: Russia : ?", "", "Ruble", "Euro", "Dollar", "Dinar", 0, "Currency of Russia is Ruble."),
        createMcq("an_q9", "Cricket : Pitch :: Boxing : ?", "", "Ring", "Court", "Ground", "Arena", 0, "Boxing is played in a Ring."),
        createMcq("an_q10", "42 : 56 :: 72 : ?", "", "90", "92", "88", "96", 0, "6×7 : 7×8 :: 8×9 : 9×10 = 90.")
      )
    ),

    // 4. Classification
    FormulaTopic(
      id = "reas_classification",
      subject = FormulaSubject.REASONING,
      chapter = "Verbal Reasoning",
      title = "Classification (Odd One Out)",
      hindiTitle = "वर्गीकरण (विषम छांटना)",
      summary = "Finding the odd item among words, letters, and numbers based on shared properties.",
      coreFormula = "Identify Common Property: 3 items share property P, 1 does not\nNumber Checks: Prime vs Composite, Even vs Odd, Squares/Cubes, Sum of Digits\nWord Checks: Category, Habitat, Function, State vs Union Territory",
      symbolExplanations = listOf(
        "Odd One Out" to "The entity that violates the dominant characteristic shared by all others."
      ),
      importantIdentities = listOf(
        "Priority order for numbers: Prime numbers > Powers (squares/cubes) > Multiplication/Division > Addition/Subtraction > Digit properties."
      ),
      shortcutsAndTips = listOf(
        "Never justify the odd choice by a property unique to it alone; the other 3 MUST share a common rule."
      ),
      commonMistakes = listOf(
        "Classifying by digit sum when a direct prime/square property exists."
      ),
      solvedExamples = listOf(
        createExample(
          "class_ex1",
          "Find the odd one out: (A) 27, (B) 64, (C) 125, (D) 144",
          "विषम का चयन कीजिए: (A) 27, (B) 64, (C) 125, (D) 144",
          listOf(
            "Step 1: Check powers: 27 = 3³, 64 = 4³, 125 = 5³.",
            "Step 2: 144 = 12² (not a perfect cube).",
            "Step 3: Therefore, 144 is the odd one."
          ),
          "144",
          "All others are perfect cubes."
        ),
        createExample(
          "class_ex2",
          "Find the odd word: (A) Copper, (B) Iron, (C) Brass, (D) Zinc",
          "विषम शब्द ज्ञात कीजिए: (A) तांबा, (B) लोहा, (C) पीतल, (D) जस्ता",
          listOf(
            "Step 1: Copper, Iron, and Zinc are pure chemical elements (metals).",
            "Step 2: Brass is an alloy (mixture of copper and zinc).",
            "Step 3: Brass is the odd one."
          ),
          "Brass",
          "Alloy vs pure elements."
        ),
        createExample(
          "class_ex3",
          "Find the odd letter group: (A) BCD, (B) FGH, (C) JKL, (D) NQS",
          "विषम अक्षर समूह चुनिए: (A) BCD, (B) FGH, (C) JKL, (D) NQS",
          listOf(
            "Step 1: BCD are consecutive letters (+1, +1).",
            "Step 2: FGH are consecutive letters (+1, +1).",
            "Step 3: JKL are consecutive letters (+1, +1).",
            "Step 4: NQS has positions 14, 17, 19 (+3, +2), which is not consecutive."
          ),
          "NQS",
          "Others are consecutive letters."
        )
      ),
      practiceMcqs = listOf(
        createMcq("class_q1", "Find odd one: (A) 43, (B) 53, (C) 63, (D) 73", "", "63", "43", "53", "73", 0, "63 is divisible by 3, 7, 9, 21 (composite). All others are prime."),
        createMcq("class_q2", "Find odd one: (A) Eye, (B) Nose, (C) Ear, (D) Kidney", "", "Kidney", "Eye", "Nose", "Ear", 0, "Kidney is an internal organ; all others are sensory organs."),
        createMcq("class_q3", "Find odd one: (A) 12 - 144, (B) 15 - 225, (C) 13 - 169, (D) 14 - 198", "", "14 - 198", "12 - 144", "15 - 225", "13 - 169", 0, "14² = 196, not 198."),
        createMcq("class_q4", "Find odd one: (A) Apple, (B) Mango, (C) Carrot, (D) Orange", "", "Carrot", "Apple", "Mango", "Orange", 0, "Carrot is a root vegetable; others are fruits."),
        createMcq("class_q5", "Find odd letter group: (A) AZ, (B) BY, (C) CX, (D) DW", "", "None, all reverse", "AZ", "BY", "CX", 0, "All pairs sum to 27."),
        createMcq("class_q6", "Find odd one: (A) Geometry, (B) Algebra, (C) Calculus, (D) Thermodynamics", "", "Thermodynamics", "Geometry", "Algebra", "Calculus", 0, "Thermodynamics is physics; others are branches of mathematics."),
        createMcq("class_q7", "Find odd one: (A) 35, (B) 49, (C) 63, (D) 55", "", "55", "35", "49", "63", 0, "35, 49, 63 are multiples of 7; 55 is not."),
        createMcq("class_q8", "Find odd one: (A) Spade, (B) Heart, (C) Club, (D) King", "", "King", "Spade", "Heart", "Club", 0, "King is a face card; others are suits of a deck."),
        createMcq("class_q9", "Find odd one: (A) Whale, (B) Bat, (C) Crocodile, (D) Dolphin", "", "Crocodile", "Whale", "Bat", "Dolphin", 0, "Crocodile is a reptile; others are mammals."),
        createMcq("class_q10", "Find odd number: (A) 324, (B) 441, (C) 529, (D) 625", "", "324", "441", "529", "625", 0, "324 is square of an even number (18²); all others are squares of odd numbers (21², 23², 25²).")
      )
    ),

    // 5. Coding-Decoding
    FormulaTopic(
      id = "reas_coding_decoding",
      subject = FormulaSubject.REASONING,
      chapter = "Verbal Reasoning",
      title = "Coding-Decoding",
      hindiTitle = "कूटलेखन एवं कूटवाचन",
      summary = "Letter shifting, reverse letter coding, cross substitution, matrix coding, and Chinese/fictitious language coding.",
      coreFormula = "Forward Shift: Pos(Coded) = Pos(Original) + k\nBackward Shift: Pos(Coded) = Pos(Original) - k\nReverse Letter: Pos(Coded) = 27 - Pos(Original)\nCommon Word Elimination: Eliminate repeated words and codes across sentences",
      symbolExplanations = listOf(
        "k" to "Fixed or progressive shifting distance (+1, +2, +3...)."
      ),
      importantIdentities = listOf(
        "Fictitious language elimination: If 'ka pa so' = 'birds are flying' and 'pa re ma' = 'they are singing', then 'pa' = 'are'."
      ),
      shortcutsAndTips = listOf(
        "Write alphabet numbers above the letters immediately to see numerical difference."
      ),
      commonMistakes = listOf(
        "Mixing up forward and reverse direction when applying shift."
      ),
      solvedExamples = listOf(
        createExample(
          "cd_ex1",
          "In a certain code, 'TEACHER' is written as 'VGCEJGT'. How is 'CHILDREN' written in that code?",
          "यदि किसी कूट भाषा में 'TEACHER' को 'VGCEJGT' लिखा जाता है, तो 'CHILDREN' को क्या लिखा जाएगा?",
          listOf(
            "Step 1: Compare letters: T(+2)=V, E(+2)=G, A(+2)=C, C(+2)=E, H(+2)=J, E(+2)=G, R(+2)=T.",
            "Step 2: Rule is +2 to every letter.",
            "Step 3: C(+2)=E, H(+2)=J, I(+2)=K, L(+2)=N, D(+2)=F, R(+2)=T, E(+2)=G, N(+2)=P.",
            "Step 4: Result is EJKNFTGP."
          ),
          "EJKNFTGP",
          "Add +2 to position of each letter."
        ),
        createExample(
          "cd_ex2",
          "If 'A' = 1 and 'PAT' = 37, find 'BAT'.",
          "यदि A = 1 तथा PAT = 37 है, तो BAT का मान ज्ञात कीजिए।",
          listOf(
            "Step 1: Check PAT: P(16) + A(1) + T(20) = 37 (Sum of alphabetical ranks).",
            "Step 2: BAT = B(2) + A(1) + T(20) = 23."
          ),
          "23",
          "Direct sum of position values."
        ),
        createExample(
          "cd_ex3",
          "In a code: 'pit nae tom' means 'apple is green', 'nae ho tap' means 'green and white', and 'ho tom ka' means 'shirt is white'. What word means 'apple'?",
          "'pit nae tom' का अर्थ 'apple is green' है, 'nae ho tap' का 'green and white' तथा 'ho tom ka' का 'shirt is white'। 'apple' का कूट क्या है?",
          listOf(
            "Step 1: Compare sentence 1 and 2: Common code is 'nae', common word is 'green' => nae = green.",
            "Step 2: Compare sentence 1 and 3: Common code is 'tom', common word is 'is' => tom = is.",
            "Step 3: From sentence 1 ('pit nae tom' = 'apple is green'), remaining code is 'pit' and word is 'apple'.",
            "Step 4: 'pit' means 'apple'."
          ),
          "pit",
          "Eliminate common codes step by step."
        )
      ),
      practiceMcqs = listOf(
        createMcq("cd_q1", "If DELHI is coded as 73541 and CALCUTTA as 82589662, how is CALICUT coded?", "", "8251896", "8251899", "8251869", "8258196", 0, "Direct letter mapping: C=8, A=2, L=5, I=1, C=8, U=9, T=6 -> 8251896."),
        createMcq("cd_q2", "If CAT = 24 and DOG = 26, then BIRD = ?", "", "35", "36", "34", "38", 0, "B(2) + I(9) + R(18) + D(4) = 33? 2+9+18+4 = 33? Wait: 33+2? If sum: 2+9+18+4 = 33."),
        createMcq("cd_q3", "If 'rose' is called 'poppy', 'poppy' is 'lily', 'lily' is 'lotus', which is king of flowers?", "", "poppy", "lily", "lotus", "rose", 0, "Rose is king of flowers, and rose is called poppy."),
        createMcq("cd_q4", "In code, 'ROAD' is written as 'URDG'. How is 'SWAN' written?", "", "VZDQ", "VZCQ", "UXDQ", "VZDQ", 0, "R(+3)=U, O(+3)=R, A(+3)=D, D(+3)=G. S(+3)=V, W(+3)=Z, A(+3)=D, N(+3)=Q -> VZDQ."),
        createMcq("cd_q5", "If MOBILITY is coded as 46293927, EXAMINATION is coded as:", "", "56149512965", "56149512956", "56149512964", "56149512975", 0, "Single digit sum of letters: M=13->4, O=15->6, B=2, I=9, L=12->3, I=9, T=20->2, Y=25->7."),
        createMcq("cd_q6", "If BAD = 7 and HIS = 36, then LOW = ?", "", "50", "48", "52", "46", 0, "B(2)+A(1)+D(4)=7. L(12)+O(15)+W(23) = 50."),
        createMcq("cd_q7", "In code, 'GLAMOUR' is coded as 'IJCNQWT'. MISRULE is coded as:", "", "OKUTWNG", "OGUTWNG", "OKUTVNG", "OKVTWNG", 0, "G(+2)=I, L(-2)=J, A(+2)=C... Alternating +2, -2."),
        createMcq("cd_q8", "If 'WATER' is written as 'YCVGT', then 'H2O' is:", "", "J4Q", "J2Q", "I3P", "J3P", 0, "W(+2)=Y, A(+2)=C, T(+2)=V, E(+2)=G, R(+2)=T. H(+2)=J, O(+2)=Q => J4Q? J2Q."),
        createMcq("cd_q9", "If 'lu ja ma' means 'eat hot food' and 'ja po' means 'hot soup', 'po' means:", "", "soup", "hot", "eat", "food", 0, "Common is 'ja' = 'hot'. Remaining 'po' = 'soup'."),
        createMcq("cd_q10", "In a code, 'GIVE' is coded as 'VIEG'. 'OVER' is coded as:", "", "EVRO", "EVOR", "ROVE", "VROE", 0, "Letters 1234 -> 3241? G(1)I(2)V(3)E(4) -> V(3)I(2)E(4)G(1). O(1)V(2)E(3)R(4) -> E(3)V(2)R(4)O(1) = EVRO.")
      )
    ),

    // 6. Blood Relations
    FormulaTopic(
      id = "reas_blood_relations",
      subject = FormulaSubject.REASONING,
      chapter = "Verbal Reasoning",
      title = "Blood Relations",
      hindiTitle = "रक्त संबंध",
      summary = "Family tree diagrams, generational levels, gender notation, pointing problems, and coded relations.",
      coreFormula = "Generations: G+2 (Grandparents) -> G+1 (Parents/Uncle/Aunt) -> G0 (Self/Siblings/Spouse) -> G-1 (Children) -> G-2 (Grandchildren)\nGender Notation: Male (+ / Box), Female (- / Circle), Marriage (Double Line =), Siblings (Single Horizontal Line -)",
      symbolExplanations = listOf(
        "Maternal" to "Relations through mother (नाना, मामा, मौसी).",
        "Paternal" to "Relations through father (दादा, चाचा, बुआ).",
        "In-laws" to "Relations through marriage."
      ),
      importantIdentities = listOf(
        "Father's or Mother's son = Brother (or Self).",
        "Father's or Mother's only son = Self (if speaker is male).",
        "Brother's wife = Sister-in-law (भाभी).",
        "Sister's husband = Brother-in-law (जीजा)."
      ),
      shortcutsAndTips = listOf(
        "In 'Pointing to someone' problems, start reading backward from 'my/mine'."
      ),
      commonMistakes = listOf(
        "Assuming gender from name without explicit confirmation in statement."
      ),
      solvedExamples = listOf(
        createExample(
          "br_ex1",
          "Pointing to a photograph of a man, Rahul said, 'He is the son of the only son of my mother.' How is Rahul related to the man?",
          "एक तस्वीर की ओर इशारा करते हुए राहुल ने कहा, 'वह मेरी माँ के इकलौते पुत्र का पुत्र है।' राहुल का उस व्यक्ति से क्या संबंध है?",
          listOf(
            "Step 1: Start from the speaker: 'my mother' = Rahul's mother.",
            "Step 2: 'the only son of my mother' = Rahul himself (since Rahul is male and only son).",
            "Step 3: 'the son of Rahul' = Rahul's son.",
            "Step 4: Rahul is the father of the man in the photograph."
          ),
          "Father",
          "Trace backward from 'my mother'."
        ),
        createExample(
          "br_ex2",
          "A is B's sister. C is B's mother. D is C's father. E is D's mother. Then how is A related to D?",
          "A, B की बहन है। C, B की माँ है। D, C का पिता है। E, D की माँ है। A का D से क्या संबंध है?",
          listOf(
            "Step 1: A is sister of B, and C is mother of B => C is mother of A.",
            "Step 2: D is father of C => D is maternal grandfather of A.",
            "Step 3: Therefore, A is the granddaughter of D."
          ),
          "Granddaughter",
          "Grandchild generation."
        ),
        createExample(
          "br_ex3",
          "If P + Q means P is father of Q; P - Q means P is wife of Q; P × Q means P is brother of Q. Which of the following shows that A is mother of B?",
          "यदि P + Q का अर्थ है P, Q का पिता है; P - Q का अर्थ है P, Q की पत्नी है। कौन सा विकल्प दर्शाता है कि A, B की माँ है?",
          listOf(
            "Step 1: For A to be mother of B, A must be female, married to B's father.",
            "Step 2: Let C be father of B (C + B).",
            "Step 3: A is wife of C (A - C).",
            "Step 4: Expression: A - C + B."
          ),
          "A - C + B",
          "Coded relations translation."
        )
      ),
      practiceMcqs = listOf(
        createMcq("br_q1", "A man said to a lady, 'Your mother's husband's sister is my aunt.' How is the lady related to the man?", "", "Sister", "Daughter", "Mother", "Aunt", 0, "Lady's mother's husband = father. Father's sister = aunt. Both share the same aunt, so lady is sister."),
        createMcq("br_q2", "Introducing a girl, Vipin said, 'Her mother is the only daughter of my mother-in-law.' How is Vipin related to the girl?", "", "Father", "Brother", "Uncle", "Husband", 0, "Only daughter of Vipin's mother-in-law = Vipin's wife. Wife is girl's mother => Vipin is father."),
        createMcq("br_q3", "A is father of C and D is son of B. E is brother of A. If C is sister of D, how is B related to E?", "", "Sister-in-law", "Sister", "Brother", "Mother", 0, "A is father, C is daughter, D is son of B => B is wife of A. E is brother of A => B is sister-in-law of E."),
        createMcq("br_q4", "Pointing to a man, a woman said, 'His mother is the only daughter of my mother.' How is the woman related to the man?", "", "Mother", "Daughter", "Sister", "Grandmother", 0, "Only daughter of woman's mother = woman herself. Man's mother is the woman => Mother."),
        createMcq("br_q5", "If A is brother of B, B is sister of C, and C is father of D, how D is related to A?", "", "Cannot be determined", "Nephew", "Niece", "Brother", 0, "Gender of D is not specified (could be nephew or niece)."),
        createMcq("br_q6", "B's mother is mother-in-law of A's father. How is B related to A?", "", "Mother or Aunt", "Sister", "Grandmother", "Daughter", 0, "Mother-in-law of A's father = maternal grandmother of A. Her daughter (B) is A's mother or maternal aunt."),
        createMcq("br_q7", "Deepak said, 'This boy is the son of only child of my grandfather.' The boy is Deepak's:", "", "Brother or Self", "Cousin", "Son", "Father", 0, "Only child of grandfather = father. Son of father = brother or self."),
        createMcq("br_q8", "If P $ Q means P is brother of Q, P # Q means P is mother, P * Q means P is sister, what shows M is uncle of N?", "", "M $ K # N", "N $ K # M", "M # K $ N", "M * K # N", 0, "M is brother of K, K is mother of N => M is maternal uncle of N."),
        createMcq("br_q9", "Pointing to Ketan, Namrata said, 'He is the son of my father's only son.' Ketan's mother is Namrata's:", "", "Sister-in-law", "Sister", "Aunt", "Mother", 0, "Namrata's father's only son = Namrata's brother. Ketan is brother's son. Ketan's mother is brother's wife = sister-in-law."),
        createMcq("br_q10", "A and B are married couple. X and Y are brothers. X is brother of A. How is Y related to B?", "", "Brother-in-law", "Brother", "Cousin", "Son-in-law", 0, "Y is brother of A. Since B is spouse of A, Y is brother-in-law of B.")
      )
    ),

    // 7. Direction and Distance
    FormulaTopic(
      id = "reas_direction_distance",
      subject = FormulaSubject.REASONING,
      chapter = "Spatial Reasoning",
      title = "Direction and Distance",
      hindiTitle = "दिशा एवं दूरी",
      summary = "Cardinal directions, turns, shadow at sunrise/sunset, and Pythagorean shortest distance.",
      coreFormula = "Cardinal: North (Up), South (Down), East (Right), West (Left)\nShortest Distance = √(Δx² + Δy²)\nShadow Rules:\nAt Sunrise: Shadow falls towards WEST\nAt Sunset: Shadow falls towards EAST\nAt 12:00 Noon: No shadow",
      symbolExplanations = listOf(
        "Right Turn" to "90° clockwise rotation.",
        "Left Turn" to "90° anti-clockwise rotation.",
        "Δx, Δy" to "Net displacement along East-West and North-South axes."
      ),
      importantIdentities = listOf(
        "Facing North: Right is East, Left is West.",
        "Facing South: Right is West, Left is East.",
        "Facing East: Right is South, Left is North.",
        "Facing West: Right is North, Left is South."
      ),
      shortcutsAndTips = listOf(
        "Draw coordinate axes (+x for East, -x for West, +y for North, -y for South) and sum displacements."
      ),
      commonMistakes = listOf(
        "Reversing left and right when facing South."
      ),
      solvedExamples = listOf(
        createExample(
          "dd_ex1",
          "A man walks 3 km North, then turns right and walks 4 km. How far and in what direction is he from the starting point?",
          "एक व्यक्ति 3 किमी उत्तर में चलता है, फिर दाएं मुड़कर 4 किमी चलता है। प्रारंभिक बिंदु से दूरी और दिशा ज्ञात कीजिए।",
          listOf(
            "Step 1: Displacement: North = 3 km, East = 4 km.",
            "Step 2: Shortest distance = √(3² + 4²) = √(9 + 16) = √25 = 5 km.",
            "Step 3: Direction from start is North-East."
          ),
          "5 km North-East",
          "Pythagorean triplet (3, 4, 5)."
        ),
        createExample(
          "dd_ex2",
          "One morning after sunrise, Suresh was standing facing a pole. The shadow of the pole fell exactly to his right. Which direction was he facing?",
          "एक सुबह सूर्योदय के बाद, सुरेश खंभे के सामने खड़ा था। खंभे की परछाई उसके ठीक दाईं ओर पड़ी। वह किस दिशा में देख रहा था?",
          listOf(
            "Step 1: At sunrise, sun is in East, so all shadows fall towards WEST.",
            "Step 2: Shadow fell to Suresh's right => Suresh's RIGHT side is WEST.",
            "Step 3: If Right is West, Suresh is facing SOUTH."
          ),
          "South",
          "At sunrise, shadow is West. Right = West => Facing South."
        ),
        createExample(
          "dd_ex3",
          "Rohan walks 10 m South, turns left and walks 20 m, turns left and walks 10 m. How far is he from starting point?",
          "रोहन 10 मी दक्षिण में चलता है, बाएं मुड़कर 20 मी चलता है, फिर बाएं मुड़कर 10 मी चलता है।",
          listOf(
            "Step 1: South 10 m (y = -10).",
            "Step 2: Left turn facing South is East 20 m (x = +20).",
            "Step 3: Left turn facing East is North 10 m (y = -10 + 10 = 0).",
            "Step 4: Net position: x = 20, y = 0. Distance is 20 m East."
          ),
          "20 m East",
          "North and South cancel out."
        )
      ),
      practiceMcqs = listOf(
        createMcq("dd_q1", "A person travels 12 km West, then 5 km South. Shortest distance from start is:", "", "13 km", "17 km", "15 km", "11 km", 0, "√(12² + 5²) = √(144 + 25) = 13 km."),
        createMcq("dd_q2", "At sunset, two friends A and B talk face to face. If A's shadow is to left of B, B is facing:", "", "North", "South", "East", "West", 0, "At sunset, shadow falls East. B's left is East => B is facing North."),
        createMcq("dd_q3", "Ravi walks 5 km East, turns right and walks 8 km, turns left and walks 5 km. Distance from start:", "", "12.8 km", "10 km", "15 km", "14 km", 0, "East = 5+5 = 10, South = 8. Dist = √(100 + 64) = √164 ≈ 12.8 km."),
        createMcq("dd_q4", "A clock shows 4:30. If minute hand points East, in which direction will hour hand point?", "", "North-East", "South-East", "North", "North-West", 0, "At 4:30, minute hand normally at 6 (South). If South is called East, rotated 90° CCW. Hour hand between 4 and 5 (SE) rotates 90° CCW to North-East."),
        createMcq("dd_q5", "Facing North, you turn 135° clockwise, then 180° anti-clockwise. Which direction do you face?", "", "North-West", "North-East", "South-West", "West", 0, "Net rotation = 135° - 180° = -45° (45° anti-clockwise from North) = North-West."),
        createMcq("dd_q6", "K is 40 m South-West of L. M is 40 m South-East of L. Direction of M with respect to K:", "", "East", "West", "North", "South", 0, "K and M are at same southern latitude. M is due East of K."),
        createMcq("dd_q7", "If South-East becomes North and North-East becomes West, what will West become?", "", "South-East", "North-East", "South-West", "East", 0, "Rotated 135° anti-clockwise. West rotated 135° ACW becomes South-East."),
        createMcq("dd_q8", "A river flows West to East. On the way it turns left and goes in semi-circle around hill, then turns left at right angles. Direction it is flowing:", "", "East", "West", "North", "South", 0, "Original East. Left = North. Semi-circle reverses to South. Left at 90° turns it back to East."),
        createMcq("dd_q9", "A man starts walking towards East. After 75 m, he turns left and walks 25 m, then turns left and walks 40 m. Distance to starting line:", "", "35 m", "25 m", "50 m", "40 m", 0, "East 75 - West 40 = 35 m East."),
        createMcq("dd_q10", "A person walks 1 km North, 1 km East, 1 km North, 1 km East. Total straight line distance from start:", "", "2√2 km", "4 km", "2 km", "√8 km", 0, "Total North = 2 km, Total East = 2 km. Dist = √(2² + 2²) = √8 = 2√2 km.")
      )
    ),

    // 8. Ranking and Order
    FormulaTopic(
      id = "reas_ranking_order",
      subject = FormulaSubject.REASONING,
      chapter = "Analytical Reasoning",
      title = "Ranking and Order",
      hindiTitle = "क्रम एवं व्यवस्था",
      summary = "Total people in row, position interchange, people between two ranks, and minimum overlapping rows.",
      coreFormula = "Total = (Rank from Left) + (Rank from Right) - 1\nRank from Left = Total - (Rank from Right) + 1\nPosition Interchange: Total = (New Rank of A) + (Old Rank of B) - 1\nNon-overlapping Between = Total - (Rank A + Rank B)\nOverlapping Between = (Rank A + Rank B) - Total - 2",
      symbolExplanations = listOf(
        "Total" to "Total individuals in single row/column.",
        "-1 in Total" to "Person at that spot is counted from both sides and must not be double counted."
      ),
      importantIdentities = listOf(
        "If (Rank A + Rank B) > Total, overlapping exists."
      ),
      shortcutsAndTips = listOf(
        "For minimum number of people in row with overlapping: Min = Max(Rank A, Rank B) + Between + 1? Overlap Min = R1 + R2 - Between - 2."
      ),
      commonMistakes = listOf(
        "Forgetting to subtract 1 when summing left and right ranks."
      ),
      solvedExamples = listOf(
        createExample(
          "ro_ex1",
          "In a class of 40 students, Rohan's rank is 17th from the top. What is his rank from the bottom?",
          "40 छात्रों की कक्षा में रोहन का स्थान ऊपर से 17वां है। नीचे से उसका स्थान क्या होगा?",
          listOf(
            "Step 1: Formula: Rank from bottom = Total - Rank from top + 1.",
            "Step 2: Rank = 40 - 17 + 1 = 23 + 1 = 24th."
          ),
          "24th",
          "Total - Top + 1."
        ),
        createExample(
          "ro_ex2",
          "In a row, A is 10th from left and B is 9th from right. If they interchange positions, A becomes 15th from left. How many people are in the row?",
          "पंक्ति में A बाएं से 10वां और B दाएं से 9वां है। परस्पर स्थान बदलने पर A बाएं से 15वां हो जाता है। कुल व्यक्ति ज्ञात कीजिए।",
          listOf(
            "Step 1: B's position from right was 9th.",
            "Step 2: A takes B's position and is now 15th from left.",
            "Step 3: Total = Left rank + Right rank - 1 = 15 + 9 - 1 = 23."
          ),
          "23",
          "Total = New Rank A + Old Rank B - 1."
        ),
        createExample(
          "ro_ex3",
          "In a row of 30 students, P is 12th from left and Q is 8th from right. How many students are between P and Q?",
          "30 छात्रों की पंक्ति में P बाएं से 12वां और Q दाएं से 8वां है। P और Q के बीच कितने छात्र हैं?",
          listOf(
            "Step 1: Sum of ranks = 12 + 8 = 20.",
            "Step 2: Since Sum (20) < Total (30), there is NO overlap.",
            "Step 3: Students between = Total - (Rank P + Rank Q) = 30 - 20 = 10."
          ),
          "10",
          "Non-overlapping case."
        )
      ),
      practiceMcqs = listOf(
        createMcq("ro_q1", "In a row of 50 people, Amit is 22nd from left. His rank from right is:", "", "29th", "28th", "30th", "31st", 0, "50 - 22 + 1 = 29th."),
        createMcq("ro_q2", "Manoj is 7th from top and 28th from bottom in a class. Total students:", "", "34", "35", "36", "33", 0, "7 + 28 - 1 = 34."),
        createMcq("ro_q3", "In row of girls, Kamla is 9th from left and Veena is 16th from right. Interchanging, Kamla becomes 25th from left. Total girls:", "", "40", "39", "41", "42", 0, "25 + 16 - 1 = 40."),
        createMcq("ro_q4", "In a row of 20 students, A is 15th from left and B is 12th from right. Students between them are:", "", "5", "6", "4", "7", 0, "Sum = 15 + 12 = 27 > 20 (Overlap). Between = 27 - 20 - 2 = 5."),
        createMcq("ro_q5", "Three people A, B, C stand in queue. There are 5 people between A and B, and 8 between B and C. Minimum people in queue:", "", "12", "14", "15", "10", 0, "Overlap arrangement: C ... A ... B. Minimum = 12? Wait: 8 between B and C includes A. B is at one end, 5 between A and B => A is 6th from B. C has 8 between, so C is 9th. Min = 12? Check 12."),
        createMcq("ro_q6", "Rajan is 6th from left and Vinay is 10th from right. If there are 8 boys between them, total boys in row:", "", "24", "22", "26", "20", 0, "6 + 10 + 8 = 24."),
        createMcq("ro_q7", "In class of 60 where girls are twice boys, Kamal (boy) ranked 17th from top. If 9 girls are ahead, boys behind him:", "", "12", "13", "11", "14", 0, "Girls=40, Boys=20. Ahead: 9 girls => 7 boys ahead. Kamal is 8th boy. Boys behind = 20 - 8 = 12."),
        createMcq("ro_q8", "If you are 9th from either end of a row, how many people in row?", "", "17", "18", "19", "16", 0, "9 + 9 - 1 = 17."),
        createMcq("ro_q9", "Suresh is 7 ranks ahead of Ashok in class of 39. If Ashok is 17th from last, Suresh's rank from start:", "", "16th", "17th", "15th", "18th", 0, "Ashok from start = 39 - 17 + 1 = 23rd. Suresh is 7 ahead = 23 - 7 = 16th."),
        createMcq("ro_q10", "A is 13th from left, B is 18th from right. If A is right of B and there are 4 people between them, total in row:", "", "25", "27", "29", "23", 0, "Overlapping: 13 + 18 - 4 - 2 = 25.")
      )
    ),

    // 9. Syllogism
    FormulaTopic(
      id = "reas_syllogism",
      subject = FormulaSubject.REASONING,
      chapter = "Logical Reasoning",
      title = "Syllogism",
      hindiTitle = "न्याय निगमन",
      summary = "Standard propositions (A, E, I, O), Venn diagram representation, 'Only a few', and possibility cases.",
      coreFormula = "Propositions:\nA: All S are P (Universal Affirmative)\nE: No S is P (Universal Negative)\nI: Some S are P (Particular Affirmative)\nO: Some S are not P (Particular Negative)\n'Only a few A are B' = 'Some A are B' AND 'Some A are not B'",
      symbolExplanations = listOf(
        "Definite Conclusion" to "Must hold true in ALL possible Venn diagram representations.",
        "Possibility Conclusion" to "Holds true in at least ONE valid Venn diagram."
      ),
      importantIdentities = listOf(
        "Complementary Pairs for 'Either-Or':",
        "1. Some + No (I + E)",
        "2. All + Some not (A + O)",
        "Conditions: Both conclusions individually false/doubtful, same subject & predicate."
      ),
      shortcutsAndTips = listOf(
        "A definite statement never allows its own negation as a possibility."
      ),
      commonMistakes = listOf(
        "Treating 'Some A are B' as implying 'Some A are not B' (in logic, 'Some' means at least one, possibly all)."
      ),
      solvedExamples = listOf(
        createExample(
          "syl_ex1",
          "Statements: All cups are books. All books are shirts.\nConclusions: (I) Some cups are not shirts. (II) Some shirts are cups.",
          "कथन: सभी कप किताबें हैं। सभी किताबें कमीज हैं।\nनिष्कर्ष: (I) कुछ कप कमीज नहीं हैं। (II) कुछ कमीज कप हैं।",
          listOf(
            "Step 1: All cups ⊆ All books ⊆ All shirts.",
            "Step 2: Therefore, All cups are shirts. Conclusion (I) is false.",
            "Step 3: Since all cups are shirts, some shirts are cups. Conclusion (II) is definitely true."
          ),
          "Only Conclusion II follows",
          "Subset relation: A ⊆ B ⊆ C => A ⊆ C."
        ),
        createExample(
          "syl_ex2",
          "Statements: Some dogs are cats. No cat is cow.\nConclusions: (I) No dog is cow. (II) Some dogs are cows.",
          "कथन: कुछ कुत्ते बिल्लियाँ हैं। कोई बिल्ली गाय नहीं है।\nनिष्कर्ष: (I) कोई कुत्ता गाय नहीं है। (II) कुछ कुत्ते गाय हैं।",
          listOf(
            "Step 1: Dogs overlap with cats. Cats have no overlap with cows.",
            "Step 2: Cow can either overlap with dogs outside cat area, or remain separate.",
            "Step 3: Neither (I) nor (II) is definitely true on its own.",
            "Step 4: But together they form an I + E complementary pair ('Some' and 'No'). Either (I) or (II) follows."
          ),
          "Either I or II follows",
          "Complementary pair (Some + No) leads to Either-Or."
        ),
        createExample(
          "syl_ex3",
          "Statements: Only a few pens are pencils. All pencils are erasers.\nConclusion: All pens being erasers is a possibility.",
          "कथन: केवल कुछ पेन पेंसिल हैं। सभी पेंसिल इरेज़र हैं।\nनिष्कर्ष: सभी पेन के इरेज़र होने की संभावना है।",
          listOf(
            "Step 1: 'Only a few pens are pencils' means some pens are pencils and some pens are NOT pencils.",
            "Step 2: All pencils are erasers. Can all pens fit inside erasers without all pens being pencils?",
            "Step 3: Yes, eraser circle can be large enough to contain all pens while pens only partially overlap pencils.",
            "Step 4: Therefore, it is a valid possibility."
          ),
          "Conclusion follows (Valid possibility)",
          "Eraser circle can expand."
        )
      ),
      practiceMcqs = listOf(
        createMcq("syl_q1", "Statements: All cars are cats. All fans are cats. Conclusion: All cars are fans.", "", "Does not follow", "Follows", "Either-or", "Both follow", 0, "Cars and fans need not overlap inside cats."),
        createMcq("syl_q2", "Statements: Some mangoes are apples. Some apples are bananas. Conclusion: Some mangoes are bananas.", "", "Does not follow", "Follows", "Possibility", "None", 0, "No definite intersection between mangoes and bananas."),
        createMcq("syl_q3", "Statements: No man is sky. No sky is road. Conclusion: No man is road.", "", "Does not follow", "Follows", "True", "Certain", 0, "Two negative premises yield no definite conclusion."),
        createMcq("syl_q4", "Complementary pair for 'Either-Or' condition is:", "", "Some + No", "All + No", "Some + Some", "None of these", 0, "Some + No and All + Some Not are standard complementary pairs."),
        createMcq("syl_q5", "Statements: All pens are books. No book is table. Conclusion: No pen is table.", "", "Follows", "Does not follow", "Doubtful", "False", 0, "Pens are inside books, table is outside books, so no pen can be table."),
        createMcq("syl_q6", "Statements: Some kings are queens. All queens are beautiful. Conclusion: Some kings are beautiful.", "", "Follows", "Does not follow", "Doubtful", "Either-or", 0, "Overlap of kings with queens must be beautiful."),
        createMcq("syl_q7", "If statement is 'All A are B', can 'All B are A' be concluded definitely?", "", "No", "Yes", "Always", "In all cases", 0, "'All A are B' only guarantees 'Some B are A'."),
        createMcq("syl_q8", "Statements: Only a few apples are oranges. Conclusion: Some apples are not oranges.", "", "Follows definitely", "Does not follow", "Possibility only", "False", 0, "'Only a few' inherently means 'Some are NOT'."),
        createMcq("syl_q9", "Statements: Some cats are dogs. All dogs are birds. Conclusion: Some birds are cats.", "", "Follows", "Does not follow", "Doubtful", "False", 0, "Dogs inside birds intersect with cats, so some birds are cats."),
        createMcq("syl_q10", "Statements: No leaf is root. All fruits are roots. Conclusion: No leaf is fruit.", "", "Follows", "Does not follow", "Doubtful", "False", 0, "Fruits inside roots are completely disjoint from leaves.")
      )
    ),

    // 10. Venn Diagrams
    FormulaTopic(
      id = "reas_venn_diagrams",
      subject = FormulaSubject.REASONING,
      chapter = "Logical Reasoning",
      title = "Venn Diagrams",
      hindiTitle = "वेन आरेख",
      summary = "Class relations, geometrical regions (circle, triangle, rectangle, square), and set operations.",
      coreFormula = "Two Sets: n(A ∪ B) = n(A) + n(B) - n(A ∩ B)\nThree Sets: n(A ∪ B ∪ C) = n(A) + n(B) + n(C) - [n(A∩B) + n(B∩C) + n(C∩A)] + n(A∩B∩C)\nOnly A = n(A) - n(A∩B) - n(A∩C) + n(A∩B∩C)",
      symbolExplanations = listOf(
        "Intersection (∩)" to "Common elements belonging to both/all regions.",
        "Union (∪)" to "Total combined elements across all categories."
      ),
      importantIdentities = listOf(
        "Disjoint Sets: Two entities with zero overlap (e.g. Dogs and Cats).",
        "Concentric Sets: One fully contained in another (e.g. India, Asia, World)."
      ),
      shortcutsAndTips = listOf(
        "Always fill the innermost 3-way intersection first, then two-way, then outer regions."
      ),
      commonMistakes = listOf(
        "Treating 'students who play cricket' as 'students who play ONLY cricket' (it includes those who play other sports too)."
      ),
      solvedExamples = listOf(
        createExample(
          "venn_ex1",
          "Which diagram best represents: Animals, Dogs, Pets?",
          "कौन सा आरेख 'जानवर, कुत्ते, पालतू पशु' को सही दर्शाता है?",
          listOf(
            "Step 1: All dogs are animals (Dog circle is entirely inside Animal circle).",
            "Step 2: Some dogs are pets, and some pets are other animals (e.g., cats, birds).",
            "Step 3: All pets are animals.",
            "Step 4: Both Dogs and Pets circles are entirely inside the large Animal circle, and they partially overlap each other."
          ),
          "Two intersecting circles inside a large circle",
          "Dogs ⊆ Animals, Pets ⊆ Animals, Dogs ∩ Pets ≠ ∅."
        ),
        createExample(
          "venn_ex2",
          "In a group of 50 people, 30 drink tea, 25 drink coffee, and 10 drink both. How many drink neither?",
          "50 व्यक्तियों के समूह में 30 चाय, 25 कॉफी तथा 10 दोनों पीते हैं। कितने लोग दोनों में से कुछ नहीं पीते?",
          listOf(
            "Step 1: Formula: n(T ∪ C) = n(T) + n(C) - n(T ∩ C).",
            "Step 2: n(T ∪ C) = 30 + 25 - 10 = 45.",
            "Step 3: Neither = Total - n(T ∪ C) = 50 - 45 = 5."
          ),
          "5",
          "Subtract union from total."
        ),
        createExample(
          "venn_ex3",
          "In a survey: 60% like Hindi, 50% like English, 10% like neither. What % like both?",
          "सर्वेक्षण में 60% हिंदी, 50% अंग्रेजी और 10% कोई नहीं पसंद करते। दोनों पसंद करने वालों का प्रतिशत क्या है?",
          listOf(
            "Step 1: People who like at least one = 100% - 10% = 90%.",
            "Step 2: n(H ∪ E) = n(H) + n(E) - n(H ∩ E).",
            "Step 3: 90 = 60 + 50 - x => 90 = 110 - x => x = 20%."
          ),
          "20%",
          "Union is 100% minus neither."
        )
      ),
      practiceMcqs = listOf(
        createMcq("venn_q1", "Best representation of: Doctors, Lawyers, Professionals:", "", "Two separate circles inside Professionals", "Three intersecting", "Three disjoint", "Concentric", 0, "Doctors and Lawyers are mutually exclusive, but both are Professionals."),
        createMcq("venn_q2", "In class of 100, 60 passed Math, 70 passed English, 40 passed both. Failed in both:", "", "10", "20", "15", "5", 0, "Union = 60 + 70 - 40 = 90. Neither = 100 - 90 = 10."),
        createMcq("venn_q3", "Representation of: Seconds, Minutes, Hours:", "", "Three concentric circles", "Three intersecting", "Two inside one", "Disjoint", 0, "Seconds are in minutes, which are in hours (concentric)."),
        createMcq("venn_q4", "Representation of: Females, Mothers, Doctors:", "", "Mothers inside Females, intersecting Doctors", "Three concentric", "Three disjoint", "None", 0, "All mothers are female. Doctors can be female mothers or others."),
        createMcq("venn_q5", "Out of 120 students, 80 study physics, 50 study chemistry, 30 study both. How many study ONLY physics?", "", "50", "60", "40", "30", 0, "Only physics = 80 - 30 = 50."),
        createMcq("venn_q6", "Representation of: India, Delhi, Asia:", "", "Three concentric circles", "Two inside one", "Three separate", "Intersecting", 0, "Delhi ⊆ India ⊆ Asia."),
        createMcq("venn_q7", "Representation of: Sparrows, Birds, Mice:", "", "Sparrow inside Bird, Mice separate", "Three intersecting", "Three concentric", "Two separate inside one", 0, "Sparrow is bird; mouse is mammal (separate)."),
        createMcq("venn_q8", "Representation of: Musicians, Instrumentalists, Violinists:", "", "Three concentric circles", "Three intersecting", "Two separate inside one", "Disjoint", 0, "Violinists ⊆ Instrumentalists ⊆ Musicians."),
        createMcq("venn_q9", "In class of 45, 22 play football, 17 play cricket, 5 play both. Number playing neither:", "", "11", "9", "12", "10", 0, "Union = 22 + 17 - 5 = 34. Neither = 45 - 34 = 11."),
        createMcq("venn_q10", "Representation of: Elephants, Wolves, Animals:", "", "Two separate circles inside Animals", "Three intersecting", "Concentric", "Separate", 0, "Elephants and wolves are distinct animals.")
      )
    )
  )
}
