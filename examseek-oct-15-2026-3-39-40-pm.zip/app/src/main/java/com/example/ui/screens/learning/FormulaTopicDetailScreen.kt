package com.example.ui.screens.learning

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.formula.FormulaRepository
import com.example.domain.formula.SolvedExample
import com.example.domain.formula.TopicPracticeMcq
import com.example.domain.formula.TopicQuizResult

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FormulaTopicDetailScreen(
  topicId: String,
  formulaRepository: FormulaRepository,
  onNavigateBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val topic = remember(topicId) { formulaRepository.getTopicById(topicId) }

  val bookmarkedIds by formulaRepository.bookmarkedTopicIds.collectAsState()
  val completedIds by formulaRepository.completedTopicIds.collectAsState()
  val quizResults by formulaRepository.quizResults.collectAsState()

  val isBookmarked = bookmarkedIds.contains(topicId)
  val isCompleted = completedIds.contains(topicId)
  val savedQuizResult = quizResults[topicId]

  // Record this view as recently viewed
  LaunchedEffect(topicId) {
    formulaRepository.recordTopicView(topicId)
  }

  if (topic == null) {
    Box(
      modifier = modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background),
      contentAlignment = Alignment.Center
    ) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Topic not found", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(12.dp))
        Button(onClick = onNavigateBack) {
          Text("Go Back")
        }
      }
    }
    return
  }

  var selectedSubTab by remember { mutableIntStateOf(0) } // 0: Formula & Concepts, 1: Solved Examples, 2: Practice Quiz (10 MCQs)

  // Quiz state
  val userSelectedAnswers = remember { mutableStateMapOf<Int, Int>() }
  var showQuizResult by remember { mutableStateOf(false) }
  var filterOnlyIncorrect by remember { mutableStateOf(false) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("formula_detail_screen")
  ) {
    // Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(MaterialTheme.colorScheme.surface)
        .padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(
        onClick = onNavigateBack,
        modifier = Modifier.testTag("formula_detail_back_button")
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowBack,
          contentDescription = "Back",
          tint = MaterialTheme.colorScheme.onSurface
        )
      }

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = topic.title,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          maxLines = 1
        )
        Text(
          text = "${topic.subject.displayName} • ${topic.chapter}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          fontSize = 11.sp
        )
      }

      // Bookmark Button
      IconButton(
        onClick = { formulaRepository.toggleBookmark(topicId) },
        modifier = Modifier.testTag("toggle_bookmark_button")
      ) {
        Icon(
          imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
          contentDescription = if (isBookmarked) "Bookmarked" else "Bookmark",
          tint = if (isBookmarked) Color(0xFFFFB74D) else MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      // Mark Complete Toggle
      IconButton(
        onClick = { formulaRepository.toggleCompleted(topicId) },
        modifier = Modifier.testTag("toggle_completed_button")
      ) {
        Icon(
          imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.Check,
          contentDescription = if (isCompleted) "Completed" else "Mark Complete",
          tint = if (isCompleted) Color(0xFF4CAF50) else MaterialTheme.colorScheme.outline
        )
      }
    }

    // Sub Navigation Tabs
    ScrollableTabRow(
      selectedTabIndex = selectedSubTab,
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
      edgePadding = 16.dp
    ) {
      Tab(
        selected = selectedSubTab == 0,
        onClick = { selectedSubTab = 0 },
        text = { Text("Formula & Rules", fontSize = 13.sp) }
      )
      Tab(
        selected = selectedSubTab == 1,
        onClick = { selectedSubTab = 1 },
        text = { Text("3 Solved Examples", fontSize = 13.sp) }
      )
      Tab(
        selected = selectedSubTab == 2,
        onClick = { selectedSubTab = 2 },
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text("10 Practice MCQs", fontSize = 13.sp)
            if (savedQuizResult != null) {
              Spacer(modifier = Modifier.width(4.dp))
              Box(
                modifier = Modifier
                  .clip(CircleShape)
                  .background(if (savedQuizResult.score >= 6) Color(0xFF4CAF50) else Color(0xFFFF9800))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  "${savedQuizResult.score}/10",
                  color = Color.White,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }
      )
    }

    // Tab Content
    when (selectedSubTab) {
      0 -> FormulaConceptsTab(topic = topic, isCompleted = isCompleted)
      1 -> SolvedExamplesTab(examples = topic.solvedExamples, topicTitle = topic.title)
      2 -> PracticeQuizTab(
        mcqs = topic.practiceMcqs,
        savedResult = savedQuizResult,
        userSelectedAnswers = userSelectedAnswers,
        showQuizResult = showQuizResult,
        filterOnlyIncorrect = filterOnlyIncorrect,
        onSelectAnswer = { index, optionIndex ->
          if (!showQuizResult) {
            userSelectedAnswers[index] = optionIndex
          }
        },
        onSubmitQuiz = {
          var score = 0
          val incorrect = mutableListOf<Int>()
          topic.practiceMcqs.forEachIndexed { i, mcq ->
            val userAns = userSelectedAnswers[i]
            if (userAns == mcq.correctOptionIndex) {
              score++
            } else {
              incorrect.add(i)
            }
          }
          val result = TopicQuizResult(
            topicId = topicId,
            score = score,
            totalQuestions = topic.practiceMcqs.size,
            incorrectQuestionIndices = incorrect
          )
          formulaRepository.recordQuizAttempt(result)
          showQuizResult = true
        },
        onResetQuiz = {
          userSelectedAnswers.clear()
          showQuizResult = false
          filterOnlyIncorrect = false
        },
        onToggleFilterIncorrect = {
          filterOnlyIncorrect = !filterOnlyIncorrect
        }
      )
    }
  }
}

@Composable
private fun FormulaConceptsTab(
  topic: com.example.domain.formula.FormulaTopic,
  isCompleted: Boolean
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp, vertical = 12.dp)
  ) {
    item {
      // Header Info Card
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.primaryContainer)
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = topic.chapter,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                fontWeight = FontWeight.Bold
              )
            }

            if (isCompleted) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.CheckCircle,
                  contentDescription = null,
                  tint = Color(0xFF4CAF50),
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  "Completed",
                  color = Color(0xFF4CAF50),
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = topic.title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
          )

          if (topic.hindiTitle.isNotBlank()) {
            Text(
              text = topic.hindiTitle,
              style = MaterialTheme.typography.titleSmall,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.Medium
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = topic.summary,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))
    }

    // Core Formula Box
    item {
      Text(
        text = "CORE FORMULA & RULES",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.primary
      )
      Spacer(modifier = Modifier.height(6.dp))

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = topic.coreFormula,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            lineHeight = 22.sp,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))
    }

    // Symbol & Variable Explanations
    if (topic.symbolExplanations.isNotEmpty()) {
      item {
        Text(
          text = "SYMBOLS, VARIABLES & CONDITIONS",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.ExtraBold,
          color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(6.dp))

        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          shape = RoundedCornerShape(12.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            topic.symbolExplanations.forEachIndexed { idx, (symbol, explanation) ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                verticalAlignment = Alignment.Top
              ) {
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = symbol,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary
                  )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                  text = explanation,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurface,
                  modifier = Modifier.weight(1f)
                )
              }
              if (idx < topic.symbolExplanations.size - 1) {
                HorizontalDivider(
                  modifier = Modifier.padding(vertical = 4.dp),
                  color = DividerDefaults.color.copy(alpha = 0.3f)
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))
      }
    }

    // Important Identities / Nuances
    if (topic.importantIdentities.isNotEmpty()) {
      item {
        Text(
          text = "KEY IDENTITIES & CRITICAL CASES",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.ExtraBold,
          color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(6.dp))

        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          shape = RoundedCornerShape(12.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            topic.importantIdentities.forEach { identity ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                verticalAlignment = Alignment.Top
              ) {
                Icon(
                  imageVector = Icons.Default.MenuBook,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = identity,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))
      }
    }

    // Shortcuts and Exam Tips
    if (topic.shortcutsAndTips.isNotEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF1E3A5F).copy(alpha = 0.25f)),
          shape = RoundedCornerShape(12.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Lightbulb,
                contentDescription = null,
                tint = Color(0xFFFFB300),
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                "EXAM SHORTCUTS & PRO TIPS",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = Color(0xFFFFB300)
              )
            }
            Spacer(modifier = Modifier.height(8.dp))
            topic.shortcutsAndTips.forEach { tip ->
              Text(
                text = "• $tip",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(vertical = 2.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))
      }
    }

    // Common Mistakes
    if (topic.commonMistakes.isNotEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF4A1A1A).copy(alpha = 0.35f)),
          shape = RoundedCornerShape(12.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = null,
                tint = Color(0xFFEF5350),
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                "COMMON EXAM TRAPS & MISTAKES",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = Color(0xFFEF5350)
              )
            }
            Spacer(modifier = Modifier.height(8.dp))
            topic.commonMistakes.forEach { mistake ->
              Text(
                text = "⚠ $mistake",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(vertical = 2.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  }
}

@Composable
private fun SolvedExamplesTab(
  examples: List<SolvedExample>,
  topicTitle: String
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp, vertical = 12.dp)
  ) {
    item {
      Text(
        text = "3 STEP-BY-STEP SOLVED EXAMPLES",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.primary
      )
      Text(
        text = "Rigorous pedagogical walkthroughs for $topicTitle",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(12.dp))
    }

    itemsIndexed(examples) { idx, ex ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          // Example Badge
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.primary)
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "Example ${idx + 1}",
                color = MaterialTheme.colorScheme.onPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
              )
            }

            if (ex.shortcutTip.isNotBlank()) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(Color(0xFF2E7D32).copy(alpha = 0.2f))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  "Shortcut Included",
                  color = Color(0xFF81C784),
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // English Problem
          Text(
            text = ex.problem,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
          )

          // Hindi Problem if available
          if (ex.hindiProblem.isNotBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = ex.hindiProblem,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.primary,
              fontSize = 12.sp
            )
          }

          Spacer(modifier = Modifier.height(12.dp))
          HorizontalDivider(color = DividerDefaults.color.copy(alpha = 0.4f))
          Spacer(modifier = Modifier.height(10.dp))

          // Step by step breakdown
          Text(
            text = "Step-by-step Solution:",
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(6.dp))

          ex.stepByStepSolution.forEach { step ->
            Text(
              text = step,
              style = MaterialTheme.typography.bodySmall,
              lineHeight = 18.sp,
              modifier = Modifier.padding(vertical = 2.dp)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Final Answer Highlight
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
              .padding(horizontal = 12.dp, vertical = 8.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Answer: ${ex.finalAnswer}",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }

          // Shortcut tip
          if (ex.shortcutTip.isNotBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.Top) {
              Icon(
                imageVector = Icons.Default.Lightbulb,
                contentDescription = null,
                tint = Color(0xFFFFB300),
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Tip: ${ex.shortcutTip}",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFFFB300),
                fontSize = 11.sp
              )
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}

@Composable
private fun PracticeQuizTab(
  mcqs: List<TopicPracticeMcq>,
  savedResult: TopicQuizResult?,
  userSelectedAnswers: Map<Int, Int>,
  showQuizResult: Boolean,
  filterOnlyIncorrect: Boolean,
  onSelectAnswer: (Int, Int) -> Unit,
  onSubmitQuiz: () -> Unit,
  onResetQuiz: () -> Unit,
  onToggleFilterIncorrect: () -> Unit
) {
  val questionsToDisplay = remember(mcqs, filterOnlyIncorrect, showQuizResult, savedResult) {
    if (filterOnlyIncorrect && showQuizResult) {
      mcqs.filterIndexed { index, _ ->
        val userAns = userSelectedAnswers[index]
        userAns != mcqs[index].correctOptionIndex
      }
    } else if (filterOnlyIncorrect && savedResult != null && !showQuizResult) {
      mcqs.filterIndexed { index, _ -> savedResult.incorrectQuestionIndices.contains(index) }
    } else {
      mcqs
    }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp, vertical = 12.dp)
  ) {
    item {
      // Score / Instruction Banner
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
          containerColor = if (showQuizResult) {
            val score = userSelectedAnswers.count { (idx, ans) -> ans == mcqs[idx].correctOptionIndex }
            if (score >= 7) Color(0xFF1B5E20) else Color(0xFFE65100)
          } else {
            MaterialTheme.colorScheme.surface
          }
        ),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          if (showQuizResult) {
            val score = userSelectedAnswers.count { (idx, ans) -> ans == mcqs[idx].correctOptionIndex }
            Text(
              text = "Quiz Completed: $score / ${mcqs.size} Correct (${score * 10}%)",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
            Text(
              text = if (score >= 7) "Excellent Mastery! Topic marked as Completed." else "Review incorrect questions below to solidify concepts.",
              style = MaterialTheme.typography.bodySmall,
              color = Color.White.copy(alpha = 0.9f)
            )

            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Button(
                onClick = onResetQuiz,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                shape = RoundedCornerShape(8.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Refresh,
                  contentDescription = null,
                  tint = Color.Black,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Retry All", color = Color.Black, fontSize = 12.sp)
              }

              OutlinedButton(
                onClick = onToggleFilterIncorrect,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(
                  if (filterOnlyIncorrect) "Show All (10)" else "Revisit Mistakes Only",
                  fontSize = 12.sp
                )
              }
            }
          } else {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  "10 Topic Practice MCQs",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  "Attempt all 10 questions and submit to test your speed & precision.",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            if (savedResult != null) {
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                "Last Attempt: ${savedResult.score}/10 on ${java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.getDefault()).format(savedResult.timestamp)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Medium
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))
    }

    // MCQ Questions
    itemsIndexed(questionsToDisplay) { visualIdx, mcq ->
      val originalIdx = mcqs.indexOf(mcq)
      val userAns = userSelectedAnswers[originalIdx]

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          // Question header
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "Q${originalIdx + 1}.",
              fontWeight = FontWeight.ExtraBold,
              color = MaterialTheme.colorScheme.primary,
              fontSize = 14.sp
            )

            if (showQuizResult) {
              val isCorrect = userAns == mcq.correctOptionIndex
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(if (isCorrect) Color(0xFF2E7D32) else Color(0xFFC62828))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  if (isCorrect) "CORRECT (+1)" else "INCORRECT (0)",
                  color = Color.White,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          // Question Text
          Text(
            text = mcq.question,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold
          )

          if (mcq.hindiQuestion.isNotBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = mcq.hindiQuestion,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.primary,
              fontSize = 12.sp
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 4 Options
          mcq.options.forEachIndexed { optIdx, optText ->
            val isSelected = userAns == optIdx
            val isTargetCorrect = optIdx == mcq.correctOptionIndex

            val optBackground = when {
              showQuizResult && isTargetCorrect -> Color(0xFF2E7D32).copy(alpha = 0.25f)
              showQuizResult && isSelected && !isTargetCorrect -> Color(0xFFC62828).copy(alpha = 0.25f)
              isSelected -> MaterialTheme.colorScheme.primaryContainer
              else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            }

            val optBorderColor = when {
              showQuizResult && isTargetCorrect -> Color(0xFF4CAF50)
              showQuizResult && isSelected && !isTargetCorrect -> Color(0xFFEF5350)
              isSelected -> MaterialTheme.colorScheme.primary
              else -> Color.Transparent
            }

            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, optBorderColor, RoundedCornerShape(8.dp))
                .background(optBackground)
                .clickable(enabled = !showQuizResult) {
                  onSelectAnswer(originalIdx, optIdx)
                }
                .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(
                      if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                    ),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = ('A'.code + optIdx).toChar().toString(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                  )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Text(
                  text = optText,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurface,
                  modifier = Modifier.weight(1f)
                )

                if (showQuizResult && isTargetCorrect) {
                  Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Correct",
                    tint = Color(0xFF4CAF50),
                    modifier = Modifier.size(18.dp)
                  )
                } else if (showQuizResult && isSelected && !isTargetCorrect) {
                  Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Wrong",
                    tint = Color(0xFFEF5350),
                    modifier = Modifier.size(18.dp)
                  )
                }
              }
            }
          }

          // Explanation when shown
          if (showQuizResult) {
            Spacer(modifier = Modifier.height(8.dp))
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                .padding(10.dp)
            ) {
              Column {
                Text(
                  text = "Explanation:",
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = mcq.explanation,
                  style = MaterialTheme.typography.bodySmall,
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
            }
          }
        }
      }
    }

    // Submit Action Button
    item {
      Spacer(modifier = Modifier.height(16.dp))

      if (!showQuizResult) {
        val answeredCount = userSelectedAnswers.size
        Button(
          onClick = onSubmitQuiz,
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("submit_topic_quiz_button"),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
          Icon(
            imageVector = Icons.Default.Quiz,
            contentDescription = null,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Submit Quiz ($answeredCount / ${mcqs.size} Answered)",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
        }
      } else {
        Button(
          onClick = onResetQuiz,
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
        ) {
          Icon(
            imageVector = Icons.Default.Refresh,
            contentDescription = null,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text("Reset and Try Again", fontWeight = FontWeight.Bold)
        }
      }

      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}
