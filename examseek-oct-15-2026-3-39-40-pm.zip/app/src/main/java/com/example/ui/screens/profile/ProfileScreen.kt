package com.example.ui.screens.profile

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.SubscriptionTier
import com.example.ui.viewmodel.MainViewModel

@Composable
fun ProfileScreen(
  viewModel: MainViewModel,
  onNavigateToBookmarks: () -> Unit,
  onNavigateToDailyLearning: () -> Unit,
  onNavigateToAiSolver: () -> Unit,
  onNavigateToSubscription: () -> Unit,
  onNavigateToTrustLegal: () -> Unit,
  onNavigateToAdmin: () -> Unit,
  onNavigateToBackendPlan: () -> Unit,
  onNavigateToLogin: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val currentUser by viewModel.currentUser.collectAsState()
  val attempts by viewModel.attempts.collectAsState()
  val bookmarks by viewModel.bookmarks.collectAsState()
  val wrongAnswers by viewModel.wrongAnswers.collectAsState()

  val tier = try { SubscriptionTier.valueOf(currentUser?.subscriptionTier ?: "FREE") } catch (e: Exception) { SubscriptionTier.FREE }
  val isAdmin = currentUser?.role == "ADMIN"

  var showAdminAuthDialog by remember { mutableStateOf(false) }
  var adminPassInput by remember { mutableStateOf("") }
  var adminPassError by remember { mutableStateOf<String?>(null) }
  var showTargetExamDialog by remember { mutableStateOf(false) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 16.dp)
      .verticalScroll(rememberScrollState())
      .testTag("profile_screen")
  ) {
    Spacer(modifier = Modifier.height(16.dp))

    Text(
      text = "Student Profile & Membership",
      style = MaterialTheme.typography.headlineSmall,
      fontWeight = FontWeight.ExtraBold
    )

    Spacer(modifier = Modifier.height(16.dp))

    // Profile Card
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primaryContainer)
        ) {
          Icon(
            imageVector = Icons.Default.Person,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(40.dp)
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (currentUser != null) {
          Text(
            text = currentUser?.name ?: "Student",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = currentUser?.email ?: "",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            // Target Exam Badge
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                .clickable { showTargetExamDialog = true }
                .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
              Icon(imageVector = Icons.Default.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = currentUser?.targetExam ?: "SSC CGL",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Subscription Tier Badge
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color(tier.badgeColor).copy(alpha = 0.15f))
                .clickable(onClick = onNavigateToSubscription)
                .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
              Icon(imageVector = Icons.Default.WorkspacePremium, contentDescription = null, tint = Color(tier.badgeColor), modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = tier.displayName,
                color = Color(tier.badgeColor),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              )
            }
          }
        } else {
          Text(
            text = "Guest Aspirant",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(8.dp))
          Button(onClick = onNavigateToLogin) {
            Icon(imageVector = Icons.Default.Login, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Login / Register")
          }
        }

        Spacer(modifier = Modifier.height(16.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(16.dp))

        // Mini Stats row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "${attempts.size}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(text = "Tests", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val totalQ = attempts.sumOf { it.totalQuestions }
            Text(text = "$totalQ", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(text = "Solved", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "${wrongAnswers.size}", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFFDC2626))
            Text(text = "Mistakes", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "${bookmarks.size}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(text = "Saved", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      text = "Study & Platform Tools",
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold
    )

    Spacer(modifier = Modifier.height(10.dp))

    // Action Menu items
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column {
        ProfileMenuItem(
          icon = Icons.Default.WorkspacePremium,
          title = "ExamSeek Pass & Subscriptions",
          subtitle = "Upgrade to Plus/Pro for unlimited tests & AI doubts",
          iconTint = Color(0xFFD97706),
          onClick = onNavigateToSubscription
        )

        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))

        ProfileMenuItem(
          icon = Icons.Default.AutoAwesome,
          title = "AI Doubt Guru",
          subtitle = "Step-by-step Hindi & English solutions for tricky questions",
          iconTint = MaterialTheme.colorScheme.primary,
          onClick = onNavigateToAiSolver
        )

        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))

        ProfileMenuItem(
          icon = Icons.Default.Newspaper,
          title = "Daily Learning & Mistake Vault",
          subtitle = "Current affairs, formula sheets, flashcards & mistakes",
          iconTint = Color(0xFF10B981),
          onClick = onNavigateToDailyLearning
        )

        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))

        ProfileMenuItem(
          icon = Icons.Default.Bookmark,
          title = "Saved Questions (Bookmarks)",
          subtitle = "${bookmarks.size} questions saved for revision",
          iconTint = Color(0xFF7C3AED),
          onClick = onNavigateToBookmarks
        )

        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))

        ProfileMenuItem(
          icon = Icons.Default.AdminPanelSettings,
          title = "Admin Panel & Content Studio",
          subtitle = if (isAdmin) "Authorized Admin Access" else "Protected Instructor / Admin Mode",
          iconTint = Color(0xFF0284C7),
          onClick = {
            if (isAdmin) {
              onNavigateToAdmin()
            } else {
              showAdminAuthDialog = true
            }
          }
        )

        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))

        ProfileMenuItem(
          icon = Icons.Default.Cloud,
          title = "Backend Architecture & Web API Plan",
          subtitle = "Production PostgreSQL, Auth & Next.js Website blueprint",
          iconTint = MaterialTheme.colorScheme.primary,
          onClick = onNavigateToBackendPlan
        )

        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))

        ProfileMenuItem(
          icon = Icons.Default.Security,
          title = "Trust, Policies & Disclaimers",
          subtitle = "Privacy policy, refund terms & support contact",
          iconTint = Color(0xFF64748B),
          onClick = onNavigateToTrustLegal
        )

        if (currentUser != null) {
          HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))

          ProfileMenuItem(
            icon = Icons.Default.Logout,
            title = "Logout Account",
            subtitle = "Switch account or take tests in guest mode",
            iconTint = MaterialTheme.colorScheme.error,
            onClick = { viewModel.logout() }
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(80.dp))
  }

  // Admin Access Verification Dialog
  if (showAdminAuthDialog) {
    AlertDialog(
      onDismissRequest = { showAdminAuthDialog = false },
      title = { Text("Admin Authorization Required", fontWeight = FontWeight.Bold) },
      text = {
        Column {
          Text(
            text = "Ordinary students cannot access admin operations. Please enter the academic administrator passcode or log in with admin@examseek.com.",
            style = MaterialTheme.typography.bodySmall
          )
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedTextField(
            value = adminPassInput,
            onValueChange = {
              adminPassInput = it
              adminPassError = null
            },
            label = { Text("Admin Passcode") },
            placeholder = { Text("admin123") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp)
          )
          if (adminPassError != null) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = adminPassError ?: "", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (adminPassInput == "admin123") {
              showAdminAuthDialog = false
              onNavigateToAdmin()
            } else {
              adminPassError = "Invalid passcode. Use 'admin123' or login as admin@examseek.com"
            }
          }
        ) {
          Text("Verify & Open")
        }
      },
      dismissButton = {
        TextButton(onClick = { showAdminAuthDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }

  // Target Exam & Goal Setting Dialog
  if (showTargetExamDialog) {
    val targetExamsList = listOf(
      "SSC CGL", "SSC CHSL", "SSC MTS", "RRB NTPC", "RRB Group D",
      "IBPS PO", "SBI Clerk", "UPSC Prelims", "UP Police SI", "NDA / CDS", "CTET", "State PCS"
    )
    var selectedExamName by remember { mutableStateOf(currentUser?.targetExam ?: "SSC CGL") }
    var selectedGoal by remember { mutableStateOf(currentUser?.dailyGoalQuestions ?: 20) }
    var selectedLang by remember { mutableStateOf(currentUser?.preferredLanguage ?: "ENGLISH") }

    AlertDialog(
      onDismissRequest = { showTargetExamDialog = false },
      title = { Text("Update Target Exam & Daily Goals", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
      text = {
        Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
          Text("Target Exam", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Spacer(modifier = Modifier.height(6.dp))
          targetExamsList.chunked(2).forEach { rowExams ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              rowExams.forEach { exam ->
                FilterChip(
                  selected = selectedExamName == exam,
                  onClick = { selectedExamName = exam },
                  label = { Text(exam, fontSize = 12.sp) },
                  modifier = Modifier.weight(1f)
                )
              }
              if (rowExams.size == 1) Spacer(modifier = Modifier.weight(1f))
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          Text("Daily Practice Goal (Questions)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            listOf(10, 15, 20, 30, 50).forEach { goal ->
              FilterChip(
                selected = selectedGoal == goal,
                onClick = { selectedGoal = goal },
                label = { Text("$goal Qs", fontSize = 11.sp) }
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          Text("Preferred Medium", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            FilterChip(
              selected = selectedLang == "ENGLISH",
              onClick = { selectedLang = "ENGLISH" },
              label = { Text("English", fontSize = 12.sp) },
              modifier = Modifier.weight(1f)
            )
            FilterChip(
              selected = selectedLang == "HINDI",
              onClick = { selectedLang = "HINDI" },
              label = { Text("हिंदी (Hindi)", fontSize = 12.sp) },
              modifier = Modifier.weight(1f)
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.updateTargetExamAndDate(selectedExamName, currentUser?.targetExamDate ?: (System.currentTimeMillis() + 68L * 24 * 3600 * 1000))
            viewModel.updateDailyGoal(selectedGoal)
            viewModel.updateLanguage(selectedLang)
            showTargetExamDialog = false
          }
        ) {
          Text("Save Changes")
        }
      },
      dismissButton = {
        TextButton(onClick = { showTargetExamDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }
}

@Composable
private fun ProfileMenuItem(
  icon: ImageVector,
  title: String,
  subtitle: String,
  iconTint: Color = MaterialTheme.colorScheme.primary,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(horizontal = 16.dp, vertical = 14.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Box(
      contentAlignment = Alignment.Center,
      modifier = Modifier
        .size(40.dp)
        .clip(RoundedCornerShape(8.dp))
        .background(iconTint.copy(alpha = 0.12f))
    ) {
      Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
    }

    Spacer(modifier = Modifier.width(14.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(text = title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
      Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }

    Icon(
      imageVector = Icons.AutoMirrored.Filled.ArrowForward,
      contentDescription = null,
      tint = MaterialTheme.colorScheme.onSurfaceVariant,
      modifier = Modifier.size(16.dp)
    )
  }
}
