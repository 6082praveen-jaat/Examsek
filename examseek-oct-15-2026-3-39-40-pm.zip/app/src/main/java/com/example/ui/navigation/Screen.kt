package com.example.ui.navigation

sealed class Screen(val route: String) {
  data object Home : Screen("home")
  data object Tests : Screen("tests")
  data object Practice : Screen("practice")
  data object DailyLearning : Screen("daily_learning")
  data object Analytics : Screen("analytics")
  data object Profile : Screen("profile")

  data object ExamRunner : Screen("exam_runner/{testId}") {
    fun createRoute(testId: String) = "exam_runner/$testId"
  }

  data object ExamResult : Screen("exam_result")
  data object SolutionReview : Screen("solution_review")
  data object Bookmarks : Screen("bookmarks")
  data object AiDoubtSolver : Screen("ai_doubt_solver")
  data object Subscription : Screen("subscription")
  data object TrustAndLegal : Screen("trust_and_legal")
  data object Login : Screen("login")
  data object Register : Screen("register")
  data object AdminPanel : Screen("admin_panel")
  data object BackendPlan : Screen("backend_plan")
  data object ExamGenerator : Screen("exam_generator")
  data object FormulaDetail : Screen("formula_detail/{topicId}") {
    fun createRoute(topicId: String) = "formula_detail/$topicId"
  }
}
