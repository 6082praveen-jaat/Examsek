package com.example.ui.screens.analytics

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.TestAttemptEntity
import com.example.ui.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AnalyticsScreen(
  viewModel: MainViewModel,
  onReviewAttempt: (TestAttemptEntity) -> Unit,
  modifier: Modifier = Modifier
) {
  val attempts by viewModel.attempts.collectAsState()

  val totalTests = attempts.size
  val totalQuestions = attempts.sumOf { it.totalQuestions }
  val totalCorrect = attempts.sumOf { it.correctCount }
  val overallAccuracy = if (totalQuestions > 0) (totalCorrect.toFloat() / totalQuestions) * 100f else 0f
  val avgScore = if (totalTests > 0) attempts.map { it.score }.average().toFloat() else 0f

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 16.dp)
      .testTag("analytics_screen")
  ) {
    item {
      Spacer(modifier = Modifier.height(16.dp))
      Text(
        text = "Performance Analytics",
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.ExtraBold
      )
      Text(
        text = "Detailed metrics from your full mock attempts and live quizzes",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(16.dp))
    }

    // 1. Overall Stats Grid Card
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Overall Preparation Summary",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            StatBox(label = "Tests Taken", value = "$totalTests", color = MaterialTheme.colorScheme.primary)
            StatBox(label = "Accuracy", value = String.format(Locale.US, "%.1f%%", overallAccuracy), color = Color(0xFF059669))
            StatBox(label = "Avg Score", value = String.format(Locale.US, "%.1f", avgScore), color = Color(0xFFD97706))
            StatBox(label = "Solved Qs", value = "$totalQuestions", color = Color(0xFF7C3AED))
          }
        }
      }
      Spacer(modifier = Modifier.height(16.dp))
    }

    // 2. Subject Mastery Meters
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Subject-Wise Proficiency",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Icon(imageVector = Icons.Default.TrendingUp, contentDescription = null, tint = Color(0xFF10B981))
          }

          Spacer(modifier = Modifier.height(14.dp))

          SubjectMeter(subject = "Quantitative Aptitude", proficiency = 0.78f, label = "78% (Strong)")
          Spacer(modifier = Modifier.height(8.dp))
          SubjectMeter(subject = "Logical Reasoning", proficiency = 0.85f, label = "85% (Very Strong)")
          Spacer(modifier = Modifier.height(8.dp))
          SubjectMeter(subject = "General Awareness", proficiency = 0.62f, label = "62% (Moderate)")
          Spacer(modifier = Modifier.height(8.dp))
          SubjectMeter(subject = "English Language", proficiency = 0.74f, label = "74% (Good)")
        }
      }
      Spacer(modifier = Modifier.height(20.dp))
    }

    // 3. Test History List Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(imageVector = Icons.Default.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Test History (${attempts.size})",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
        }
      }
      Spacer(modifier = Modifier.height(10.dp))
    }

    if (attempts.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(
              imageVector = Icons.Default.AutoGraph,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "No tests attempted yet",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "Take your first live mock or daily drill to generate deep analytics!",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(attempts, key = { it.attemptId }) { attempt ->
        TestHistoryItemCard(
          attempt = attempt,
          onReviewSolutions = { onReviewAttempt(attempt) }
        )
        Spacer(modifier = Modifier.height(10.dp))
      }
    }

    item {
      Spacer(modifier = Modifier.height(80.dp))
    }
  }
}

@Composable
private fun StatBox(label: String, value: String, color: Color) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
    Text(text = label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
  }
}

@Composable
private fun SubjectMeter(subject: String, proficiency: Float, label: String) {
  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(text = subject, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
      Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    Spacer(modifier = Modifier.height(4.dp))
    LinearProgressIndicator(
      progress = { proficiency },
      modifier = Modifier
        .fillMaxWidth()
        .height(7.dp)
        .clip(RoundedCornerShape(4.dp)),
      color = if (proficiency > 0.75f) Color(0xFF10B981) else if (proficiency > 0.65f) Color(0xFF3B82F6) else Color(0xFFF59E0B),
      trackColor = MaterialTheme.colorScheme.surfaceVariant
    )
  }
}

@Composable
private fun TestHistoryItemCard(
  attempt: TestAttemptEntity,
  onReviewSolutions: () -> Unit
) {
  val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
  val formattedDate = dateFormat.format(Date(attempt.attemptedAt))

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("history_item_${attempt.attemptId}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = attempt.category,
          fontWeight = FontWeight.Bold,
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.primary,
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .padding(horizontal = 6.dp, vertical = 2.dp)
        )
        Text(
          text = formattedDate,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = attempt.testTitle,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Score: ${String.format(Locale.US, "%.1f", attempt.score)} / ${attempt.totalMarks.toInt()}",
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary,
            fontSize = 15.sp
          )
          Text(
            text = "Accuracy: ${String.format(Locale.US, "%.1f%%", attempt.accuracy)} • ${attempt.correctCount} Correct, ${attempt.incorrectCount} Wrong",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        OutlinedButton(
          onClick = onReviewSolutions,
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.height(36.dp)
        ) {
          Icon(imageVector = Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Solutions", fontSize = 12.sp)
        }
      }
    }
  }
}
