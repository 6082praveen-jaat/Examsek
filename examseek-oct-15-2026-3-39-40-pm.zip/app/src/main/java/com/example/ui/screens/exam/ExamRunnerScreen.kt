package com.example.ui.screens.exam

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.AppLanguage
import com.example.domain.model.TestResult
import com.example.ui.components.CountdownTimerView
import com.example.ui.components.QuestionPaletteSheet
import com.example.ui.components.VerifiedBadge
import com.example.ui.viewmodel.ExamViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExamRunnerScreen(
  viewModel: ExamViewModel,
  onFinishTest: (TestResult) -> Unit,
  onExit: () -> Unit
) {
  val currentTest by viewModel.currentTest.collectAsState()
  val questions by viewModel.questions.collectAsState()
  val currentIndex by viewModel.currentIndex.collectAsState()
  val userAnswers by viewModel.userAnswers.collectAsState()
  val markedForReview by viewModel.markedForReview.collectAsState()
  val bookmarks by viewModel.bookmarks.collectAsState()
  val applyNegativeMarking by viewModel.applyNegativeMarking.collectAsState()
  val examLanguage by viewModel.examLanguage.collectAsState()
  val timeRemainingSeconds by viewModel.timeRemainingSeconds.collectAsState()
  val isTimerRunning by viewModel.isTimerRunning.collectAsState()
  val isSubmitting by viewModel.isSubmitting.collectAsState()

  var showPalette by remember { mutableStateOf(false) }
  var showSubmitConfirmDialog by remember { mutableStateOf(false) }
  var showExitConfirmDialog by remember { mutableStateOf(false) }

  val testResult by viewModel.testResult.collectAsState()

  androidx.compose.runtime.LaunchedEffect(testResult) {
    val res = testResult
    if (res != null) {
      onFinishTest(res)
    }
  }

  androidx.activity.compose.BackHandler {
    showExitConfirmDialog = true
  }

  val currentQ = viewModel.currentQuestion

  if (currentTest == null || questions.isEmpty()) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        CircularProgressIndicator()
        Spacer(modifier = Modifier.height(12.dp))
        Text("Loading CBT Exam Environment...", style = MaterialTheme.typography.bodyMedium)
      }
    }
    return
  }

  val selectedOption = if (currentQ != null) userAnswers[currentQ.id] else null
  val isMarked = if (currentQ != null) markedForReview.contains(currentQ.id) else false
  val isBookmarked = if (currentQ != null) bookmarks.contains(currentQ.id) else false

  val isHindi = examLanguage == AppLanguage.HINDI && !currentQ?.hindiQuestionText.isNullOrBlank()
  val displayedStatement = if (isHindi) currentQ?.hindiQuestionText ?: currentQ?.questionText.orEmpty() else currentQ?.questionText.orEmpty()
  val displayedOptions = if (isHindi && currentQ?.hindiOptions?.isNotEmpty() == true) currentQ.hindiOptions else currentQ?.options ?: emptyList()

  Scaffold(
    topBar = {
      CenterAlignedTopAppBar(
        title = {
          CountdownTimerView(timeRemainingSeconds = timeRemainingSeconds)
        },
        navigationIcon = {
          IconButton(onClick = { showExitConfirmDialog = true }) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Exit Test")
          }
        },
        actions = {
          // Bilingual toggle (EN / हिंदी)
          IconButton(
            onClick = { viewModel.toggleExamLanguage() },
            modifier = Modifier.testTag("toggle_exam_language_btn")
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
              Icon(imageVector = Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(13.dp))
              Spacer(modifier = Modifier.width(3.dp))
              Text(
                text = if (examLanguage == AppLanguage.HINDI) "हिंदी" else "EN",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          // Pause/resume timer button
          IconButton(onClick = { viewModel.togglePauseTimer() }) {
            Icon(
              imageVector = if (isTimerRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
              contentDescription = "Pause or Resume Timer",
              tint = MaterialTheme.colorScheme.primary
            )
          }

          // Question Palette icon
          IconButton(
            onClick = { showPalette = true },
            modifier = Modifier.testTag("open_palette_button")
          ) {
            Icon(
              imageVector = Icons.Default.GridView,
              contentDescription = "Question Palette",
              tint = MaterialTheme.colorScheme.primary
            )
          }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface
        )
      )
    },
    bottomBar = {
      // CBT Action Bar: Prev, Clear, Mark Review, Save & Next / Submit
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.surface)
          .padding(horizontal = 16.dp, vertical = 10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Clear Response
          TextButton(
            onClick = { viewModel.clearResponse() },
            enabled = selectedOption != null,
            modifier = Modifier.testTag("clear_response_button")
          ) {
            Text("Clear", fontSize = 13.sp)
          }

          // Mark For Review
          OutlinedButton(
            onClick = {
              viewModel.toggleMarkForReview()
              viewModel.nextQuestion()
            },
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.testTag("mark_review_button")
          ) {
            Text(if (isMarked) "Unmark" else "Mark for Review", fontSize = 12.sp)
          }

          // Previous & Next navigation
          Row {
            IconButton(
              onClick = { viewModel.previousQuestion() },
              enabled = currentIndex > 0,
              modifier = Modifier.testTag("prev_question_button")
            ) {
              Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous")
            }

            if (currentIndex < questions.size - 1) {
              Button(
                onClick = { viewModel.nextQuestion() },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("next_question_button")
              ) {
                Text("Save & Next", fontSize = 13.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(14.dp))
              }
            } else {
              Button(
                onClick = { showSubmitConfirmDialog = true },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                modifier = Modifier.testTag("submit_exam_button")
              ) {
                Text("Submit Test", fontSize = 13.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .padding(horizontal = 16.dp)
        .verticalScroll(rememberScrollState())
    ) {
      Spacer(modifier = Modifier.height(8.dp))

      // Exam Sub-header: Subject, Topic, Marks Info, Bookmark, Negative marking toggle
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Question ${currentIndex + 1} of ${questions.size}",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "${currentQ?.subject} • ${currentQ?.topic} (+${currentTest?.marksPerQuestion?.toInt() ?: 2})",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          // Negative Marking Toggle Chip
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .clip(RoundedCornerShape(20.dp))
              .background(if (applyNegativeMarking) Color(0xFFFEE2E2) else Color(0xFFDCFCE7))
              .clickable { viewModel.setNegativeMarkingEnabled(!applyNegativeMarking) }
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Text(
              text = if (applyNegativeMarking) "-${currentTest?.negativeMarkingRate} Neg" else "No Neg",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = if (applyNegativeMarking) Color(0xFFDC2626) else Color(0xFF16A34A)
            )
          }

          Spacer(modifier = Modifier.width(8.dp))

          // Bookmark Question Button
          IconButton(
            onClick = { viewModel.toggleBookmarkCurrentQuestion() },
            modifier = Modifier.testTag("bookmark_question_btn")
          ) {
            Icon(
              imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
              contentDescription = "Bookmark Question",
              tint = if (isBookmarked) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Question Statement Card
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("current_question_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "Difficulty: ${currentQ?.difficulty?.name} • ${currentQ?.source}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            VerifiedBadge(isVerified = currentQ?.isVerified == true)
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = displayedStatement,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium,
            lineHeight = 24.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "Select one option:",
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontWeight = FontWeight.SemiBold
      )

      Spacer(modifier = Modifier.height(8.dp))

      // 4 MCQ Options
      val optionLabels = listOf("A", "B", "C", "D")
      displayedOptions.forEachIndexed { index, optionText ->
        val isChosen = selectedOption == index

        val borderModifier = if (isChosen) {
          Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
        } else {
          Modifier.border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
        }

        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .testTag("option_card_$index")
            .clip(RoundedCornerShape(12.dp))
            .clickable { viewModel.selectOption(index) }
            .then(borderModifier),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isChosen) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface
          )
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              contentAlignment = Alignment.Center,
              modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(
                  if (isChosen) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
              Text(
                text = optionLabels.getOrElse(index) { "?" },
                color = if (isChosen) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Text(
              text = optionText,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.weight(1f)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }

  // Question Palette Bottom Sheet
  if (showPalette) {
    QuestionPaletteSheet(
      questions = questions,
      currentIndex = currentIndex,
      getQuestionStatus = { viewModel.getQuestionStatus(it) },
      onQuestionSelect = { index -> viewModel.goToQuestion(index) },
      onSubmitClick = { showSubmitConfirmDialog = true },
      onDismiss = { showPalette = false }
    )
  }

  // Submit Test Confirmation Dialog
  if (showSubmitConfirmDialog) {
    val attemptedCount = userAnswers.values.filterNotNull().size
    val unattemptedCount = questions.size - attemptedCount
    val markedCount = markedForReview.size

    AlertDialog(
      onDismissRequest = { showSubmitConfirmDialog = false },
      title = { Text("Submit Test Summary", fontWeight = FontWeight.Bold) },
      text = {
        Column {
          Text(text = "Are you sure you want to finish the exam?", style = MaterialTheme.typography.bodyMedium)
          Spacer(modifier = Modifier.height(12.dp))

          Card(
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Total Questions:", style = MaterialTheme.typography.bodySmall)
                Text("${questions.size}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
              }
              Spacer(modifier = Modifier.height(4.dp))
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Attempted:", style = MaterialTheme.typography.bodySmall, color = Color(0xFF059669))
                Text("$attemptedCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = Color(0xFF059669))
              }
              Spacer(modifier = Modifier.height(4.dp))
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Unattempted:", style = MaterialTheme.typography.bodySmall, color = Color(0xFFDC2626))
                Text("$unattemptedCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = Color(0xFFDC2626))
              }
              Spacer(modifier = Modifier.height(4.dp))
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Marked for Review:", style = MaterialTheme.typography.bodySmall, color = Color(0xFF7C3AED))
                Text("$markedCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = Color(0xFF7C3AED))
              }
              Spacer(modifier = Modifier.height(4.dp))
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Negative Marking:", style = MaterialTheme.typography.bodySmall)
                Text(
                  if (applyNegativeMarking) "Active (${currentTest?.negativeMarkingRate})" else "Disabled",
                  fontWeight = FontWeight.Bold,
                  style = MaterialTheme.typography.bodySmall
                )
              }
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            showSubmitConfirmDialog = false
            viewModel.submitTest { result ->
              onFinishTest(result)
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
          modifier = Modifier.testTag("confirm_submit_btn")
        ) {
          Text("Confirm Submit")
        }
      },
      dismissButton = {
        TextButton(onClick = { showSubmitConfirmDialog = false }) {
          Text("Back to Test")
        }
      }
    )
  }

  // Exit Confirmation Dialog
  if (showExitConfirmDialog) {
    AlertDialog(
      onDismissRequest = { showExitConfirmDialog = false },
      title = { Text("Pause & Exit Test?", fontWeight = FontWeight.Bold) },
      text = {
        Text("Your progress is securely saved. You can resume this attempt anytime from the student dashboard.")
      },
      confirmButton = {
        Button(
          onClick = {
            showExitConfirmDialog = false
            onExit()
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
          Text("Save & Exit")
        }
      },
      dismissButton = {
        TextButton(onClick = { showExitConfirmDialog = false }) {
          Text("Continue Test")
        }
      }
    )
  }
}
