package com.example.domain.model

enum class ExamCategory(
  val id: String,
  val displayName: String,
  val iconName: String,
  val description: String,
  val popularExams: List<String>
) {
  SSC(
    id = "SSC",
    displayName = "SSC",
    iconName = "ssc",
    description = "Staff Selection Commission exams",
    popularExams = listOf("SSC CGL", "SSC CHSL", "SSC MTS", "SSC GD Constable", "SSC CPO")
  ),
  RAILWAY(
    id = "RAILWAY",
    displayName = "Railway",
    iconName = "railway",
    description = "Indian Railways RRB recruitments",
    popularExams = listOf("RRB NTPC", "RRB Group D", "RRB ALP & Technician", "RRB JE")
  ),
  BANKING(
    id = "BANKING",
    displayName = "Banking",
    iconName = "banking",
    description = "Public & Private Sector Bank exams",
    popularExams = listOf("IBPS PO", "SBI PO", "IBPS Clerk", "SBI Clerk", "RBI Grade B")
  ),
  UPSC(
    id = "UPSC",
    displayName = "UPSC",
    iconName = "upsc",
    description = "Union Public Service Commission",
    popularExams = listOf("Civil Services Prelims", "CAPF AC", "CDS", "NDA", "EPFO")
  ),
  STATE_PCS(
    id = "STATE_PCS",
    displayName = "State PCS",
    iconName = "state_pcs",
    description = "State Public Service Commissions",
    popularExams = listOf("UPPSC", "BPSC", "MPPSC", "RAS (RPSC)", "WBPSC")
  ),
  POLICE(
    id = "POLICE",
    displayName = "Police",
    iconName = "police",
    description = "State & Central Police Services",
    popularExams = listOf("UP Police SI", "Delhi Police Constable", "Bihar Police SI", "MP Police")
  ),
  DEFENCE(
    id = "DEFENCE",
    displayName = "Defence",
    iconName = "defence",
    description = "Armed Forces & Paramilitary",
    popularExams = listOf("NDA", "CDS", "AFCAT", "Indian Navy SSR", "Air Force Agniveer")
  ),
  TEACHING(
    id = "TEACHING",
    displayName = "Teaching",
    iconName = "teaching",
    description = "Central & State Teacher Eligibility",
    popularExams = listOf("CTET Paper 1 & 2", "UPTET", "KVS PRT/TGT/PGT", "Super TET")
  );

  companion object {
    fun fromId(id: String): ExamCategory =
      entries.find { it.id.equals(id, ignoreCase = true) } ?: SSC
  }
}

enum class TestType(val displayName: String) {
  FULL_MOCK("Full Mock Test"),
  SECTIONAL_TEST("Sectional Test"),
  TOPIC_TEST("Topic Test"),
  DAILY_QUIZ("Daily Live Quiz"),
  PRACTICE_SET("Practice Set"),
  PYQ_PAPER("Previous Year Paper (PYQ)")
}

enum class Subject(val displayName: String) {
  QUANT("Quantitative Aptitude"),
  REASONING("Logical Reasoning"),
  GENERAL_AWARENESS("General Awareness"),
  ENGLISH("English Language"),
  CURRENT_AFFAIRS("Current Affairs"),
  GENERAL_SCIENCE("General Science")
}

enum class AppLanguage(val code: String, val displayName: String) {
  ENGLISH("en", "English"),
  HINDI("hi", "हिंदी (Hindi)")
}

enum class SubscriptionTier(val displayName: String, val badgeColor: Long) {
  FREE("Free", 0xFF64748B),
  PLUS("ExamSeek Plus", 0xFF0D9488),
  PRO("ExamSeek Pro", 0xFFD97706)
}
