package com.example.data.formula

import android.content.Context
import android.content.SharedPreferences
import com.example.domain.formula.FormulaSubject
import com.example.domain.formula.FormulaTopic
import com.example.domain.formula.TopicProgress
import com.example.domain.formula.TopicQuizResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class FormulaRepository(context: Context) {

  private val prefs: SharedPreferences =
    context.getSharedPreferences("examseek_formula_vault", Context.MODE_PRIVATE)

  // Aggregate all topics from all subject parts
  val allTopics: List<FormulaTopic> by lazy {
    MathTopicsPart1.topics +
      MathTopicsPart2.topics +
      MathTopicsPart3.topics +
      ReasoningTopicsPart1.topics +
      ReasoningTopicsPart2.topics +
      EnglishTopicsPart1.topics +
      EnglishTopicsPart2.topics
  }

  private val topicMap: Map<String, FormulaTopic> by lazy {
    allTopics.associateBy { it.id }
  }

  // Reactive state flows for UI
  private val _bookmarkedTopicIds = MutableStateFlow<Set<String>>(emptySet())
  val bookmarkedTopicIds: StateFlow<Set<String>> = _bookmarkedTopicIds.asStateFlow()

  private val _completedTopicIds = MutableStateFlow<Set<String>>(emptySet())
  val completedTopicIds: StateFlow<Set<String>> = _completedTopicIds.asStateFlow()

  private val _recentlyViewedIds = MutableStateFlow<List<String>>(emptyList())
  val recentlyViewedIds: StateFlow<List<String>> = _recentlyViewedIds.asStateFlow()

  private val _quizResults = MutableStateFlow<Map<String, TopicQuizResult>>(emptyMap())
  val quizResults: StateFlow<Map<String, TopicQuizResult>> = _quizResults.asStateFlow()

  init {
    loadPersistedData()
  }

  private fun loadPersistedData() {
    val bSet = prefs.getStringSet("bookmarked_topics", emptySet()) ?: emptySet()
    _bookmarkedTopicIds.value = bSet

    val cSet = prefs.getStringSet("completed_topics", emptySet()) ?: emptySet()
    _completedTopicIds.value = cSet

    val recentRaw = prefs.getString("recent_topics", "[]") ?: "[]"
    val recentList = mutableListOf<String>()
    try {
      val arr = JSONArray(recentRaw)
      for (i in 0 until arr.length()) {
        recentList.add(arr.getString(i))
      }
    } catch (_: Exception) {}
    _recentlyViewedIds.value = recentList

    val quizRaw = prefs.getString("quiz_results", "{}") ?: "{}"
    val qMap = mutableMapOf<String, TopicQuizResult>()
    try {
      val obj = JSONObject(quizRaw)
      val keys = obj.keys()
      while (keys.hasNext()) {
        val topicId = keys.next()
        val item = obj.getJSONObject(topicId)
        val score = item.getInt("score")
        val total = item.getInt("total")
        val timestamp = item.getLong("timestamp")
        val incorrectArr = item.getJSONArray("incorrectIndices")
        val incorrectList = mutableListOf<Int>()
        for (k in 0 until incorrectArr.length()) {
          incorrectList.add(incorrectArr.getInt(k))
        }
        qMap[topicId] = TopicQuizResult(
          topicId = topicId,
          score = score,
          totalQuestions = total,
          incorrectQuestionIndices = incorrectList,
          timestamp = timestamp
        )
      }
    } catch (_: Exception) {}
    _quizResults.value = qMap
  }

  fun getTopicById(id: String): FormulaTopic? {
    return topicMap[id]
  }

  fun getTopicsBySubject(subject: FormulaSubject): List<FormulaTopic> {
    return allTopics.filter { it.subject == subject }
  }

  fun searchTopics(query: String, subject: FormulaSubject?): List<FormulaTopic> {
    val q = query.trim().lowercase()
    return allTopics.filter { topic ->
      (subject == null || topic.subject == subject) &&
        (q.isEmpty() ||
          topic.title.lowercase().contains(q) ||
          topic.hindiTitle.lowercase().contains(q) ||
          topic.chapter.lowercase().contains(q) ||
          topic.summary.lowercase().contains(q) ||
          topic.coreFormula.lowercase().contains(q))
    }
  }

  fun recordTopicView(topicId: String) {
    val current = _recentlyViewedIds.value.toMutableList()
    current.remove(topicId)
    current.add(0, topicId)
    val trimmed = current.take(15)
    _recentlyViewedIds.value = trimmed

    val arr = JSONArray(trimmed)
    prefs.edit().putString("recent_topics", arr.toString()).apply()
  }

  fun toggleBookmark(topicId: String) {
    val current = _bookmarkedTopicIds.value.toMutableSet()
    if (current.contains(topicId)) {
      current.remove(topicId)
    } else {
      current.add(topicId)
    }
    _bookmarkedTopicIds.value = current
    prefs.edit().putStringSet("bookmarked_topics", current).apply()
  }

  fun toggleCompleted(topicId: String) {
    val current = _completedTopicIds.value.toMutableSet()
    if (current.contains(topicId)) {
      current.remove(topicId)
    } else {
      current.add(topicId)
    }
    _completedTopicIds.value = current
    prefs.edit().putStringSet("completed_topics", current).apply()
  }

  fun recordQuizAttempt(result: TopicQuizResult) {
    val map = _quizResults.value.toMutableMap()
    map[result.topicId] = result
    _quizResults.value = map

    // Auto mark as completed if score >= 60%
    if (result.score >= (result.totalQuestions * 0.6)) {
      val cSet = _completedTopicIds.value.toMutableSet()
      cSet.add(result.topicId)
      _completedTopicIds.value = cSet
      prefs.edit().putStringSet("completed_topics", cSet).apply()
    }

    // Persist to json
    try {
      val rootObj = JSONObject()
      for ((tid, res) in map) {
        val o = JSONObject()
        o.put("score", res.score)
        o.put("total", res.totalQuestions)
        o.put("timestamp", res.timestamp)
        val arr = JSONArray()
        res.incorrectQuestionIndices.forEach { arr.put(it) }
        o.put("incorrectIndices", arr)
        rootObj.put(tid, o)
      }
      prefs.edit().putString("quiz_results", rootObj.toString()).apply()
    } catch (_: Exception) {}
  }

  fun getTopicProgress(topicId: String): TopicProgress {
    val isBookmarked = _bookmarkedTopicIds.value.contains(topicId)
    val isCompleted = _completedTopicIds.value.contains(topicId)
    val quizResult = _quizResults.value[topicId]
    return TopicProgress(
      topicId = topicId,
      isBookmarked = isBookmarked,
      isCompleted = isCompleted,
      lastScore = quizResult?.score ?: 0,
      totalQuestions = quizResult?.totalQuestions ?: 0,
      incorrectQuestionIndices = quizResult?.incorrectQuestionIndices ?: emptyList(),
      lastAttemptTimestamp = quizResult?.timestamp ?: 0L
    )
  }

  fun getSubjectCompletionStats(subject: FormulaSubject): Pair<Int, Int> {
    val topics = getTopicsBySubject(subject)
    val completedCount = topics.count { _completedTopicIds.value.contains(it.id) }
    return Pair(completedCount, topics.size)
  }
}
