package com.example

import com.example.data.ai.ExamQuestionGeneratorService
import com.example.data.ai.GenerationResult
import com.example.domain.model.ExamDetail
import com.example.domain.model.ExamRegistry
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class QuestionGeneratorAndExamTest {

  @Test
  fun testExamRegistryCompleteness() {
    val exams = ExamRegistry.allExams
    assertTrue("Exams registry should contain at least 10 major competitive exams", exams.size >= 10)

    val sscCgl = ExamRegistry.findExam("SSC CGL")
    assertNotNull("SSC CGL must be present in registry", sscCgl)
    assertEquals("SSC CGL", sscCgl?.name)
    assertTrue("SSC CGL must have verified marking scheme", sscCgl?.verifiedMarkingScheme == true)
    assertEquals(2.0f, sscCgl?.defaultMarksPerQuestion ?: 0f, 0.01f)
    assertEquals(0.5f, sscCgl?.defaultNegativeMarking ?: 0f, 0.01f)

    val rrbNtpc = ExamRegistry.findExam("Railway RRB NTPC")
    assertNotNull("RRB NTPC must be present in registry", rrbNtpc)
    assertEquals(0.33f, rrbNtpc?.defaultNegativeMarking ?: 0f, 0.01f)
  }

  @Test
  fun testContentHashDeduplication() {
    val hash1 = ExamQuestionGeneratorService.computeContentHash(
      qText = "What is the capital of India?",
      a = "New Delhi",
      b = "Mumbai",
      c = "Kolkata",
      d = "Chennai"
    )

    val hash2 = ExamQuestionGeneratorService.computeContentHash(
      qText = "what is the capital of india? ",
      a = "New Delhi",
      b = "Mumbai",
      c = "Kolkata",
      d = "Chennai"
    )

    val hashDifferent = ExamQuestionGeneratorService.computeContentHash(
      qText = "What is the financial capital of India?",
      a = "New Delhi",
      b = "Mumbai",
      c = "Kolkata",
      d = "Chennai"
    )

    assertEquals("Normalized questions should produce identical hashes", hash1, hash2)
    assertFalse("Different questions must produce different hashes", hash1 == hashDifferent)
  }

  @Test
  fun testAcademicBatchGenerationWithDeduplication() = runBlocking {
    val service = ExamQuestionGeneratorService()
    val sscExam = ExamRegistry.findExam("SSC CGL")!!

    val existingHashes = mutableSetOf<String>()

    val result = service.generateQuestionBatch(
      examDetail = sscExam,
      stage = "Tier-1",
      subject = "Quantitative Aptitude",
      topic = "Profit & Loss",
      difficulty = "MEDIUM",
      language = "ENGLISH",
      batchSize = 10,
      existingHashesChecker = { hash -> existingHashes.contains(hash) }
    )

    assertTrue("Generation should succeed", result is GenerationResult.Success)
    val success = result as GenerationResult.Success
    assertEquals("Should generate requested batch count", 10, success.questions.size)

    success.questions.forEach { q ->
      assertEquals("Each question must have 4 options", 4, listOf(q.optionA, q.optionB, q.optionC, q.optionD).size)
      assertTrue("Correct option index must be 0..3", q.correctOptionIndex in 0..3)
      assertTrue("Explanation must not be empty", q.explanation.isNotBlank())
      assertEquals("Source label must be AI_GENERATED_PRACTICE", "AI_GENERATED_PRACTICE", q.sourceLabel)
      assertFalse("AI generated questions must NOT be marked verified until reviewed", q.isVerified)
      existingHashes.add(q.contentHash)
    }

    // Attempt second generation with duplicate checker active
    val secondResult = service.generateQuestionBatch(
      examDetail = sscExam,
      stage = "Tier-1",
      subject = "Quantitative Aptitude",
      topic = "Profit & Loss",
      difficulty = "MEDIUM",
      language = "ENGLISH",
      batchSize = 5,
      existingHashesChecker = { hash -> existingHashes.contains(hash) }
    )

    assertTrue(secondResult is GenerationResult.Success)
  }
}
