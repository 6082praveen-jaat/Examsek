package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.ActiveTestSessionEntity
import com.example.data.local.entity.BookmarkEntity
import com.example.data.local.entity.QuestionEntity
import com.example.data.local.entity.StudyMaterialEntity
import com.example.data.local.entity.SubscriptionOrderEntity
import com.example.data.local.entity.TestAttemptEntity
import com.example.data.local.entity.TestEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WrongAnswerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
  @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
  suspend fun getUserByEmail(email: String): UserEntity?

  @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
  suspend fun getUserById(id: Long): UserEntity?

  @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
  fun getUserByIdFlow(id: Long): Flow<UserEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertUser(user: UserEntity): Long

  @Query("UPDATE users SET subscriptionTier = :tier, subscriptionExpiry = :expiry WHERE id = :userId")
  suspend fun updateSubscription(userId: Long, tier: String, expiry: Long)

  @Query("UPDATE users SET targetExam = :targetExam, targetExamDate = :examDate WHERE id = :userId")
  suspend fun updateTargetExamAndDate(userId: Long, targetExam: String, examDate: Long)

  @Query("UPDATE users SET preferredLanguage = :language WHERE id = :userId")
  suspend fun updateLanguage(userId: Long, language: String)

  @Query("UPDATE users SET aiDoubtsUsedToday = :count, lastAiDoubtDate = :date WHERE id = :userId")
  suspend fun updateAiDoubtUsage(userId: Long, count: Int, date: String)

  @Query("UPDATE users SET dailyGoalQuestions = :goal WHERE id = :userId")
  suspend fun updateDailyGoal(userId: Long, goal: Int)

  @Query("SELECT COUNT(*) FROM users")
  suspend fun getUserCount(): Int

  @Query("SELECT * FROM users")
  fun getAllUsers(): Flow<List<UserEntity>>
}

@Dao
interface TestDao {
  @Query("SELECT * FROM tests")
  fun getAllTests(): Flow<List<TestEntity>>

  @Query("SELECT * FROM tests WHERE category = :category")
  fun getTestsByCategory(category: String): Flow<List<TestEntity>>

  @Query("SELECT * FROM tests WHERE id = :testId LIMIT 1")
  suspend fun getTestById(testId: String): TestEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTests(tests: List<TestEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTest(test: TestEntity)

  @Query("DELETE FROM tests WHERE id = :testId")
  suspend fun deleteTest(testId: String)
}

@Dao
interface QuestionDao {
  @Query("SELECT * FROM questions WHERE testId = :testId")
  suspend fun getQuestionsForTest(testId: String): List<QuestionEntity>

  @Query("SELECT * FROM questions WHERE testId = :testId")
  fun getQuestionsForTestFlow(testId: String): Flow<List<QuestionEntity>>

  @Query("SELECT * FROM questions WHERE id = :id LIMIT 1")
  suspend fun getQuestionById(id: String): QuestionEntity?

  @Query("SELECT * FROM questions")
  fun getAllQuestions(): Flow<List<QuestionEntity>>

  @Query("SELECT * FROM questions WHERE subject = :subject")
  fun getQuestionsBySubject(subject: String): Flow<List<QuestionEntity>>

  @Query("SELECT * FROM questions WHERE topic = :topic")
  fun getQuestionsByTopic(topic: String): Flow<List<QuestionEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertQuestions(questions: List<QuestionEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertQuestion(question: QuestionEntity)

  @Query("SELECT COUNT(*) FROM questions")
  suspend fun getQuestionCount(): Int

  @Query("SELECT * FROM questions WHERE targetExam = :exam ORDER BY createdAt DESC")
  fun getQuestionsByExamFlow(exam: String): Flow<List<QuestionEntity>>

  @Query("SELECT * FROM questions WHERE targetExam = :exam AND (:subject = 'All' OR subject = :subject) AND (:topic = 'All' OR topic = :topic) ORDER BY createdAt DESC")
  fun getFilteredQuestionsFlow(exam: String, subject: String, topic: String): Flow<List<QuestionEntity>>

  @Query("SELECT * FROM questions WHERE targetExam = :exam AND (:subject = 'All' OR subject = :subject) AND (:topic = 'All' OR topic = :topic) ORDER BY createdAt DESC LIMIT :limit OFFSET :offset")
  suspend fun getPagedQuestions(exam: String, subject: String, topic: String, limit: Int, offset: Int): List<QuestionEntity>

  @Query("SELECT * FROM questions WHERE targetExam = :exam AND (:subject = 'All' OR subject = :subject) ORDER BY RANDOM() LIMIT :limit")
  suspend fun getRandomQuestionsForExam(exam: String, subject: String, limit: Int): List<QuestionEntity>

  @Query("SELECT COUNT(*) FROM questions WHERE targetExam = :exam")
  suspend fun getQuestionCountForExam(exam: String): Int

  @Query("SELECT COUNT(*) FROM questions WHERE targetExam = :exam AND topic = :topic")
  suspend fun getQuestionCountForExamTopic(exam: String, topic: String): Int

  @Query("SELECT EXISTS(SELECT 1 FROM questions WHERE contentHash = :hash AND contentHash != '')")
  suspend fun existsByContentHash(hash: String): Boolean

  @Query("SELECT * FROM questions WHERE sourceLabel = 'NEEDS_REVIEW' OR isVerified = 0 ORDER BY createdAt DESC")
  fun getQuestionsPendingReviewFlow(): Flow<List<QuestionEntity>>

  @Query("UPDATE questions SET isVerified = :verified, sourceLabel = :sourceLabel WHERE id = :id")
  suspend fun updateQuestionVerification(id: String, verified: Boolean, sourceLabel: String)

  @Query("DELETE FROM questions WHERE id = :id")
  suspend fun deleteQuestion(id: String)
}

@Dao
interface TestAttemptDao {
  @Query("SELECT * FROM test_attempts ORDER BY attemptedAt DESC")
  fun getAllAttempts(): Flow<List<TestAttemptEntity>>

  @Query("SELECT * FROM test_attempts WHERE userId = :userId ORDER BY attemptedAt DESC")
  fun getAttemptsForUser(userId: Long): Flow<List<TestAttemptEntity>>

  @Query("SELECT * FROM test_attempts WHERE attemptId = :attemptId LIMIT 1")
  suspend fun getAttemptById(attemptId: String): TestAttemptEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAttempt(attempt: TestAttemptEntity)
}

@Dao
interface ActiveTestSessionDao {
  @Query("SELECT * FROM active_test_sessions WHERE testId = :testId AND userId = :userId LIMIT 1")
  suspend fun getActiveSession(testId: String, userId: Long): ActiveTestSessionEntity?

  @Query("SELECT * FROM active_test_sessions WHERE userId = :userId ORDER BY lastSavedTimestamp DESC LIMIT 1")
  suspend fun getLatestActiveSession(userId: Long): ActiveTestSessionEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveActiveSession(session: ActiveTestSessionEntity)

  @Query("DELETE FROM active_test_sessions WHERE testId = :testId AND userId = :userId")
  suspend fun deleteActiveSession(testId: String, userId: Long)
}

@Dao
interface WrongAnswerDao {
  @Query("SELECT * FROM wrong_answers WHERE userId = :userId AND isResolved = 0 ORDER BY recordedAt DESC")
  fun getUnresolvedWrongAnswers(userId: Long): Flow<List<WrongAnswerEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertWrongAnswer(wrongAnswer: WrongAnswerEntity)

  @Query("UPDATE wrong_answers SET isResolved = 1 WHERE id = :id")
  suspend fun markResolved(id: String)

  @Query("DELETE FROM wrong_answers WHERE id = :id")
  suspend fun deleteWrongAnswer(id: String)
}

@Dao
interface StudyMaterialDao {
  @Query("SELECT * FROM study_materials ORDER BY id DESC")
  fun getAllMaterials(): Flow<List<StudyMaterialEntity>>

  @Query("SELECT * FROM study_materials WHERE category = :category ORDER BY id DESC")
  fun getMaterialsByCategory(category: String): Flow<List<StudyMaterialEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMaterial(material: StudyMaterialEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMaterials(materials: List<StudyMaterialEntity>)
}

@Dao
interface SubscriptionOrderDao {
  @Query("SELECT * FROM subscription_orders WHERE userId = :userId ORDER BY createdAt DESC")
  fun getOrdersForUser(userId: Long): Flow<List<SubscriptionOrderEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrder(order: SubscriptionOrderEntity)

  @Query("UPDATE subscription_orders SET status = :status WHERE orderId = :orderId")
  suspend fun updateOrderStatus(orderId: String, status: String)
}

@Dao
interface BookmarkDao {
  @Query("SELECT * FROM bookmarks WHERE userId = :userId ORDER BY savedAt DESC")
  fun getBookmarksForUser(userId: Long): Flow<List<BookmarkEntity>>

  @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE questionId = :questionId AND userId = :userId)")
  suspend fun isBookmarked(questionId: String, userId: Long): Boolean

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBookmark(bookmark: BookmarkEntity)

  @Query("DELETE FROM bookmarks WHERE questionId = :questionId AND userId = :userId")
  suspend fun deleteBookmark(questionId: String, userId: Long)
}
