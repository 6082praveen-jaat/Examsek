package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.ActiveTestSessionEntity
import com.example.data.local.entity.BookmarkEntity
import com.example.data.local.entity.QuestionEntity
import com.example.data.local.entity.SubscriptionOrderEntity
import com.example.data.local.entity.TestAttemptEntity
import com.example.data.local.entity.TestEntity
import com.example.data.local.entity.UserEntity
import com.example.data.repository.ExamSeekRepository
import com.example.domain.model.AppLanguage
import com.example.domain.model.ExamCategory
import com.example.domain.model.StudyMaterialItem
import com.example.domain.model.SubscriptionPlan
import com.example.domain.model.SubscriptionTier
import com.example.domain.model.TestItem
import com.example.domain.model.TestQuestion
import com.example.domain.model.TestType
import com.example.domain.model.WrongAnswerItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

  val repository = ExamSeekRepository(application)
  val formulaRepository = com.example.data.formula.FormulaRepository(application)
  val liveCurrentAffairsService = com.example.data.currentaffairs.LiveCurrentAffairsService()
  val liveCurrentAffairsState: StateFlow<com.example.domain.model.LiveCurrentAffairsState> = liveCurrentAffairsService.state

  val currentUser: StateFlow<UserEntity?> = repository.currentUser

  private val _searchQuery = MutableStateFlow("")
  val searchQuery = _searchQuery.asStateFlow()

  private val _selectedCategoryFilter = MutableStateFlow<ExamCategory?>(null)
  val selectedCategoryFilter = _selectedCategoryFilter.asStateFlow()

  private val _selectedTypeFilter = MutableStateFlow<TestType?>(null)
  val selectedTypeFilter = _selectedTypeFilter.asStateFlow()

  private val _selectedTierFilter = MutableStateFlow<SubscriptionTier?>(null)
  val selectedTierFilter = _selectedTierFilter.asStateFlow()

  private val _allTests = repository.getAllTests()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val filteredTests: StateFlow<List<TestItem>> = combine(
    _allTests,
    _searchQuery,
    _selectedCategoryFilter,
    _selectedTypeFilter
  ) { tests, query, category, testType ->
    tests.filter { test ->
      val matchesQuery = query.isBlank() ||
          test.title.contains(query, ignoreCase = true) ||
          test.subject.contains(query, ignoreCase = true) ||
          test.category.displayName.contains(query, ignoreCase = true)

      val matchesCategory = category == null || test.category == category
      val matchesType = testType == null || test.type == testType

      matchesQuery && matchesCategory && matchesType
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val attempts: StateFlow<List<TestAttemptEntity>> = repository.getAttemptsForCurrentUser()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val bookmarks: StateFlow<List<BookmarkEntity>> = repository.getBookmarksForCurrentUser()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allQuestions: StateFlow<List<TestQuestion>> = repository.getAllQuestions()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val wrongAnswers: StateFlow<List<WrongAnswerItem>> = repository.getWrongAnswersForCurrentUser()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val studyMaterials: StateFlow<List<StudyMaterialItem>> = repository.getStudyMaterials()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val subscriptionOrders: StateFlow<List<SubscriptionOrderEntity>> = repository.getSubscriptionOrders()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _activeSession = MutableStateFlow<ActiveTestSessionEntity?>(null)
  val activeSession: StateFlow<ActiveTestSessionEntity?> = _activeSession.asStateFlow()

  // AI Doubt State
  private val _aiDoubtResponse = MutableStateFlow<String?>(null)
  val aiDoubtResponse = _aiDoubtResponse.asStateFlow()

  private val _isAiSolving = MutableStateFlow(false)
  val isAiSolving = _isAiSolving.asStateFlow()

  private val _aiDoubtError = MutableStateFlow<String?>(null)
  val aiDoubtError = _aiDoubtError.asStateFlow()

  private val _selectedQuestionForAi = MutableStateFlow<TestQuestion?>(null)
  val selectedQuestionForAi = _selectedQuestionForAi.asStateFlow()

  fun setSelectedQuestionForAi(question: TestQuestion?) {
    _selectedQuestionForAi.value = question
  }

  init {
    checkForActiveSession()
    refreshLiveCurrentAffairs(force = false)
  }

  fun refreshLiveCurrentAffairs(force: Boolean = true) {
    viewModelScope.launch {
      liveCurrentAffairsService.fetchLiveFeeds(force = force)
    }
  }

  fun checkForActiveSession() {
    viewModelScope.launch {
      _activeSession.value = repository.getLatestActiveSession()
    }
  }

  fun dismissActiveSession(testId: String) {
    viewModelScope.launch {
      repository.clearActiveTestSession(testId)
      _activeSession.value = null
    }
  }

  // Auth Operations
  fun login(email: String, password: String, onResult: (Boolean, String?) -> Unit) {
    viewModelScope.launch {
      val res = repository.login(email, password)
      if (res.isSuccess) {
        checkForActiveSession()
        onResult(true, null)
      } else {
        onResult(false, res.exceptionOrNull()?.message ?: "Login failed")
      }
    }
  }

  fun register(
    name: String,
    email: String,
    password: String,
    targetExam: String,
    phone: String,
    onResult: (Boolean, String?) -> Unit
  ) {
    viewModelScope.launch {
      val res = repository.register(name, email, password, targetExam, phone)
      if (res.isSuccess) {
        onResult(true, null)
      } else {
        onResult(false, res.exceptionOrNull()?.message ?: "Registration failed")
      }
    }
  }

  fun logout() {
    repository.logout()
    _activeSession.value = null
  }

  fun updateTargetExamAndDate(targetExam: String, examDate: Long) {
    viewModelScope.launch {
      repository.updateTargetExamAndDate(targetExam, examDate)
    }
  }

  fun updateLanguage(language: String) {
    viewModelScope.launch {
      repository.updateLanguage(language)
    }
  }

  fun updateDailyGoal(goal: Int) {
    viewModelScope.launch {
      repository.updateDailyGoal(goal)
    }
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun selectCategoryFilter(category: ExamCategory?) {
    _selectedCategoryFilter.value = category
  }

  fun selectTypeFilter(type: TestType?) {
    _selectedTypeFilter.value = type
  }

  fun toggleBookmark(questionId: String) {
    viewModelScope.launch {
      repository.toggleBookmark(questionId)
    }
  }

  fun resolveWrongAnswer(id: String) {
    viewModelScope.launch {
      repository.resolveWrongAnswer(id)
    }
  }

  // AI Doubt Solver
  fun askAiDoubt(
    question: TestQuestion,
    userQuery: String,
    language: String = currentUser.value?.preferredLanguage ?: "ENGLISH"
  ) {
    viewModelScope.launch {
      _isAiSolving.value = true
      _aiDoubtResponse.value = null
      _aiDoubtError.value = null

      val (canUse, reason) = repository.canUseAiDoubt()
      if (!canUse) {
        _isAiSolving.value = false
        _aiDoubtError.value = reason
        return@launch
      }

      val result = repository.aiDoubtService.solveDoubt(
        questionStatement = question.questionText,
        options = question.options,
        correctAnswer = question.options.getOrElse(question.correctOptionIndex) { "Option A" },
        userQuery = userQuery.ifBlank { "Please explain step-by-step why the correct answer is right and how to solve this fast in exams." },
        preferredLanguage = language
      )

      _isAiSolving.value = false
      if (result.isSuccess) {
        _aiDoubtResponse.value = result.getOrNull()
        repository.recordAiDoubtUsed()
      } else {
        _aiDoubtError.value = result.exceptionOrNull()?.message ?: "Failed to generate solution"
      }
    }
  }

  fun clearAiDoubtState() {
    _aiDoubtResponse.value = null
    _aiDoubtError.value = null
    _isAiSolving.value = false
  }

  // Subscription Purchase
  fun subscribeToPlan(plan: SubscriptionPlan, onResult: (Boolean, String?) -> Unit) {
    viewModelScope.launch {
      val durationMonths = if (plan.id.contains("annual", ignoreCase = true)) 12 else 1
      val res = repository.purchaseSubscription(
        planId = plan.id,
        tier = plan.tier,
        amount = plan.priceInRupees,
        durationMonths = durationMonths
      )
      if (res.isSuccess) {
        onResult(true, "Successfully subscribed to ${plan.tier.displayName}!")
      } else {
        onResult(false, res.exceptionOrNull()?.message ?: "Purchase error")
      }
    }
  }

  // Admin Actions
  fun addCustomTest(
    title: String,
    category: ExamCategory,
    type: TestType,
    durationMinutes: Int,
    totalMarks: Float,
    negativeRate: Float,
    isVerified: Boolean,
    subject: String,
    description: String,
    tier: SubscriptionTier = SubscriptionTier.FREE,
    onSuccess: () -> Unit
  ) {
    viewModelScope.launch {
      val newId = "custom_test_${System.currentTimeMillis()}"
      val testEntity = TestEntity(
        id = newId,
        title = title,
        category = category.id,
        type = type.name,
        durationMinutes = durationMinutes,
        totalMarks = totalMarks,
        marksPerQuestion = 2.0f,
        negativeMarkingRate = negativeRate,
        isVerified = isVerified,
        subject = subject,
        description = description,
        tier = tier.name,
        attemptsCount = 0
      )
      repository.createCustomTest(testEntity)
      onSuccess()
    }
  }

  fun addCustomQuestion(
    testId: String,
    subject: String,
    topic: String,
    questionText: String,
    hindiQuestionText: String,
    optA: String,
    optB: String,
    optC: String,
    optD: String,
    correctIndex: Int,
    explanation: String,
    hindiExplanation: String,
    source: String,
    year: String,
    isVerified: Boolean,
    onSuccess: () -> Unit
  ) {
    viewModelScope.launch {
      val question = QuestionEntity(
        id = "custom_q_${System.currentTimeMillis()}",
        testId = testId,
        subject = subject,
        topic = topic,
        questionText = questionText,
        hindiQuestionText = hindiQuestionText,
        optionA = optA,
        optionB = optB,
        optionC = optC,
        optionD = optD,
        correctOptionIndex = correctIndex,
        explanation = explanation,
        hindiExplanation = hindiExplanation,
        difficulty = "MEDIUM",
        source = source,
        year = year,
        isVerified = isVerified
      )
      repository.createCustomQuestion(question)
      onSuccess()
    }
  }

  fun toggleTestVerification(testId: String) {
    viewModelScope.launch {
      repository.toggleTestVerification(testId)
    }
  }

  // Question Bank & AI Generator State
  private val _selectedExamDetail = MutableStateFlow(com.example.domain.model.ExamRegistry.allExams.first())
  val selectedExamDetail = _selectedExamDetail.asStateFlow()

  private val _selectedStage = MutableStateFlow(_selectedExamDetail.value.stages.firstOrNull() ?: "Tier-1")
  val selectedStage = _selectedStage.asStateFlow()

  private val _selectedSubject = MutableStateFlow("All")
  val selectedSubject = _selectedSubject.asStateFlow()

  private val _selectedTopic = MutableStateFlow("All")
  val selectedTopic = _selectedTopic.asStateFlow()

  private val _selectedDifficulty = MutableStateFlow("MEDIUM")
  val selectedDifficulty = _selectedDifficulty.asStateFlow()

  private val _selectedLanguage = MutableStateFlow("ENGLISH")
  val selectedLanguage = _selectedLanguage.asStateFlow()

  private val _isGenerating = MutableStateFlow(false)
  val isGenerating = _isGenerating.asStateFlow()

  private val _generationMessage = MutableStateFlow<String?>(null)
  val generationMessage = _generationMessage.asStateFlow()

  private val _generationError = MutableStateFlow<String?>(null)
  val generationError = _generationError.asStateFlow()

  private val _dailyGenerationCount = MutableStateFlow(0)
  val dailyGenerationCount = _dailyGenerationCount.asStateFlow()

  val maxDailyGenerations: Int
    get() = when (currentUser.value?.subscriptionTier) {
      "PRO" -> 100 // batches
      "PLUS" -> 30
      else -> 10 // Free users: 10 batches/day
    }

  private val _examBankQuestions = MutableStateFlow<List<TestQuestion>>(emptyList())
  val examBankQuestions = _examBankQuestions.asStateFlow()

  private val _pendingReviewQuestions = MutableStateFlow<List<TestQuestion>>(emptyList())
  val pendingReviewQuestions = _pendingReviewQuestions.asStateFlow()

  fun selectExam(examDetail: com.example.domain.model.ExamDetail) {
    _selectedExamDetail.value = examDetail
    _selectedStage.value = examDetail.stages.firstOrNull() ?: "Tier-1"
    _selectedSubject.value = "All"
    _selectedTopic.value = "All"
    refreshBankQuestions()
  }

  fun setStage(stage: String) {
    _selectedStage.value = stage
  }

  fun setSubject(subject: String) {
    _selectedSubject.value = subject
    _selectedTopic.value = "All"
    refreshBankQuestions()
  }

  fun setTopic(topic: String) {
    _selectedTopic.value = topic
    refreshBankQuestions()
  }

  fun setDifficulty(difficulty: String) {
    _selectedDifficulty.value = difficulty
  }

  fun setLanguage(language: String) {
    _selectedLanguage.value = language
  }

  fun refreshBankQuestions() {
    viewModelScope.launch {
      repository.getQuestionsForExam(
        examName = _selectedExamDetail.value.name,
        subject = _selectedSubject.value,
        topic = _selectedTopic.value
      ).collect { list ->
        _examBankQuestions.value = list
      }
    }
  }

  fun loadPendingReviewQuestions() {
    viewModelScope.launch {
      repository.getPendingReviewQuestions().collect { list ->
        _pendingReviewQuestions.value = list
      }
    }
  }

  fun generateQuestions(batchSize: Int = 10, onComplete: ((Boolean) -> Unit)? = null) {
    if (_isGenerating.value) return

    if (_dailyGenerationCount.value >= maxDailyGenerations) {
      _generationError.value = "Daily batch limit reached (${maxDailyGenerations} batches). Upgrade to Plus/Pro or wait until tomorrow."
      onComplete?.invoke(false)
      return
    }

    _isGenerating.value = true
    _generationError.value = null
    _generationMessage.value = "Connecting to Exam Question Engine for ${_selectedExamDetail.value.name}..."

    viewModelScope.launch {
      val targetSubject = if (_selectedSubject.value == "All") {
        _selectedExamDetail.value.subjects.firstOrNull() ?: "General Awareness"
      } else {
        _selectedSubject.value
      }

      val targetTopic = if (_selectedTopic.value == "All") {
        _selectedExamDetail.value.topicsBySubject[targetSubject]?.firstOrNull() ?: "General"
      } else {
        _selectedTopic.value
      }

      val result = repository.generateAndSaveQuestionBatch(
        examDetail = _selectedExamDetail.value,
        stage = _selectedStage.value,
        subject = targetSubject,
        topic = targetTopic,
        difficulty = _selectedDifficulty.value,
        language = _selectedLanguage.value,
        batchSize = batchSize
      )

      _isGenerating.value = false

      when (result) {
        is com.example.data.ai.GenerationResult.Success -> {
          _dailyGenerationCount.value += 1
          _generationMessage.value = "Added ${result.questions.size} questions on '$targetTopic' via ${result.sourceUsed}! (${result.duplicatesSkipped} duplicates skipped)"
          refreshBankQuestions()
          onComplete?.invoke(true)
        }
        is com.example.data.ai.GenerationResult.Error -> {
          _generationError.value = result.message
          onComplete?.invoke(false)
        }
      }
    }
  }

  fun approveQuestion(questionId: String) {
    viewModelScope.launch {
      repository.updateQuestionReviewStatus(questionId, true, "OFFICIAL_VERIFIED_PYQ")
      loadPendingReviewQuestions()
      refreshBankQuestions()
    }
  }

  fun rejectOrDeleteQuestion(questionId: String) {
    viewModelScope.launch {
      repository.deleteQuestion(questionId)
      loadPendingReviewQuestions()
      refreshBankQuestions()
    }
  }

  fun createMockFromCurrentSelection(
    questionCount: Int = 10,
    durationMinutes: Int = 15,
    onReady: (TestItem, List<TestQuestion>) -> Unit
  ) {
    viewModelScope.launch {
      val (testItem, questions) = repository.createDynamicMockTest(
        examDetail = _selectedExamDetail.value,
        stage = _selectedStage.value,
        subject = _selectedSubject.value,
        topic = _selectedTopic.value,
        questionCount = questionCount,
        durationMinutes = durationMinutes
      )
      onReady(testItem, questions)
    }
  }
}
