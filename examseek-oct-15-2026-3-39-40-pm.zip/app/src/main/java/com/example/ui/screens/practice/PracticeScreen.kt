package com.example.ui.screens.practice

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.TestQuestion
import com.example.ui.components.VerifiedBadge
import com.example.ui.viewmodel.MainViewModel

@Composable
fun PracticeScreen(
  viewModel: MainViewModel,
  onNavigateToExamGenerator: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val allQuestions by viewModel.allQuestions.collectAsState()
  val bookmarkedList by viewModel.bookmarks.collectAsState()

  val subjects = listOf("All", "Quantitative Aptitude", "Logical Reasoning", "General Awareness", "English Language", "General Science")
  var selectedSubject by remember { mutableStateOf("All") }

  // Store user practice selections for immediate feedback in practice mode
  val practiceAnswers = remember { mutableStateMapOf<String, Int>() }

  val filteredQuestions = if (selectedSubject == "All") {
    allQuestions
  } else {
    allQuestions.filter { it.subject.contains(selectedSubject, ignoreCase = true) }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("practice_screen")
  ) {
    // Header
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(MaterialTheme.colorScheme.surface)
        .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Psychology,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Practice Drills",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
          )
        }

        androidx.compose.material3.OutlinedButton(
          onClick = onNavigateToExamGenerator,
          modifier = Modifier.testTag("practice_generate_more_btn")
        ) {
          Icon(imageVector = Icons.Default.Lightbulb, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Generate More", fontSize = 12.sp)
        }
      }

      Text(
        text = "Solve questions with instant answer reveal and in-depth explanations",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Subject Filter Chips
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        subjects.forEach { subj ->
          FilterChip(
            selected = selectedSubject == subj,
            onClick = { selectedSubject = subj },
            label = { Text(subj, fontSize = 12.sp) }
          )
        }
      }
    }

    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      itemsIndexed(filteredQuestions, key = { _, item -> item.id }) { index, question ->
        val chosenOpt = practiceAnswers[question.id]
        val isBookmarked = bookmarkedList.any { it.questionId == question.id }

        PracticeQuestionCard(
          questionNumber = index + 1,
          question = question,
          selectedOption = chosenOpt,
          isBookmarked = isBookmarked,
          onSelectOption = { optIdx ->
            practiceAnswers[question.id] = optIdx
          },
          onToggleBookmark = { viewModel.toggleBookmark(question.id) }
        )
      }

      item {
        Spacer(modifier = Modifier.height(70.dp))
      }
    }
  }
}

@Composable
private fun PracticeQuestionCard(
  questionNumber: Int,
  question: TestQuestion,
  selectedOption: Int?,
  isBookmarked: Boolean,
  onSelectOption: (Int) -> Unit,
  onToggleBookmark: () -> Unit
) {
  val hasAnswered = selectedOption != null
  val isCorrect = selectedOption == question.correctOptionIndex

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("practice_q_${question.id}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "Q$questionNumber",
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            fontSize = 14.sp
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = question.subject,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          com.example.ui.components.SourceLabelBadge(sourceLabel = question.sourceLabel)
          Spacer(modifier = Modifier.width(4.dp))
          VerifiedBadge(isVerified = question.isVerified)
          IconButton(onClick = onToggleBookmark) {
            Icon(
              imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
              contentDescription = "Bookmark",
              tint = if (isBookmarked) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = question.questionText,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.Medium,
        lineHeight = 22.sp
      )

      Spacer(modifier = Modifier.height(12.dp))

      val labels = listOf("A", "B", "C", "D")
      question.options.forEachIndexed { optIndex, optionText ->
        val isChosen = selectedOption == optIndex
        val isTheCorrectOne = optIndex == question.correctOptionIndex

        val (optBg, optBorder, optTextColor) = when {
          hasAnswered && isTheCorrectOne -> Triple(Color(0xFFDCFCE7), Color(0xFF22C55E), Color(0xFF15803D))
          hasAnswered && isChosen && !isCorrect -> Triple(Color(0xFFFEE2E2), Color(0xFFEF4444), Color(0xFFB91C1C))
          isChosen -> Triple(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimaryContainer)
          else -> Triple(MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), MaterialTheme.colorScheme.onSurface)
        }

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(optBg)
            .border(1.dp, optBorder, RoundedCornerShape(8.dp))
            .clickable { onSelectOption(optIndex) }
            .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "${labels[optIndex]}.",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              color = optTextColor
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = optionText,
              style = MaterialTheme.typography.bodySmall,
              color = optTextColor,
              modifier = Modifier.weight(1f)
            )

            if (hasAnswered && isTheCorrectOne) {
              Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF15803D), modifier = Modifier.size(16.dp))
            } else if (hasAnswered && isChosen && !isCorrect) {
              Icon(imageVector = Icons.Default.Close, contentDescription = null, tint = Color(0xFFB91C1C), modifier = Modifier.size(16.dp))
            }
          }
        }
      }

      // Instant Solution Reveal Box
      AnimatedVisibility(visible = hasAnswered) {
        Column(modifier = Modifier.padding(top = 12.dp)) {
          Card(
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = if (isCorrect) Color(0xFFF0FDF4) else Color(0xFFFFFBEB))
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.Lightbulb,
                  contentDescription = null,
                  tint = if (isCorrect) Color(0xFF16A34A) else Color(0xFFD97706),
                  modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isCorrect) "Excellent! Correct Answer" else "Incorrect - Correct is Option ${labels[question.correctOptionIndex]}",
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  color = if (isCorrect) Color(0xFF15803D) else Color(0xFFB45309)
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = question.explanation,
                style = MaterialTheme.typography.bodySmall,
                fontSize = 12.sp,
                color = Color(0xFF1E293B),
                lineHeight = 18.sp
              )
            }
          }
        }
      }
    }
  }
}
