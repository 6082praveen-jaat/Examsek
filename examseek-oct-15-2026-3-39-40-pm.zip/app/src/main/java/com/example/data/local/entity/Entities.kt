package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val email: String,
  val password: String,
  val phone: String = "",
  val targetExam: String = "SSC CGL",
  val role: String = "STUDENT", // "STUDENT" or "ADMIN"
  val subscriptionTier: String = "FREE", // "FREE", "PLUS", "PRO"
  val subscriptionExpiry: Long = 0L,
  val targetExamDate: Long = System.currentTimeMillis() + (75L * 24 * 60 * 60 * 1000),
  val preferredLanguage: String = "ENGLISH", // "ENGLISH" or "HINDI"
  val aiDoubtsUsedToday: Int = 0,
  val lastAiDoubtDate: String = "",
  val dailyGoalQuestions: Int = 20,
  val streakDays: Int = 5,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tests")
data class TestEntity(
  @PrimaryKey val id: String,
  val title: String,
  val category: String, // ExamCategory name
  val type: String, // TestType name
  val durationMinutes: Int,
  val totalMarks: Float,
  val marksPerQuestion: Float = 2.0f,
  val negativeMarkingRate: Float = 0.5f,
  val isVerified: Boolean = true,
  val subject: String = "All Subjects",
  val description: String = "",
  val tier: String = "FREE", // "FREE", "PLUS", "PRO"
  val attemptsCount: Int = 1000
)

@Entity(
  tableName = "questions",
  indices = [
    androidx.room.Index(value = ["testId"]),
    androidx.room.Index(value = ["subject"]),
    androidx.room.Index(value = ["topic"]),
    androidx.room.Index(value = ["targetExam"]),
    androidx.room.Index(value = ["contentHash"])
  ]
)
data class QuestionEntity(
  @PrimaryKey val id: String,
  val testId: String,
  val subject: String,
  val topic: String = "General",
  val questionText: String,
  val optionA: String,
  val optionB: String,
  val optionC: String,
  val optionD: String,
  val correctOptionIndex: Int, // 0..3
  val explanation: String,
  val hindiQuestionText: String = "",
  val hindiOptionA: String = "",
  val hindiOptionB: String = "",
  val hindiOptionC: String = "",
  val hindiOptionD: String = "",
  val hindiExplanation: String = "",
  val difficulty: String = "MEDIUM",
  val source: String = "ExamSeek Academic Team",
  val year: String = "2024",
  val isVerified: Boolean = true,
  val targetExam: String = "SSC CGL",
  val stage: String = "Tier-1",
  val language: String = "ENGLISH",
  val sourceLabel: String = "OFFICIAL_VERIFIED_PYQ", // "OFFICIAL_VERIFIED_PYQ", "AI_GENERATED_PRACTICE", "NEEDS_REVIEW"
  val contentHash: String = "",
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "test_attempts")
data class TestAttemptEntity(
  @PrimaryKey val attemptId: String,
  val userId: Long,
  val testId: String,
  val testTitle: String,
  val category: String,
  val score: Float,
  val totalMarks: Float,
  val accuracy: Float,
  val totalQuestions: Int,
  val correctCount: Int,
  val incorrectCount: Int,
  val unattemptedCount: Int,
  val timeSpentSeconds: Int,
  val totalTimeSeconds: Int,
  val negativeMarkingApplied: Boolean,
  val negativeMarksDeducted: Float,
  val attemptedAt: Long = System.currentTimeMillis(),
  val answersSummary: String // e.g. "q1:0,q2:1,q3:-1"
)

@Entity(tableName = "active_test_sessions")
data class ActiveTestSessionEntity(
  @PrimaryKey val testId: String,
  val userId: Long,
  val timeRemainingSeconds: Int,
  val currentIndex: Int,
  val answersSummary: String, // "q1:0,q2:2"
  val markedReviewSummary: String, // "q1,q3"
  val applyNegativeMarking: Boolean,
  val lastSavedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "wrong_answers")
data class WrongAnswerEntity(
  @PrimaryKey val id: String,
  val userId: Long,
  val questionId: String,
  val testId: String,
  val userWrongOption: Int,
  val correctOption: Int,
  val recordedAt: Long = System.currentTimeMillis(),
  val isResolved: Boolean = false
)

@Entity(tableName = "study_materials")
data class StudyMaterialEntity(
  @PrimaryKey val id: String,
  val title: String,
  val category: String, // "CURRENT_AFFAIRS", "FORMULA_SHEET", "REVISION_NOTE", "FLASHCARD"
  val subject: String,
  val dateLabel: String,
  val content: String,
  val source: String,
  val tier: String = "FREE" // "FREE", "PLUS", "PRO"
)

@Entity(tableName = "subscription_orders")
data class SubscriptionOrderEntity(
  @PrimaryKey val orderId: String,
  val userId: Long,
  val plan: String,
  val amount: Int,
  val status: String, // "PENDING", "ACTIVE", "EXPIRED", "CANCELLED"
  val gateway: String = "SIMULATED_GATEWAY",
  val transactionRef: String = "",
  val createdAt: Long = System.currentTimeMillis(),
  val expiresAt: Long = 0L
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
  @PrimaryKey val questionId: String,
  val userId: Long = 1,
  val savedAt: Long = System.currentTimeMillis()
)
