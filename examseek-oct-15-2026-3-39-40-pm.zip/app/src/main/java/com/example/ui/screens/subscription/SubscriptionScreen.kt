package com.example.ui.screens.subscription

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.SampleExamData
import com.example.domain.model.SubscriptionPlan
import com.example.domain.model.SubscriptionTier
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionScreen(
  viewModel: MainViewModel,
  onNavigateToTrustLegal: () -> Unit,
  onBack: () -> Unit
) {
  val context = LocalContext.current
  val currentUser by viewModel.currentUser.collectAsState()
  val plans = SampleExamData.subscriptionPlans

  var selectedPlan by remember { mutableStateOf(plans.first()) }
  var showPaymentSimulatorDialog by remember { mutableStateOf(false) }

  val currentTier = try { SubscriptionTier.valueOf(currentUser?.subscriptionTier ?: "FREE") } catch (e: Exception) { SubscriptionTier.FREE }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("ExamSeek Premium Passes", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        }
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
        .padding(horizontal = 16.dp)
        .verticalScroll(rememberScrollState())
        .testTag("subscription_screen")
    ) {
      Spacer(modifier = Modifier.height(10.dp))

      // Current Tier Badge Banner
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "Your Current Plan",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              text = currentTier.displayName,
              fontWeight = FontWeight.ExtraBold,
              fontSize = 16.sp,
              color = Color(currentTier.badgeColor)
            )
          }

          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(Color(currentTier.badgeColor).copy(alpha = 0.15f))
              .padding(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Text(
              text = if (currentTier == SubscriptionTier.FREE) "Free Access" else "Active Pass",
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              color = Color(currentTier.badgeColor)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "Select a Preparation Pass",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = "Unlock all mock test series, official PYQs, and AI doubt-solving",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Plans List
      plans.forEach { plan ->
        val isSelected = selectedPlan.id == plan.id
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface
          ),
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .border(
              width = if (isSelected) 2.dp else 1.dp,
              color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
              shape = RoundedCornerShape(14.dp)
            )
            .clip(RoundedCornerShape(14.dp))
            .clickable { selectedPlan = plan }
            .testTag("plan_card_${plan.id}")
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = if (plan.tier == SubscriptionTier.PRO) Icons.Default.WorkspacePremium else Icons.Default.Star,
                  contentDescription = null,
                  tint = Color(plan.tier.badgeColor),
                  modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = plan.tier.displayName,
                  fontWeight = FontWeight.Bold,
                  fontSize = 15.sp,
                  color = Color(plan.tier.badgeColor)
                )
              }

              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(Color(0xFFDCFCE7))
                  .padding(horizontal = 8.dp, vertical = 3.dp)
              ) {
                Text(
                  text = plan.discountLabel,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = Color(0xFF15803D)
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = plan.durationTitle,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.Bottom) {
              Text(
                text = "₹${plan.priceInRupees}",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 24.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "₹${plan.originalPriceInRupees}",
                fontSize = 13.sp,
                textDecoration = TextDecoration.LineThrough,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = plan.billingPeriod,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Spacer(modifier = Modifier.height(10.dp))

            plan.features.forEach { feat ->
              Row(
                modifier = Modifier.padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = Icons.Default.CheckCircle,
                  contentDescription = null,
                  tint = Color(0xFF10B981),
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = feat,
                  style = MaterialTheme.typography.bodySmall,
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Subscription Security Notice
      Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Secure Payments Architecture: 256-bit encryption. Payment credentials are never stored on device. Subscriptions are verifiable via server webhook.",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 15.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Button(
        onClick = { showPaymentSimulatorDialog = true },
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("proceed_to_payment_btn"),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(imageVector = Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text("Get ${selectedPlan.tier.displayName} (₹${selectedPlan.priceInRupees})", fontWeight = FontWeight.Bold)
      }

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center
      ) {
        TextButton(onClick = onNavigateToTrustLegal) {
          Text("Subscription Terms, Refund Policy & Privacy", fontSize = 11.sp)
        }
      }

      Spacer(modifier = Modifier.height(40.dp))
    }
  }

  // Payment Verification Simulator Dialog
  if (showPaymentSimulatorDialog) {
    AlertDialog(
      onDismissRequest = { showPaymentSimulatorDialog = false },
      title = {
        Text("Payment Gateway Simulation", fontWeight = FontWeight.Bold)
      },
      text = {
        Column {
          Text(
            text = "Order Details:",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
          )
          Text("• Plan: ${selectedPlan.tier.displayName} (${selectedPlan.durationTitle})", fontSize = 12.sp)
          Text("• Total Amount: ₹${selectedPlan.priceInRupees}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          Text("• Mode: Sandbox Verification (Pre-Production Architecture)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = "In production, this initiates a server-side order with Razorpay/Stripe and updates entitlements only after cryptographic HMAC signature validation.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            showPaymentSimulatorDialog = false
            viewModel.subscribeToPlan(selectedPlan) { success, msg ->
              Toast.makeText(context, msg ?: "Plan Activated!", Toast.LENGTH_SHORT).show()
            }
          }
        ) {
          Text("Simulate Successful Payment")
        }
      },
      dismissButton = {
        TextButton(onClick = { showPaymentSimulatorDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }
}
