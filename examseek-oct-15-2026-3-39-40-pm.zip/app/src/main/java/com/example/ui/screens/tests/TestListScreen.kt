package com.example.ui.screens.tests

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ExamCategory
import com.example.domain.model.TestItem
import com.example.domain.model.TestType
import com.example.ui.components.TestCard
import com.example.ui.screens.home.CategoryPill
import com.example.ui.viewmodel.MainViewModel

@Composable
fun TestListScreen(
  viewModel: MainViewModel,
  onStartTest: (TestItem) -> Unit,
  modifier: Modifier = Modifier
) {
  val filteredTests by viewModel.filteredTests.collectAsState()
  val searchQuery by viewModel.searchQuery.collectAsState()
  val selectedCategory by viewModel.selectedCategoryFilter.collectAsState()
  val selectedType by viewModel.selectedTypeFilter.collectAsState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("test_list_screen")
  ) {
    // Top Bar
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(MaterialTheme.colorScheme.surface)
        .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      Text(
        text = "Test Series & Mock Tests",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = "Standard pattern CBT mocks with negative marking & all-India rankings",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Search Bar
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { viewModel.setSearchQuery(it) },
        placeholder = { Text("Search by exam or topic...", fontSize = 13.sp) },
        leadingIcon = {
          Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.onSurfaceVariant)
        },
        trailingIcon = {
          if (searchQuery.isNotBlank()) {
            IconButton(onClick = { viewModel.setSearchQuery("") }) {
              Icon(imageVector = Icons.Default.Close, contentDescription = "Clear")
            }
          }
        },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("tests_search_field"),
        shape = RoundedCornerShape(10.dp),
        singleLine = true
      )

      Spacer(modifier = Modifier.height(8.dp))

      // Category Horizontal Row
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(vertical = 4.dp)
      ) {
        items(ExamCategory.entries) { cat ->
          val isSelected = selectedCategory == cat
          CategoryPill(
            category = cat,
            isSelected = isSelected,
            onClick = {
              if (isSelected) viewModel.selectCategoryFilter(null)
              else viewModel.selectCategoryFilter(cat)
            }
          )
        }
      }

      // Type Filter Chips
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState())
          .padding(top = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        FilterChip(
          selected = selectedType == null,
          onClick = { viewModel.selectTypeFilter(null) },
          label = { Text("All") }
        )
        FilterChip(
          selected = selectedType == TestType.FULL_MOCK,
          onClick = { viewModel.selectTypeFilter(TestType.FULL_MOCK) },
          label = { Text("Full Mocks") }
        )
        FilterChip(
          selected = selectedType == TestType.DAILY_QUIZ,
          onClick = { viewModel.selectTypeFilter(TestType.DAILY_QUIZ) },
          label = { Text("Daily Quizzes") }
        )
        FilterChip(
          selected = selectedType == TestType.PRACTICE_SET,
          onClick = { viewModel.selectTypeFilter(TestType.PRACTICE_SET) },
          label = { Text("Practice Sets") }
        )
      }
    }

    // List of Tests
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      items(filteredTests, key = { it.id }) { test ->
        TestCard(
          test = test,
          onStartClick = { onStartTest(test) }
        )
      }

      item {
        Spacer(modifier = Modifier.height(70.dp))
      }
    }
  }
}
