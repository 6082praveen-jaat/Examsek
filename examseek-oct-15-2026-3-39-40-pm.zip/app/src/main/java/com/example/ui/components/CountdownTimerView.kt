package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun CountdownTimerView(
  timeRemainingSeconds: Int,
  modifier: Modifier = Modifier
) {
  val minutes = timeRemainingSeconds / 60
  val seconds = timeRemainingSeconds % 60
  val isLowTime = timeRemainingSeconds < 120 // less than 2 minutes

  val backgroundColor by animateColorAsState(
    targetValue = if (isLowTime) Color(0xFFFEE2E2) else MaterialTheme.colorScheme.primaryContainer,
    label = "timerBg"
  )
  val textColor by animateColorAsState(
    targetValue = if (isLowTime) Color(0xFFDC2626) else MaterialTheme.colorScheme.onPrimaryContainer,
    label = "timerText"
  )

  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = modifier
      .testTag("countdown_timer_view")
      .clip(RoundedCornerShape(8.dp))
      .background(backgroundColor)
      .padding(horizontal = 10.dp, vertical = 6.dp)
  ) {
    Icon(
      imageVector = if (isLowTime) Icons.Default.HourglassBottom else Icons.Default.Timer,
      contentDescription = "Timer",
      tint = textColor,
      modifier = Modifier.size(16.dp)
    )
    Spacer(modifier = Modifier.width(6.dp))
    Text(
      text = String.format(Locale.US, "%02d:%02d", minutes, seconds),
      color = textColor,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Bold,
      fontSize = 14.sp
    )
  }
}
