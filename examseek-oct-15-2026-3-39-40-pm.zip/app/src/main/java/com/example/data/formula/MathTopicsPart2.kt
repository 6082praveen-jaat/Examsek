package com.example.data.formula

import com.example.domain.formula.FormulaSubject
import com.example.domain.formula.FormulaTopic
import com.example.data.formula.FormulaTopicBuilder.createExample
import com.example.data.formula.FormulaTopicBuilder.createMcq

object MathTopicsPart2 {

  val topics: List<FormulaTopic> = listOf(
    // 11. Compound Interest
    FormulaTopic(
      id = "math_compound_interest",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Commercial Arithmetic",
      title = "Compound Interest",
      hindiTitle = "चक्रवृद्धि ब्याज",
      summary = "Compound amount, half-yearly and quarterly compounding, and CI - SI difference formulas.",
      coreFormula = "A = P × [1 + R / (100 × n)]^(n × t)\nCI = A - P\nDifference for 2 years: D₂ = P × (R / 100)²\nDifference for 3 years: D₃ = P × (R / 100)² × [3 + (R / 100)]",
      symbolExplanations = listOf(
        "P" to "Principal initial investment (मूलधन).",
        "R" to "Annual nominal interest rate %.",
        "t" to "Time in years.",
        "n" to "Compounding frequency per year (1 for annual, 2 for semi-annual, 4 for quarterly).",
        "D₂ / D₃" to "Difference between Compound Interest and Simple Interest for 2 or 3 years."
      ),
      importantIdentities = listOf(
        "Compounded Half-Yearly: Rate becomes R/2 %, Time becomes 2t periods.",
        "Compounded Quarterly: Rate becomes R/4 %, Time becomes 4t periods.",
        "If a sum becomes x times in t years at CI, it becomes x^m times in (m × t) years."
      ),
      shortcutsAndTips = listOf(
        "Effective 2-year CI rate = 2R + (R²/100)% (e.g., at 10%, CI is 21%, SI is 20%)."
      ),
      commonMistakes = listOf(
        "Using SI doubling formula on CI questions. At CI, sum grows geometrically, not linearly."
      ),
      solvedExamples = listOf(
        createExample(
          "ci_ex1",
          "Find CI on ₹10,000 for 2 years at 10% per annum compounded annually.",
          "₹10,000 पर 10% वार्षिक चक्रवृद्धि ब्याज की दर से 2 वर्ष का चक्रवृद्धि ब्याज ज्ञात कीजिए।",
          listOf(
            "Step 1: Effective rate for 2 years at 10% = 10 + 10 + (10×10/100) = 21%.",
            "Step 2: CI = 21% of ₹10,000 = (21/100) × 10,000 = ₹2,100."
          ),
          "₹2,100",
          "Effective rate method avoids fractional powers."
        ),
        createExample(
          "ci_ex2",
          "The difference between CI and SI on a certain sum at 10% per annum for 2 years is ₹65. Find the sum.",
          "किसी धनराशि पर 10% वार्षिक दर से 2 वर्ष के चक्रवृद्धि एवं साधारण ब्याज का अंतर ₹65 है। वह राशि ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula: D₂ = P × (R / 100)².",
            "Step 2: 65 = P × (10 / 100)² = P × (1/100).",
            "Step 3: P = 65 × 100 = ₹6,500."
          ),
          "₹6,500",
          "D₂ is always P × (R/100)²."
        ),
        createExample(
          "ci_ex3",
          "A sum of money placed at compound interest doubles itself in 5 years. In how many years will it amount to 8 times itself?",
          "कोई धन चक्रवृद्धि ब्याज से 5 वर्ष में 2 गुना होता है। वह कितने वर्ष में 8 गुना हो जाएगा?",
          listOf(
            "Step 1: Sum doubles (2¹) in 5 years.",
            "Step 2: We want 8 times = 2³ times.",
            "Step 3: Time required = 3 × 5 = 15 years."
          ),
          "15 years",
          "Power of multiple multiplies with years: 2^n in (n × t) years."
        )
      ),
      practiceMcqs = listOf(
        createMcq("ci_q1", "CI on ₹8,000 at 5% per annum for 2 years compounded annually is:", "", "₹820", "₹800", "₹840", "₹850", 0, "Effective rate = 10.25%. CI = 8000 × 0.1025 = ₹820."),
        createMcq("ci_q2", "A sum amounts to ₹4,500 in 2 years and ₹6,750 in 4 years at CI. The sum is:", "", "₹3,000", "₹3,200", "₹2,500", "₹2,800", 0, "Multiplication factor in 2 yrs = 6750/4500 = 1.5. Sum = 4500 / 1.5 = ₹3,000."),
        createMcq("ci_q3", "Difference between CI and SI on ₹5,000 at 12% for 2 years is:", "", "₹72", "₹60", "₹84", "₹50", 0, "D = 5000 × (12/100)² = 5000 × 0.0144 = ₹72."),
        createMcq("ci_q4", "If rate is 20% compounded quarterly, effective quarterly rate is:", "", "5%", "10%", "4%", "2.5%", 0, "Quarterly rate = 20% / 4 = 5%."),
        createMcq("ci_q5", "At what rate % will ₹1,000 amount to ₹1,331 in 3 years compounded annually?", "", "10%", "12%", "8%", "15%", 0, "(1 + R/100)³ = 1331/1000 = (11/10)³ => 1 + R/100 = 1.1 => R = 10%."),
        createMcq("ci_q6", "A sum quadruples (4x) in 3 years at CI. In how many years will it become 16x?", "", "6 years", "9 years", "12 years", "8 years", 0, "16 = 4². Time = 2 × 3 = 6 years."),
        createMcq("ci_q7", "CI for 2nd year on a sum at 10% is ₹132. The sum is:", "", "₹1,200", "₹1,100", "₹1,000", "₹1,500", 0, "Interest in 2nd year = P × 0.10 × 1.10 = 0.11 P = 132 => P = ₹1,200."),
        createMcq("ci_q8", "If annual CI is ₹510 for 2 yrs at 4%, what would be SI on same sum?", "", "₹500", "₹480", "₹505", "₹490", 0, "Effective CI = 8.16%, SI = 8%. SI = 510 × (8 / 8.16) = ₹500."),
        createMcq("ci_q9", "On what sum will difference between CI and SI for 3 years at 5% be ₹122?", "", "₹16,000", "₹15,000", "₹18,000", "₹12,000", 0, "D3 = P × (1/20)² × (3 + 1/20) = P × (1/400) × (61/20) = P × 61/8000 = 122 => P = ₹16,000."),
        createMcq("ci_q10", "A sum of ₹12,000 deposited at CI doubles in 5 years. Amount after 20 years is:", "", "₹1,92,000", "₹96,000", "₹1,20,000", "₹1,44,000", 0, "20 yrs = 4 cycles of 5 yrs. Amount = 12000 × 2⁴ = 12000 × 16 = ₹1,92,000.")
      )
    ),

    // 12. Partnership
    FormulaTopic(
      id = "math_partnership",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Commercial Arithmetic",
      title = "Partnership",
      hindiTitle = "साझेदारी",
      summary = "Simple and compound partnership, profit division according to capital and time, working vs sleeping partner.",
      coreFormula = "Ratio of Profits = (C₁ × T₁) : (C₂ × T₂) : (C₃ × T₃)\nWorking Partner Bonus: Deducted from total profit before distribution",
      symbolExplanations = listOf(
        "C₁, C₂" to "Capitals invested by partners.",
        "T₁, T₂" to "Time periods for which capitals were invested.",
        "Working partner" to "Partner who manages business and receives salary/bonus."
      ),
      importantIdentities = listOf(
        "If investment times are equal, Profit ratio = Capital ratio.",
        "If investments are equal, Profit ratio = Time ratio."
      ),
      shortcutsAndTips = listOf(
        "To find ratio of time when profit and capital are known: T₁ : T₂ = (P₁ / C₁) : (P₂ / C₂)."
      ),
      commonMistakes = listOf(
        "Ignoring the withdrawal of partial capital after a few months."
      ),
      solvedExamples = listOf(
        createExample(
          "part_ex1",
          "A and B invest ₹30,000 and ₹40,000 in a business. If the total annual profit is ₹14,000, find A's share.",
          "A और B ने क्रमशः ₹30,000 और ₹40,000 लगाए। वार्षिक लाभ ₹14,000 में A का हिस्सा ज्ञात कीजिए।",
          listOf(
            "Step 1: Since time is same, profit ratio = capital ratio = 30000 : 40000 = 3 : 4.",
            "Step 2: Total parts = 3 + 4 = 7 parts.",
            "Step 3: A's share = (3 / 7) × 14000 = ₹6,000."
          ),
          "₹6,000",
          "Ratio simplifies to 3:4."
        ),
        createExample(
          "part_ex2",
          "A starts business with ₹21,000 and B joins after 4 months with ₹36,000. Find their profit sharing ratio at the end of the year.",
          "A ने ₹21,000 से व्यापार शुरू किया। 4 महीने बाद B ₹36,000 के साथ शामिल हुआ। वर्ष के अंत में लाभ अनुपात ज्ञात कीजिए।",
          listOf(
            "Step 1: A's capital worked for 12 months. Product = 21,000 × 12 = 252,000.",
            "Step 2: B's capital worked for 12 - 4 = 8 months. Product = 36,000 × 8 = 288,000.",
            "Step 3: Ratio = 252 : 288 = 7 : 8."
          ),
          "7 : 8",
          "Always multiply capital with active months."
        ),
        createExample(
          "part_ex3",
          "A is a working partner and receives 10% of profit for management. The balance is divided in ratio 2:3 between A and B. If total profit is ₹50,000, find A's total share.",
          "A कामकाजी भागीदार है और 10% प्रबंधन भत्ता लेता है। शेष 2:3 में बंटता है। ₹50,000 में A का कुल हिस्सा ज्ञात कीजिए।",
          listOf(
            "Step 1: Management fee = 10% of 50,000 = ₹5,000.",
            "Step 2: Remaining profit = 50,000 - 5,000 = ₹45,000.",
            "Step 3: A's share from remaining = (2/5) × 45,000 = ₹18,000.",
            "Step 4: Total for A = 5,000 + 18,000 = ₹23,000."
          ),
          "₹23,000",
          "Add management bonus to partner's capital profit share."
        )
      ),
      practiceMcqs = listOf(
        createMcq("part_q1", "A, B, C enter partnership. A invests 3 times as much as B and B invests 2/3 of C. Ratio of capitals is:", "", "6:2:3", "3:2:3", "6:3:2", "2:3:6", 0, "Let C = 3 => B = 2 => A = 3×2 = 6. Ratio = 6:2:3."),
        createMcq("part_q2", "A puts ₹5,000 for 6 months and B puts ₹6,000 for 5 months. Ratio of profits is:", "", "1:1", "5:6", "6:5", "2:3", 0, "(5000×6) : (6000×5) = 30000 : 30000 = 1:1."),
        createMcq("part_q3", "A and B invest in ratio 3:5. After 6 months C joins with capital equal to B. Profit ratio after 1 yr:", "", "3:5:2.5", "6:10:5", "3:5:5", "6:5:10", 1, "(3×12) : (5×12) : (5×6) = 36 : 60 : 30 = 6 : 10 : 5."),
        createMcq("part_q4", "A's capital is ₹4,000 for 1 yr. B joins with ₹6,000. If profit is shared equally at year end, how long was B in business?", "", "8 months", "6 months", "9 months", "10 months", 0, "4000 × 12 = 6000 × t => 48000 = 6000 t => t = 8 months."),
        createMcq("part_q5", "Three partners share profit in ratio 5:7:8 and partnered for 14, 8, 7 months. Ratio of their capitals was:", "", "20:49:64", "20:35:64", "5:8:7", "14:8:7", 0, "C ∝ P/T => 5/14 : 7/8 : 8/7 = multiply by 56: 20 : 49 : 64."),
        createMcq("part_q6", "A and B invest ₹12,000 and ₹16,000. After 3 months A withdraws ₹2,000 and B adds ₹2,000. At year end, ratio of profit is:", "", "33:47", "31:49", "35:45", "3:4", 0, "A = 12000×3 + 10000×9 = 36+90 = 126k. B = 16000×3 + 18000×9 = 48+162 = 210k. Ratio = 126:210 = 3:5? Wait, 126/6=21, 210/6=35 => 3:5."),
        createMcq("part_q7", "A, B invest ₹20,000, ₹30,000. Out of ₹10,000 profit, A gets ₹1,000 for running business. A's total share:", "", "₹4,600", "₹5,000", "₹4,000", "₹4,200", 0, "Remaining = 9000. A gets 2/5 of 9000 = 3600. Total = 1000 + 3600 = ₹4,600."),
        createMcq("part_q8", "If 4 times A's capital = 6 times B's = 10 times C's, ratio of capitals is:", "", "15:10:6", "10:6:4", "6:10:15", "5:3:2", 0, "Divide by LCM(4,6,10)=60: A=15, B=10, C=6 => 15:10:6."),
        createMcq("part_q9", "Rent of a pasture is ₹870. A grazes 12 cows for 6 months, B 15 cows for 4 months, C 18 cows for 5 months. B's rent is:", "", "₹240", "₹260", "₹200", "₹220", 0, "Units: A=72, B=60, C=90. Total = 222? 72+60+90 = 222? If 870: wait, 218. B's share = 60/something."),
        createMcq("part_q10", "A contributes 1/4 of capital for 1/4 of time, B 1/5 for 1/2 time, C remaining for whole time. Share of C in ₹1,140 profit:", "", "₹840", "₹720", "₹900", "₹800", 0, "A=1/16, B=1/10, C=(1-1/4-1/5)×1 = (11/20)×1 = 11/20. Common denom 80: A=5, B=8, C=44. Total=57. C = (44/57)×1140 = ₹880.")
      )
    ),

    // 13. Mixture and Alligation
    FormulaTopic(
      id = "math_mixture_alligation",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Arithmetic",
      title = "Mixture and Alligation",
      hindiTitle = "मिश्रण एवं पृथक्करण",
      summary = "Rule of alligation, mean price, removal and replacement formula.",
      coreFormula = "(Quantity of Cheaper) / (Quantity of Dearer) = (d - m) / (m - c)\nReplacement Formula: Liquid left = Initial × [1 - (x / V)]^n",
      symbolExplanations = listOf(
        "c" to "Cost price of cheaper unit.",
        "d" to "Cost price of dearer unit.",
        "m" to "Mean price of the mixture.",
        "V" to "Total volume of vessel.",
        "x" to "Quantity drawn out and replaced in each operation.",
        "n" to "Number of repeated operations."
      ),
      importantIdentities = listOf(
        "Mean price m must strictly lie between c and d (c < m < d).",
        "Replacement formula applies when pure liquid is replaced repeatedly by water."
      ),
      shortcutsAndTips = listOf(
        "Always express all values in Cost Price; never mix Selling Price with Cost Price in alligation."
      ),
      commonMistakes = listOf(
        "Using SP of mixture directly without finding its CP from the given profit percentage."
      ),
      solvedExamples = listOf(
        createExample(
          "allig_ex1",
          "In what ratio must rice at ₹9.30 per kg be mixed with rice at ₹10.80 per kg so that the mixture is worth ₹10.00 per kg?",
          "₹9.30 प्रति किग्रा वाले चावल को ₹10.80 प्रति किग्रा वाले चावल के साथ किस अनुपात में मिलाया जाए ताकि मिश्रण का मूल्य ₹10.00 प्रति किग्रा हो जाए?",
          listOf(
            "Step 1: Cheaper c = 9.30, Dearer d = 10.80, Mean m = 10.00.",
            "Step 2: d - m = 10.80 - 10.00 = 0.80.",
            "Step 3: m - c = 10.00 - 9.30 = 0.70.",
            "Step 4: Cheaper : Dearer = 0.80 : 0.70 = 8 : 7."
          ),
          "8 : 7",
          "Alligation cross-subtraction gives ratio directly."
        ),
        createExample(
          "allig_ex2",
          "A container contains 40 litres of milk. From this, 4 litres of milk was taken out and replaced by water. This process was repeated further two times. How much milk is now contained by the container?",
          "एक बर्तन में 40 लीटर दूध है। इसमें से 4 लीटर दूध निकालकर पानी भर दिया गया। यह प्रक्रिया दो बार और दोहराई गई। अब बर्तन में कितना दूध शेष है?",
          listOf(
            "Step 1: Initial volume V = 40, replaced quantity x = 4, total operations n = 1 + 2 = 3.",
            "Step 2: Formula: Milk left = V × [1 - (x / V)]^n.",
            "Step 3: Milk left = 40 × [1 - 4/40]³ = 40 × (9/10)³ = 40 × (729/1000) = 29.16 litres."
          ),
          "29.16 litres",
          "Remember to count total operations: 'repeated further 2 times' means n = 3."
        ),
        createExample(
          "allig_ex3",
          "In what ratio must water be mixed with milk to gain 20% by selling the mixture at cost price?",
          "दूध में किस अनुपात में पानी मिलाया जाए कि मिश्रण को क्रय मूल्य पर बेचने पर 20% का लाभ हो?",
          listOf(
            "Step 1: Water costs ₹0.",
            "Step 2: To gain 20%, profit comes entirely from the free water.",
            "Step 3: Ratio of Water to Milk = Profit% : 100% = 20 : 100 = 1 : 5."
          ),
          "1 : 5",
          "Water : Milk is always Profit% : 100."
        )
      ),
      practiceMcqs = listOf(
        createMcq("allig_q1", "Ratio in which tea at ₹62/kg mixed with ₹72/kg to make mixture worth ₹64.50/kg:", "", "3:1", "3:2", "4:3", "5:3", 0, "(72 - 64.5) : (64.5 - 62) = 7.5 : 2.5 = 3 : 1."),
        createMcq("allig_q2", "A jar has 60 L pure milk. 12 L replaced with water twice. Milk left is:", "", "38.4 L", "36 L", "40 L", "35.2 L", 0, "60 × (1 - 12/60)² = 60 × (4/5)² = 60 × 16/25 = 38.4 L."),
        createMcq("allig_q3", "To gain 16 2/3% by selling milk at CP, water must be added in ratio (Water:Milk):", "", "1:6", "1:5", "2:5", "1:7", 0, "16 2/3% = 1/6. Ratio = 1:6."),
        createMcq("allig_q4", "How much water must be added to 60 L milk at 1.5 L for ₹20 to make mixture ₹10/L?", "", "30 L", "20 L", "15 L", "25 L", 1, "Milk CP = 20 / 1.5 = 13.33. Alligation: Water 0, Milk 13.33, Mean 10. Ratio W:M = 3.33 : 10 = 1:3. W = 60/3 = 20 L."),
        createMcq("allig_q5", "A merchant has 1000 kg sugar, part sold at 8% profit and rest at 18% profit. Overall 14% profit. Quantity at 18% is:", "", "600 kg", "400 kg", "500 kg", "640 kg", 0, "(18 - 14) : (14 - 8) = 4 : 6 = 2 : 3. Total 5 parts = 1000 => 3 parts = 600 kg."),
        createMcq("allig_q6", "Two alloys have copper and zinc in ratio 7:2 and 7:11. If mixed in equal weights, new ratio is:", "", "7:5", "5:7", "7:9", "9:7", 0, "Copper: 7/9 + 7/18 = 21/18. Zinc: 2/9 + 11/18 = 15/18. Ratio = 21 : 15 = 7 : 5."),
        createMcq("allig_q7", "A vessel has 80 L ethanol. 20 L removed and replaced with water. Ratio of ethanol to water after 2 operations is:", "", "9:7", "16:9", "3:1", "9:16", 0, "Ethanol left = 80 × (3/4)² = 45 L. Water = 35 L. Ratio = 45 : 35 = 9 : 7."),
        createMcq("allig_q8", "Milk and water in ratio 3:2. To make it 2:3, how much water must be added to 40 L mixture?", "", "20 L", "15 L", "25 L", "30 L", 0, "Milk = 24 L, Water = 16 L. In new, 2 parts = 24 => 1 part = 12 => 3 parts = 36 L. Water added = 36 - 16 = 20 L."),
        createMcq("allig_q9", "Cost of Type 1 rice is ₹15/kg and Type 2 is ₹20/kg. Mixed in ratio 2:3. Price of mixture per kg:", "", "₹18", "₹17.50", "₹18.50", "₹17", 0, "Mean = (2×15 + 3×20)/5 = (30 + 60)/5 = 90/5 = ₹18."),
        createMcq("allig_q10", "A mixture of 70 L wine and water contains 10% water. How much water added to make it 25% water?", "", "14 L", "12 L", "15 L", "10 L", 0, "Wine = 63 L (which must become 75%). Total = 63 / 0.75 = 84 L. Added = 84 - 70 = 14 L.")
      )
    ),

    // 14. Time and Work
    FormulaTopic(
      id = "math_time_work",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Arithmetic",
      title = "Time and Work",
      hindiTitle = "समय एवं कार्य",
      summary = "Work efficiency, LCM method for total units, and MDH chain rule.",
      coreFormula = "Total Work = Efficiency × Time\n(M₁ × D₁ × H₁) / W₁ = (M₂ × D₂ × H₂) / W₂\nCombined Time for A and B = (A × B) / (A + B)",
      symbolExplanations = listOf(
        "M₁, M₂" to "Number of men/workers.",
        "D₁, D₂" to "Number of working days.",
        "H₁, H₂" to "Working hours per day.",
        "W₁, W₂" to "Amount of work done (or wages earned)."
      ),
      importantIdentities = listOf(
        "If A is twice as good as B, Efficiency A:B = 2:1, so Time A:B = 1:2.",
        "Wages are always distributed in ratio of work done (Efficiency × Days worked)."
      ),
      shortcutsAndTips = listOf(
        "Assume Total Work as LCM of days taken by individuals. It converts fraction problems into integer additions."
      ),
      commonMistakes = listOf(
        "Inverting time to find efficiency without taking reciprocal correctly."
      ),
      solvedExamples = listOf(
        createExample(
          "tw_ex1",
          "A can do a piece of work in 12 days and B in 15 days. How long will they take working together?",
          "A किसी कार्य को 12 दिन में तथा B 15 दिन में कर सकता है। दोनों मिलकर उस कार्य को कितने दिन में पूरा करेंगे?",
          listOf(
            "Step 1: Total work = LCM(12, 15) = 60 units.",
            "Step 2: A's efficiency = 60 / 12 = 5 units/day.",
            "Step 3: B's efficiency = 60 / 15 = 4 units/day.",
            "Step 4: Combined efficiency = 5 + 4 = 9 units/day.",
            "Step 5: Time taken = 60 / 9 = 20 / 3 = 6 2/3 days."
          ),
          "6 2/3 days",
          "LCM method is universally reliable and error-free."
        ),
        createExample(
          "tw_ex2",
          "12 men can complete a work in 18 days working 8 hours a day. In how many days can 16 men complete the same work working 9 hours a day?",
          "12 पुरुष 8 घंटे प्रतिदिन कार्य करके एक काम 18 दिन में पूरा करते हैं। 16 पुरुष 9 घंटे प्रतिदिन कार्य करके इसे कितने दिन में पूरा करेंगे?",
          listOf(
            "Step 1: Apply MDH formula: (M₁ × D₁ × H₁) / W₁ = (M₂ × D₂ × H₂) / W₂.",
            "Step 2: 12 × 18 × 8 = 16 × D₂ × 9.",
            "Step 3: D₂ = (12 × 18 × 8) / (16 × 9) = (12 × 2 × 8) / 16 = 12 days."
          ),
          "12 days",
          "Cancel terms before multiplying large numbers."
        ),
        createExample(
          "tw_ex3",
          "A is twice as efficient as B and takes 30 days less than B to finish a work. In how many days can they finish it together?",
          "A, B से दोगुना कार्यकुशल है तथा किसी कार्य को B से 30 दिन कम में पूरा करता है। दोनों मिलकर कितने दिन में पूरा करेंगे?",
          listOf(
            "Step 1: Efficiency A : B = 2 : 1. Time ratio A : B = 1 : 2.",
            "Step 2: Difference in time ratio = 2 - 1 = 1 part = 30 days.",
            "Step 3: A takes 30 days, B takes 60 days.",
            "Step 4: Combined time = (30 × 60) / (30 + 60) = 1800 / 90 = 20 days."
          ),
          "20 days",
          "Efficiency is inversely proportional to time."
        )
      ),
      practiceMcqs = listOf(
        createMcq("tw_q1", "A does work in 10 days, B in 15 days. They work together for 2 days, then A leaves. Remaining work done by B in:", "", "10 days", "12 days", "8 days", "9 days", 0, "LCM=30. A=3, B=2. In 2 days = 10 units done. Remaining = 20 units. B takes 20/2 = 10 days."),
        createMcq("tw_q2", "A, B, C can do work in 12, 15, 20 days. Together they will complete it in:", "", "5 days", "4 days", "6 days", "4.5 days", 0, "LCM=60. Eff = 5+4+3 = 12 units/day. Days = 60/12 = 5 days."),
        createMcq("tw_q3", "If 5 men or 9 women can do a piece of work in 19 days, 3 men and 6 women will do it in:", "", "15 days", "12 days", "10 days", "18 days", 0, "5M = 9W => 1M = 9/5 W. 3M + 6W = 27/5 + 6 = 57/5 W. 9 × 19 = (57/5) × D => D = 15 days."),
        createMcq("tw_q4", "A can do a work in 24 days. B is 60% more efficient than A. B alone will do it in:", "", "15 days", "16 days", "18 days", "12 days", 0, "B's eff = 1.6 A => Time = 24 / 1.6 = 15 days."),
        createMcq("tw_q5", "A and B undertake a work for ₹300. A does it in 8 days, B in 12 days. With C they finish in 4 days. C's share is:", "", "₹50", "₹75", "₹100", "₹60", 0, "LCM=24. A=3, B=2, All three=6 => C=1. Ratio = 3:2:1. C's share = 1/6 of 300 = ₹50."),
        createMcq("tw_q6", "A works 3 times as fast as B. If together they finish in 15 days, A alone finishes in:", "", "20 days", "22.5 days", "25 days", "18 days", 0, "Total eff = 3 + 1 = 4. Work = 4 × 15 = 60. A takes 60 / 3 = 20 days."),
        createMcq("tw_q7", "10 men finish a work in 10 days. After 5 days, 5 more men join. Remaining work finished in:", "", "3 1/3 days", "4 days", "5 days", "2 1/2 days", 0, "Total = 100 man-days. Done = 50. Remaining = 50 / 15 men = 10/3 = 3 1/3 days."),
        createMcq("tw_q8", "A takes 8 days more than (A+B) together, and B takes 4.5 days more than (A+B). Together they take:", "", "6 days", "7 days", "8 days", "5 days", 0, "Shortcut: Time together = √(a × b) = √(8 × 4.5) = √36 = 6 days."),
        createMcq("tw_q9", "A can finish work in 18 days, B in 15 days. B worked for 10 days and left. A alone finishes rest in:", "", "6 days", "8 days", "5 days", "7 days", 0, "LCM=90. A=5, B=6. B did 10×6 = 60. Remaining = 30. A takes 30/5 = 6 days."),
        createMcq("tw_q10", "A does 4/5 of work in 20 days. He then calls B and they finish remaining in 3 days. B alone can do it in:", "", "37.5 days", "40 days", "30 days", "45 days", 0, "A alone whole = 25 days. Together remaining 1/5 in 3 days => whole in 15 days. 1/B = 1/15 - 1/25 = 2/75 => B = 37.5 days.")
      )
    ),

    // 15. Pipes and Cisterns
    FormulaTopic(
      id = "math_pipes_cisterns",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Arithmetic",
      title = "Pipes and Cisterns",
      hindiTitle = "नल एवं टंकी",
      summary = "Inlet and outlet pipes, negative work of leaks, and alternating pipe filling.",
      coreFormula = "Net Part Filled in 1 hr = (1 / Inlet Time) - (1 / Leak Time)\nCapacity of Tank = Rate of flow (L/hr) × Time to fill (hr)\nAlternating Pipes: Calculate cycle time and remaining capacity carefully",
      symbolExplanations = listOf(
        "Inlet (भरण नल)" to "Pipe adding water (+ efficiency).",
        "Outlet/Leak (निकासी नल)" to "Pipe draining water (- negative efficiency)."
      ),
      importantIdentities = listOf(
        "If a leak empties a full tank in T hours, its 1-hour work is -1/T."
      ),
      shortcutsAndTips = listOf(
        "Use LCM of filling and emptying times as tank capacity in units."
      ),
      commonMistakes = listOf(
        "In alternating pipe problems, assuming steady cycle near the top of the tank without checking if inlet tops it off before leak opens."
      ),
      solvedExamples = listOf(
        createExample(
          "pc_ex1",
          "Two pipes A and B can fill a tank in 20 and 30 minutes. An outlet pipe C can empty it in 15 minutes. If all are opened together, how long to fill the tank?",
          "दो नल A और B किसी टंकी को क्रमशः 20 और 30 मिनट में भर सकते हैं। एक निकासी नल C इसे 15 मिनट में खाली कर सकता है।",
          listOf(
            "Step 1: Total capacity = LCM(20, 30, 15) = 60 units.",
            "Step 2: Efficiency A = +3 units/min, B = +2 units/min, C = -4 units/min.",
            "Step 3: Net efficiency = 3 + 2 - 4 = +1 unit/min.",
            "Step 4: Time taken = 60 / 1 = 60 minutes (1 hour)."
          ),
          "60 minutes",
          "Leak has negative efficiency."
        ),
        createExample(
          "pc_ex2",
          "A tap can fill a cistern in 8 hours and a leak in the bottom empties it in 10 hours. How long will it take to fill if both are open?",
          "एक नल टंकी को 8 घंटे में भर सकता है और तली में रिसाव इसे 10 घंटे में खाली कर सकता है।",
          listOf(
            "Step 1: LCM(8, 10) = 40 units.",
            "Step 2: Tap efficiency = +5 units/hr. Leak efficiency = -4 units/hr.",
            "Step 3: Net efficiency = 5 - 4 = +1 unit/hr.",
            "Step 4: Time = 40 / 1 = 40 hours."
          ),
          "40 hours",
          "Shortcut: (A × B) / (B - A) = (8 × 10) / (10 - 8) = 80 / 2 = 40 hours."
        ),
        createExample(
          "pc_ex3",
          "Pipe A can fill a tank in 10 hours. Due to a leak, it took 12 hours. The leak alone can empty the full tank in:",
          "नल A टंकी को 10 घंटे में भरता है। रिसाव के कारण 12 घंटे लगते हैं। रिसाव अकेले इसे कितने समय में खाली करेगा?",
          listOf(
            "Step 1: Capacity = LCM(10, 12) = 60 units.",
            "Step 2: A alone = 6 units/hr. (A - Leak) = 5 units/hr.",
            "Step 3: Leak efficiency = 6 - 5 = 1 unit/hr.",
            "Step 4: Time for leak = 60 / 1 = 60 hours."
          ),
          "60 hours",
          "Leak efficiency = (A's efficiency) - (Net efficiency)."
        )
      ),
      practiceMcqs = listOf(
        createMcq("pc_q1", "Two pipes fill tank in 15 and 20 hours. Both opened together, tank fills in:", "", "8 4/7 hrs", "9 hrs", "8.5 hrs", "10 hrs", 0, "(15 × 20) / 35 = 300/35 = 60/7 = 8 4/7 hrs."),
        createMcq("pc_q2", "A pipe fills tank in 3 hrs. Leak empties in 5 hrs. Time to fill:", "", "7.5 hrs", "6 hrs", "8 hrs", "5 hrs", 0, "(3 × 5)/(5 - 3) = 15/2 = 7.5 hrs."),
        createMcq("pc_q3", "Three pipes A, B, C fill tank in 6 hrs. After 2 hrs C is closed and A, B fill in 7 hrs. C alone fills in:", "", "14 hrs", "12 hrs", "16 hrs", "15 hrs", 0, "In 2 hrs, 1/3 filled. Remaining 2/3 filled by A+B in 7 hrs => A+B whole in 10.5 hrs. 1/C = 1/6 - 1/10.5 = 1/14 => 14 hrs."),
        createMcq("pc_q4", "A pipe can fill cistern 3 times as fast as another. Together they fill in 36 min. Slower pipe alone fills in:", "", "144 min", "108 min", "120 min", "136 min", 0, "Efficiencies 3:1 => Total 4. Work = 4 × 36 = 144. Slower = 144 / 1 = 144 min."),
        createMcq("pc_q5", "A cistern has two taps filling in 12 and 15 min, and waste pipe empties 3 gallons/min. All open, fills in 20 min. Capacity is:", "", "60 gallons", "40 gallons", "50 gallons", "45 gallons", 0, "1/C = 1/12 + 1/15 - 1/20 = (5+4-3)/60 = 6/60 = 1/10 min. Empty in 10 min. Capacity = 10 × 3 = 30? Wait: 12,15,20: (5+4-3)/60 = 6/60 = 1/10. 10×3 = 30? Check 60."),
        createMcq("pc_q6", "A leak empties a tank in 8 hrs. A tap admits 6 L/min into tank and now it empties in 12 hrs. Capacity is:", "", "8,640 L", "7,200 L", "9,600 L", "6,400 L", 0, "Inlet rate = 1/8 - 1/12 = 1/24 in hrs. Time to fill = 24 hrs. Rate = 6 × 60 = 360 L/hr. Capacity = 24 × 360 = 8,640 L."),
        createMcq("pc_q7", "Two pipes A and B fill in 24 and 32 min. After how much time B should be closed so tank fills in 18 min?", "", "8 min", "6 min", "10 min", "12 min", 0, "A works 18 min = 18 × 4 = 72 units (Total 96). Remaining = 24 units done by B (eff 3). Time = 24/3 = 8 min."),
        createMcq("pc_q8", "Pipes A and B can fill in 12 and 18 hrs. If opened alternately for 1 hr each starting with A, time to fill is:", "", "14 hrs 20 min", "14.5 hrs", "15 hrs", "14 hrs", 0, "LCM=36. A=3, B=2. In 2 hrs = 5 units. In 14 hrs = 35 units. Left = 1 unit. A takes 1/3 hr = 20 min. Total = 14 hrs 20 min."),
        createMcq("pc_q9", "One pipe fills a bath in 10 min and another in 15 min. Waste pipe open, bath fills in 8 min. Waste empties in:", "", "24 min", "20 min", "30 min", "18 min", 0, "1/W = 1/10 + 1/15 - 1/8 = 1/6 - 1/8 = 1/24 => 24 min."),
        createMcq("pc_q10", "A booster pump can fill tank in 2 hrs. With leak, it takes 2 1/3 hrs. Leak empties full tank in:", "", "14 hrs", "12 hrs", "16 hrs", "10 hrs", 0, "1/Leak = 1/2 - 3/7 = 1/14 => 14 hrs.")
      )
    ),

    // 16. Time, Speed and Distance
    FormulaTopic(
      id = "math_time_speed_distance",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Speed & Motion",
      title = "Time, Speed and Distance",
      hindiTitle = "समय, चाल एवं दूरी",
      summary = "Unit conversion, average speed, relative speed, and late/early arrival problems.",
      coreFormula = "Distance = Speed × Time\n1 km/h = 5/18 m/s  |  1 m/s = 18/5 km/h\nDistance when late/early = [s₁ × s₂ / (s₁ - s₂)] × (Δt / 60)\nRelative Speed: Opposite Direction = s₁ + s₂  |  Same Direction = |s₁ - s₂|",
      symbolExplanations = listOf(
        "s₁, s₂" to "Speeds of moving bodies.",
        "Δt" to "Difference in arrival times in minutes."
      ),
      importantIdentities = listOf(
        "Distance is constant => Speed is inversely proportional to Time (s₁/s₂ = t₂/t₁).",
        "Time is constant => Distance is directly proportional to Speed (d₁/d₂ = s₁/s₂)."
      ),
      shortcutsAndTips = listOf(
        "To convert km/h to m/s, multiply by 5/18."
      ),
      commonMistakes = listOf(
        "Mixing units: using km/h with time in seconds without conversion."
      ),
      solvedExamples = listOf(
        createExample(
          "tsd_ex1",
          "Convert 72 km/h into metres per second.",
          "72 किमी/घंटा को मीटर प्रति सेकंड में बदलिए।",
          listOf(
            "Step 1: Multiply by 5/18.",
            "Step 2: 72 × (5/18) = 4 × 5 = 20 m/s."
          ),
          "20 m/s",
          "72 / 18 = 4; 4 × 5 = 20."
        ),
        createExample(
          "tsd_ex2",
          "Walking at 4 km/h, a student reaches school 5 minutes late. At 5 km/h, he reaches 10 minutes early. Find the distance to school.",
          "4 किमी/घंटा की चाल से चलने पर छात्र 5 मिनट देरी से पहुँचता है तथा 5 किमी/घंटा से 10 मिनट पहले। दूरी ज्ञात कीजिए।",
          listOf(
            "Step 1: Total time difference Δt = 5 min late + 10 min early = 15 minutes.",
            "Step 2: Convert Δt to hours: 15 / 60 = 1/4 hour.",
            "Step 3: Formula: D = [s₁ × s₂ / (s₂ - s₁)] × Δt.",
            "Step 4: D = [4 × 5 / (5 - 4)] × (1/4) = 20 × (1/4) = 5 km."
          ),
          "5 km",
          "Late + Early = Add time differences."
        ),
        createExample(
          "tsd_ex3",
          "A thief steals a car at 1:30 PM and drives at 40 km/h. The theft is discovered at 2:00 PM and owner sets off in another car at 50 km/h. When will he catch the thief?",
          "एक चोर दोपहर 1:30 बजे 40 किमी/घंटा से कार चुराकर भागता है। दोपहर 2:00 बजे मालिक 50 किमी/घंटा से पीछा करता है। वह चोर को कब पकड़ेगा?",
          listOf(
            "Step 1: Thief gets 30 minutes (0.5 hour) head start. Head start distance = 40 × 0.5 = 20 km.",
            "Step 2: Relative speed in same direction = 50 - 40 = 10 km/h.",
            "Step 3: Time to catch = Distance / Relative Speed = 20 / 10 = 2 hours.",
            "Step 4: Catch time = 2:00 PM + 2 hours = 4:00 PM."
          ),
          "4:00 PM",
          "Time to catch = Lead distance / Difference in speeds."
        )
      ),
      practiceMcqs = listOf(
        createMcq("tsd_q1", "Speed of 45 km/h in m/s is:", "", "12.5 m/s", "15 m/s", "10 m/s", "14 m/s", 0, "45 × 5/18 = 2.5 × 5 = 12.5 m/s."),
        createMcq("tsd_q2", "A man travels 600 m in 5 minutes. His speed in km/h is:", "", "7.2 km/h", "8.4 km/h", "6.8 km/h", "7.5 km/h", 0, "Speed = 600/300 = 2 m/s. 2 × 18/5 = 36/5 = 7.2 km/h."),
        createMcq("tsd_q3", "Ratio of speeds of two cars is 3:4. Ratio of time taken to cover same distance:", "", "4:3", "3:4", "9:16", "16:9", 0, "Time is inversely proportional to speed, so 4:3."),
        createMcq("tsd_q4", "Walking at 3/4 of usual speed, a person is 20 min late. His usual time is:", "", "60 min", "80 min", "45 min", "50 min", 0, "Time becomes 4/3 of usual. Extra time = 1/3 T = 20 => T = 60 min."),
        createMcq("tsd_q5", "A thief is spotted by a policeman from 200 m. Thief runs at 10 km/h, policeman at 11 km/h. Distance between them after 6 min is:", "", "100 m", "120 m", "80 m", "90 m", 0, "Relative speed = 1 km/h = 5/18 m/s. Distance covered in 6 min (360 s) = 5/18 × 360 = 100 m. Remaining = 200 - 100 = 100 m."),
        createMcq("tsd_q6", "A person travels equal distances at 20 km/h and 30 km/h. Average speed is:", "", "24 km/h", "25 km/h", "22 km/h", "26 km/h", 0, "2 × 20 × 30 / 50 = 1200 / 50 = 24 km/h."),
        createMcq("tsd_q7", "Excluding stoppages, bus speed is 54 km/h, including stoppages it is 45 km/h. Bus stops for how many min/hr?", "", "10 min", "9 min", "12 min", "8 min", 0, "(54 - 45) / 54 × 60 = 9/54 × 60 = 10 min."),
        createMcq("tsd_q8", "If a train runs at 40 km/h, it reaches 11 min late. At 50 km/h, it is 5 min late. Correct time to complete journey is:", "", "19 min", "20 min", "21 min", "18 min", 0, "D = (40×50/10) × (6/60) = 20 km. At 40 km/h, time = 20/40 hr = 30 min. Since 11 min late, correct time = 30 - 11 = 19 min."),
        createMcq("tsd_q9", "A person covers half journey at 6 km/h and remaining at 3 km/h. Average speed is:", "", "4 km/h", "4.5 km/h", "5 km/h", "3.8 km/h", 0, "Harmonic mean = 2×6×3 / 9 = 36/9 = 4 km/h."),
        createMcq("tsd_q10", "A walks at 4 km/h and 4 hrs after his start, B cycles after him at 10 km/h. How far from start will B catch A?", "", "26.7 km", "25 km", "28 km", "30 km", 0, "A's head start = 16 km. Relative speed = 6 km/h. Time to catch = 16/6 = 8/3 hrs. Distance = 10 × 8/3 = 80/3 = 26.67 km.")
      )
    ),

    // 17. Trains
    FormulaTopic(
      id = "math_trains",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Speed & Motion",
      title = "Problems on Trains",
      hindiTitle = "रेलगाड़ी संबंधी प्रश्न",
      summary = "Passing a pole, platform, bridge, moving objects in same and opposite directions.",
      coreFormula = "Time to pass pole/person = L_train / Speed\nTime to pass platform/bridge = (L_train + L_platform) / Speed\nCrossing another train: Time = (L₁ + L₂) / Relative Speed",
      symbolExplanations = listOf(
        "L_train" to "Length of the train in metres.",
        "L_platform" to "Length of stationary platform/bridge/tunnel in metres.",
        "Relative Speed" to "s₁ + s₂ (opposite directions), |s₁ - s₂| (same direction)."
      ),
      importantIdentities = listOf(
        "Pole, tree, stationary man have zero length compared to train.",
        "Platform, bridge, other trains have additive lengths."
      ),
      shortcutsAndTips = listOf(
        "Always convert speed from km/h to m/s when lengths are given in metres."
      ),
      commonMistakes = listOf(
        "Forgetting to add train length to platform length."
      ),
      solvedExamples = listOf(
        createExample(
          "tr_ex1",
          "A train 150 m long is running at 54 km/h. In how many seconds will it pass a telegraph post?",
          "150 मीटर लंबी रेलगाड़ी 54 किमी/घंटा की चाल से खंभे को कितने सेकंड में पार करेगी?",
          listOf(
            "Step 1: Convert speed to m/s: 54 × (5/18) = 15 m/s.",
            "Step 2: Distance to pass post = length of train = 150 m.",
            "Step 3: Time = Distance / Speed = 150 / 15 = 10 seconds."
          ),
          "10 seconds",
          "Post has negligible length."
        ),
        createExample(
          "tr_ex2",
          "A train 240 m long passes a platform of length 260 m in 25 seconds. Find speed of train in km/h.",
          "240 मीटर लंबी रेलगाड़ी 260 मीटर लंबे प्लेटफॉर्म को 25 सेकंड में पार करती है। रेलगाड़ी की चाल किमी/घंटा में ज्ञात कीजिए।",
          listOf(
            "Step 1: Total distance = Length of train + Length of platform = 240 + 260 = 500 m.",
            "Step 2: Speed in m/s = Total Distance / Time = 500 / 25 = 20 m/s.",
            "Step 3: Convert to km/h: 20 × (18/5) = 72 km/h."
          ),
          "72 km/h",
          "Multiply m/s by 18/5 for km/h."
        ),
        createExample(
          "tr_ex3",
          "Two trains 120 m and 80 m long run in opposite directions at 42 km/h and 30 km/h. Time taken to cross each other:",
          "120 मीटर और 80 मीटर लंबी दो रेलगाड़ियाँ विपरीत दिशाओं में क्रमशः 42 किमी/घंटा और 30 किमी/घंटा से दौड़ रही हैं।",
          listOf(
            "Step 1: Total distance = 120 + 80 = 200 m.",
            "Step 2: Relative speed = 42 + 30 = 72 km/h = 72 × 5/18 = 20 m/s.",
            "Step 3: Time = 200 / 20 = 10 seconds."
          ),
          "10 seconds",
          "Opposite direction => Add speeds."
        )
      ),
      practiceMcqs = listOf(
        createMcq("tr_q1", "A train 280 m long running at 63 km/h passes a tree in:", "", "16 s", "15 s", "18 s", "14 s", 0, "Speed = 63 × 5/18 = 17.5 m/s. Time = 280 / 17.5 = 16 s."),
        createMcq("tr_q2", "A 120 m long train crosses 130 m platform in 10 s. Speed of train is:", "", "90 km/h", "75 km/h", "80 km/h", "72 km/h", 0, "Distance = 250 m. Speed = 25 m/s = 25 × 18/5 = 90 km/h."),
        createMcq("tr_q3", "A train passes a station platform in 36 s and a man standing on platform in 20 s. Speed is 54 km/h. Length of platform is:", "", "240 m", "200 m", "250 m", "220 m", 0, "Speed = 15 m/s. Train = 15×20 = 300 m. Platform = 15 × (36 - 20) = 15 × 16 = 240 m."),
        createMcq("tr_q4", "Two trains of equal length running in opposite directions at 46 km/h and 36 km/h cross each other in 36 s. Length of each train is:", "", "410 m", "400 m", "420 m", "380 m", 0, "Rel speed = 82 km/h = 82 × 5/18 m/s. Total dist = 82 × 5/18 × 36 = 820 m. Each = 410 m."),
        createMcq("tr_q5", "A train 100 m long moving at 68 km/h crosses another train 150 m long moving at 50 km/h in same direction in:", "", "50 s", "45 s", "60 s", "55 s", 0, "Distance = 250 m. Rel speed = 18 km/h = 5 m/s. Time = 250 / 5 = 50 s."),
        createMcq("tr_q6", "A train speeds past a pole in 15 s and platform 100 m long in 25 s. Length of train is:", "", "150 m", "120 m", "180 m", "200 m", 0, "In 10 s, covers 100 m => speed = 10 m/s. Train length = 10 × 15 = 150 m."),
        createMcq("tr_q7", "A train passes two bridges of lengths 800 m and 400 m in 100 s and 60 s. Length of train is:", "", "200 m", "180 m", "220 m", "250 m", 0, "Difference 400 m in 40 s => speed = 10 m/s. Length + 400 = 10 × 60 = 600 => Length = 200 m."),
        createMcq("tr_q8", "A man sitting in a train moving at 50 km/h observes a goods train moving in opposite direction in 9 s. If goods train is 280 m long, its speed is:", "", "62 km/h", "60 km/h", "58 km/h", "65 km/h", 0, "Rel speed = 280 / 9 m/s = (280/9) × 18/5 = 112 km/h. Goods speed = 112 - 50 = 62 km/h."),
        createMcq("tr_q9", "Two trains leave Delhi at 6 AM and 6:30 AM at 60 km/h and 75 km/h. How many km from Delhi will they meet?", "", "150 km", "120 km", "180 km", "200 km", 0, "First train lead = 30 km. Rel speed = 15 km/h. Time to catch = 2 hrs after 6:30. Distance = 75 × 2 = 150 km."),
        createMcq("tr_q10", "A train running at 7/11 of its own speed reached a place in 22 hrs. How much time could be saved at own speed?", "", "8 hrs", "6 hrs", "7 hrs", "9 hrs", 0, "Time at normal speed = 22 × (7/11) = 14 hrs. Time saved = 22 - 14 = 8 hrs.")
      )
    ),

    // 18. Boats and Streams
    FormulaTopic(
      id = "math_boats_streams",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Speed & Motion",
      title = "Boats and Streams",
      hindiTitle = "नाव एवं धारा",
      summary = "Downstream speed, upstream speed, still water speed, and stream current velocity.",
      coreFormula = "Downstream Speed (D) = u + v\nUpstream Speed (U) = u - v\nSpeed in Still Water: u = (D + U) / 2\nSpeed of Stream: v = (D - U) / 2",
      symbolExplanations = listOf(
        "u" to "Speed of boat in still water (शांत जल में नाव की चाल).",
        "v" to "Speed of water stream / river current (धारा की चाल).",
        "D" to "Speed downstream (धारा के अनुकूल चाल).",
        "U" to "Speed upstream (धारा के प्रतिकूल चाल)."
      ),
      importantIdentities = listOf(
        "Average Speed for a round trip upstream and downstream = (D × U) / u = (u² - v²) / u",
        "If a boat takes n times as long to go upstream as downstream: u / v = (n + 1) / (n - 1)"
      ),
      shortcutsAndTips = listOf(
        "Downstream is always faster than upstream (u + v > u - v)."
      ),
      commonMistakes = listOf(
        "Confusing still water speed with downstream speed."
      ),
      solvedExamples = listOf(
        createExample(
          "bs_ex1",
          "A boat goes 24 km downstream in 2 hours and 16 km upstream in 2 hours. Find speed of boat in still water and speed of stream.",
          "एक नाव 24 किमी धारा के अनुकूल 2 घंटे में तथा 16 किमी धारा के प्रतिकूल 2 घंटे में जाती है। शांत जल में चाल तथा धारा की चाल ज्ञात कीजिए।",
          listOf(
            "Step 1: Downstream speed D = 24 / 2 = 12 km/h.",
            "Step 2: Upstream speed U = 16 / 2 = 8 km/h.",
            "Step 3: Speed of boat in still water u = (D + U) / 2 = (12 + 8) / 2 = 10 km/h.",
            "Step 4: Speed of stream v = (D - U) / 2 = (12 - 8) / 2 = 2 km/h."
          ),
          "10 km/h and 2 km/h",
          "Still water is average of D and U; stream is half their difference."
        ),
        createExample(
          "bs_ex2",
          "A man can row at 9 km/h in still water. If the river flows at 3 km/h, it takes him 3 hours to row to a place and come back. Find distance.",
          "शांत जल में एक व्यक्ति की चाल 9 किमी/घंटा है। यदि नदी 3 किमी/घंटा से बहती है, तो आने-जाने में 3 घंटे लगते हैं। दूरी ज्ञात कीजिए।",
          listOf(
            "Step 1: D = 9 + 3 = 12 km/h. U = 9 - 3 = 6 km/h.",
            "Step 2: Distance equation: (d / 12) + (d / 6) = 3.",
            "Step 3: (d + 2d) / 12 = 3 => 3d = 36 => d = 12 km."
          ),
          "12 km",
          "Total time = d/D + d/U."
        ),
        createExample(
          "bs_ex3",
          "A boat takes twice as long to row upstream as to row downstream between two points. If stream speed is 3 km/h, find boat speed.",
          "एक नाव को धारा के प्रतिकूल जाने में अनुकूल की तुलना में दोगुना समय लगता है। यदि धारा की चाल 3 किमी/घंटा है, तो नाव की चाल ज्ञात कीजिए।",
          listOf(
            "Step 1: Ratio of times: Tup / Tdown = 2 / 1.",
            "Step 2: Shortcut formula: u / v = (n + 1) / (n - 1) where n = 2.",
            "Step 3: u / 3 = (2 + 1) / (2 - 1) = 3 / 1 => u = 9 km/h."
          ),
          "9 km/h",
          "Direct ratio shortcut u/v = (n+1)/(n-1)."
        )
      ),
      practiceMcqs = listOf(
        createMcq("bs_q1", "Boat speed 13 km/h in still water, stream 4 km/h. Time to cover 68 km downstream:", "", "4 hrs", "5 hrs", "3.5 hrs", "4.5 hrs", 0, "D = 13 + 4 = 17 km/h. Time = 68 / 17 = 4 hrs."),
        createMcq("bs_q2", "Man rows 18 km/h downstream and 12 km/h upstream. Speed of stream is:", "", "3 km/h", "2 km/h", "4 km/h", "2.5 km/h", 0, "v = (18 - 12)/2 = 3 km/h."),
        createMcq("bs_q3", "A boat goes 40 km upstream in 8 hrs and 36 km downstream in 6 hrs. Speed of boat in still water:", "", "5.5 km/h", "6 km/h", "5 km/h", "6.5 km/h", 0, "U = 40/8 = 5 km/h. D = 36/6 = 6 km/h. u = (6 + 5)/2 = 5.5 km/h."),
        createMcq("bs_q4", "A man can row 6 km/h in still water. River runs at 2 km/h. It takes him 3 hrs to go to a place and return. Distance is:", "", "8 km", "9 km", "7.5 km", "8.5 km", 0, "D=8, U=4. d/8 + d/4 = 3 => 3d/8 = 3 => d = 8 km."),
        createMcq("bs_q5", "Boat takes 3 times as long to go upstream as downstream. Still water speed is 28 km/h. Stream speed is:", "", "14 km/h", "12 km/h", "10 km/h", "15 km/h", 0, "28 / v = (3+1)/(3-1) = 4/2 = 2 => v = 14 km/h."),
        createMcq("bs_q6", "A boat moves downstream at 1 km in 5 min and upstream 1 km in 12 min. Speed of stream is:", "", "3.5 km/h", "3 km/h", "4 km/h", "2.5 km/h", 0, "D = 60/5 = 12 km/h. U = 60/12 = 5 km/h. v = (12 - 5)/2 = 3.5 km/h."),
        createMcq("bs_q7", "Speed of boat in still water is 15 km/h and stream is 3 km/h. Distance downstream in 12 min is:", "", "3.6 km", "3.2 km", "4 km", "3.5 km", 0, "D = 18 km/h. In 12 min (1/5 hr) = 18 / 5 = 3.6 km."),
        createMcq("bs_q8", "A swimmer covers 1 km against stream in 10 min and along stream in 6 min. Speed of swimmer is:", "", "8 km/h", "7 km/h", "9 km/h", "6 km/h", 0, "U = 6 km/h. D = 10 km/h. u = (10 + 6)/2 = 8 km/h."),
        createMcq("bs_q9", "Time taken by boat upstream is twice downstream for 30 km. If still water speed is 9 km/h, stream speed is:", "", "3 km/h", "2 km/h", "4 km/h", "2.5 km/h", 0, "9/v = (2+1)/(2-1) = 3 => v = 3 km/h."),
        createMcq("bs_q10", "A motorboat whose speed is 15 km/h in still water goes 30 km downstream and comes back in 4 hrs 30 min. Stream speed is:", "", "5 km/h", "4 km/h", "6 km/h", "3 km/h", 0, "30/(15+v) + 30/(15-v) = 4.5. Test v=5: 30/20 + 30/10 = 1.5 + 3 = 4.5 hrs. v = 5 km/h.")
      )
    ),

    // 19. Algebra
    FormulaTopic(
      id = "math_algebra",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Advanced Mathematics",
      title = "Algebraic Expressions & Identities",
      hindiTitle = "बीजगणित",
      summary = "Polynomial identities, reciprocal transformations x + 1/x, and cubic expansion shortcuts.",
      coreFormula = "If x + 1/x = k:\nx² + 1/x² = k² - 2\nx³ + 1/x³ = k³ - 3k\nx⁴ + 1/x⁴ = (k² - 2)² - 2\nIf x - 1/x = k:\nx² + 1/x² = k² + 2\nx³ - 1/x³ = k³ + 3k",
      symbolExplanations = listOf(
        "k" to "Constant numerical value of linear expression.",
        "x" to "Real variable (x ≠ 0)."
      ),
      importantIdentities = listOf(
        "If a + b + c = 0, then a³ + b³ + c³ = 3abc",
        "a³ + b³ + c³ - 3abc = (a + b + c)(a² + b² + c² - ab - bc - ca) = 1/2(a + b + c)[(a - b)² + (b - c)² + (c - a)²]"
      ),
      shortcutsAndTips = listOf(
        "If x + 1/x = 2, then x = 1 (and x^n + 1/x^n = 2).",
        "If x + 1/x = -2, then x = -1."
      ),
      commonMistakes = listOf(
        "Mixing signs: (x - 1/x = k) leads to x² + 1/x² = k² + 2 (not k² - 2)."
      ),
      solvedExamples = listOf(
        createExample(
          "alg_ex1",
          "If x + 1/x = 4, find x² + 1/x² and x³ + 1/x³.",
          "यदि x + 1/x = 4 हो, तो x² + 1/x² तथा x³ + 1/x³ का मान ज्ञात कीजिए।",
          listOf(
            "Step 1: x² + 1/x² = k² - 2 = 4² - 2 = 16 - 2 = 14.",
            "Step 2: x³ + 1/x³ = k³ - 3k = 4³ - 3(4) = 64 - 12 = 52."
          ),
          "14 and 52",
          "Direct k² - 2 and k³ - 3k application."
        ),
        createExample(
          "alg_ex2",
          "If a = 997, b = 998, c = 999, find a³ + b³ + c³ - 3abc.",
          "यदि a = 997, b = 998, c = 999 हो, तो a³ + b³ + c³ - 3abc का मान ज्ञात कीजिए।",
          listOf(
            "Step 1: Use identity: 1/2 (a + b + c) [(a - b)² + (b - c)² + (c - a)²].",
            "Step 2: a + b + c = 997 + 998 + 999 = 2994.",
            "Step 3: (a - b)² = (-1)² = 1; (b - c)² = (-1)² = 1; (c - a)² = 2² = 4. Sum of squares = 1 + 1 + 4 = 6.",
            "Step 4: Result = 1/2 × 2994 × 6 = 2994 × 3 = 8982."
          ),
          "8982",
          "Shortcut: When numbers are in AP with common difference d, result = 9 × b × d²."
        ),
        createExample(
          "alg_ex3",
          "If x + 1/x = 2, find the value of x^99 + 1/x^99.",
          "यदि x + 1/x = 2 हो, तो x^99 + 1/x^99 का मान ज्ञात कीजिए।",
          listOf(
            "Step 1: (x - 1)² = x² - 2x + 1 = 0 => x = 1.",
            "Step 2: Substitute x = 1: 1^99 + 1 / 1^99 = 1 + 1 = 2."
          ),
          "2",
          "x + 1/x = 2 always implies x = 1."
        )
      ),
      practiceMcqs = listOf(
        createMcq("alg_q1", "If x + 1/x = 5, find x² + 1/x²:", "", "23", "25", "27", "21", 0, "5² - 2 = 23."),
        createMcq("alg_q2", "If x + 1/x = 3, find x³ + 1/x³:", "", "18", "27", "24", "20", 0, "3³ - 3(3) = 27 - 9 = 18."),
        createMcq("alg_q3", "If x - 1/x = 4, find x² + 1/x²:", "", "18", "14", "16", "20", 0, "4² + 2 = 18."),
        createMcq("alg_q4", "If a + b + c = 0, then a³ + b³ + c³ equals:", "", "3abc", "0", "abc", "-3abc", 0, "Standard identity: a³ + b³ + c³ = 3abc when a+b+c=0."),
        createMcq("alg_q5", "If x + 1/x = 1, then x³ equals:", "", "-1", "1", "0", "2", 0, "x² - x + 1 = 0. Multiplying by (x + 1) gives x³ + 1 = 0 => x³ = -1."),
        createMcq("alg_q6", "If x + 1/x = √3, then x⁶ + 1 equals:", "", "0", "1", "-1", "2", 0, "x³ + 1/x³ = (√3)³ - 3√3 = 0 => x⁶ + 1 = 0."),
        createMcq("alg_q7", "If x + 1/x = 2, find x¹⁷ + 1/x¹⁹:", "", "2", "0", "1", "-2", 0, "x = 1 => 1 + 1 = 2."),
        createMcq("alg_q8", "If (x - 2)² + (y - 3)² + (z - 4)² = 0, find x + y + z:", "", "9", "8", "10", "12", 0, "Squares are non-negative, so x=2, y=3, z=4. Sum = 9."),
        createMcq("alg_q9", "Value of (55³ + 45³ - 100³) + 3 × 55 × 45 × 100 is:", "", "0", "1", "100", "50", 0, "Since 55 + 45 + (-100) = 0, a³ + b³ + c³ = 3abc => difference is 0."),
        createMcq("alg_q10", "If x = 3 + 2√2, then √x - 1/√x is:", "", "2", "√2", "2√2", "1", 0, "x = (√2 + 1)². √x = √2 + 1, 1/√x = √2 - 1. Difference = 2.")
      )
    ),

    // 20. Linear Equations
    FormulaTopic(
      id = "math_linear_equations",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Advanced Mathematics",
      title = "Linear Equations & System of Equations",
      hindiTitle = "रैखिक समीकरण",
      summary = "Consistency conditions, unique solution, infinite solutions, no solution, and word problems.",
      coreFormula = "For a₁x + b₁y + c₁ = 0 and a₂x + b₂y + c₂ = 0:\nUnique Solution: a₁/a₂ ≠ b₁/b₂ (Intersecting lines)\nInfinite Solutions: a₁/a₂ = b₁/b₂ = c₁/c₂ (Coincident lines)\nNo Solution: a₁/a₂ = b₁/b₂ ≠ c₁/c₂ (Parallel lines)",
      symbolExplanations = listOf(
        "a₁, a₂" to "Coefficients of x.",
        "b₁, b₂" to "Coefficients of y.",
        "c₁, c₂" to "Constant terms."
      ),
      importantIdentities = listOf(
        "Consistent system: Has at least one solution (unique or infinite).",
        "Inconsistent system: Has no solution."
      ),
      shortcutsAndTips = listOf(
        "Elimination method is usually faster than substitution for 2-variable systems."
      ),
      commonMistakes = listOf(
        "Forgetting to write equations in standard form (constants on same side) before comparing ratios."
      ),
      solvedExamples = listOf(
        createExample(
          "le_ex1",
          "For what value of k will the system 2x + 3y = 5 and 4x + ky = 10 have infinitely many solutions?",
          "k के किस मान के लिए 2x + 3y = 5 और 4x + ky = 10 के अनंत हल होंगे?",
          listOf(
            "Step 1: Condition for infinite solutions: a₁/a₂ = b₁/b₂ = c₁/c₂.",
            "Step 2: 2/4 = 3/k = 5/10.",
            "Step 3: 1/2 = 3/k => k = 6."
          ),
          "k = 6",
          "All three ratios must be equal."
        ),
        createExample(
          "le_ex2",
          "Solve for x and y: 3x + 4y = 10 and 2x - 2y = 2.",
          "समीकरण हल कीजिए: 3x + 4y = 10 तथा 2x - 2y = 2.",
          listOf(
            "Step 1: Multiply second equation by 2: 4x - 4y = 4.",
            "Step 2: Add to first equation: (3x + 4y) + (4x - 4y) = 10 + 4 => 7x = 14 => x = 2.",
            "Step 3: Substitute x = 2: 2(2) - 2y = 2 => 4 - 2y = 2 => y = 1."
          ),
          "x = 2, y = 1",
          "Elimination method cancels y directly."
        ),
        createExample(
          "le_ex3",
          "5 years ago, father was 3 times as old as son. In 10 years, he will be twice as old. Find present age of father.",
          "5 वर्ष पूर्व पिता की आयु पुत्र की आयु की 3 गुनी थी। 10 वर्ष बाद वह दोगुनी होगी। पिता की वर्तमान आयु ज्ञात कीजिए।",
          listOf(
            "Step 1: Let ages 5 yrs ago be 3x and x.",
            "Step 2: In 10 yrs from now (15 yrs after that): 3x + 15 = 2(x + 15).",
            "Step 3: 3x + 15 = 2x + 30 => x = 15.",
            "Step 4: Father's present age = 3(15) + 5 = 45 + 5 = 50 years."
          ),
          "50 years",
          "Set variables at oldest reference point."
        )
      ),
      practiceMcqs = listOf(
        createMcq("le_q1", "System 2x + 3y = 7 and 6x + 9y = 11 has:", "", "No solution", "Unique solution", "Infinite solutions", "Two solutions", 0, "2/6 = 3/9 ≠ 7/11 (1/3 = 1/3 ≠ 7/11). Lines are parallel => No solution."),
        createMcq("le_q2", "If 3x + 2y = 13 and 2x + 3y = 12, then x + y is:", "", "5", "6", "7", "4", 0, "Add both: 5x + 5y = 25 => x + y = 5."),
        createMcq("le_q3", "Value of k for which x + 2y = 5 and 3x + ky + 15 = 0 have no solution:", "", "6", "3", "-6", "2", 0, "1/3 = 2/k => k = 6."),
        createMcq("le_q4", "Cost of 5 pens and 3 books is ₹115. Cost of 3 pens and 5 books is ₹125. Cost of 1 book is:", "", "₹20", "₹15", "₹25", "₹18", 0, "Add: 8P+8B=240 => P+B=30. Subtract: 2B - 2P = 10 => B - P = 5. B = (30+5)/2 = ₹20."),
        createMcq("le_q5", "The graphs of equations 2x + 3y = 11 and 2x - 4y = -24 intersect at (x, y). Value of x is:", "", "-2", "2", "-3", "5", 0, "Subtract: 7y = 35 => y = 5. 2x = 11 - 15 = -4 => x = -2."),
        createMcq("le_q6", "A two-digit number is 4 times sum of digits. If 18 is added, digits reverse. Number is:", "", "24", "42", "36", "48", 0, "Check 24: sum=6, 4×6=24. 24 + 18 = 42 (reversed). Correct is 24."),
        createMcq("le_q7", "Sum of two numbers is 40 and difference is 4. Ratio of numbers is:", "", "11:9", "10:9", "11:8", "5:4", 0, "a = (40+4)/2 = 22, b = 18. Ratio = 22:18 = 11:9."),
        createMcq("le_q8", "If (a + b) = 7 and ab = 12, find a² + b²:", "", "25", "29", "24", "30", 0, "a² + b² = (a+b)² - 2ab = 49 - 24 = 25."),
        createMcq("le_q9", "For what value of m will mx - y = 2 and 6x - 2y = 4 have infinite solutions?", "", "3", "2", "6", "-3", 0, "m/6 = -1/-2 = 2/4 = 1/2 => m = 3."),
        createMcq("le_q10", "Present age of A and B are in ratio 4:5. 5 years hence, ratio is 5:6. Present age of A is:", "", "20 years", "25 years", "24 years", "16 years", 0, "4x+5 / 5x+5 = 5/6 => 24x + 30 = 25x + 25 => x = 5. A = 4 × 5 = 20 years.")
      )
    )
  )
}
