package com.example.domain.model

enum class CurrentAffairsCategory(val displayName: String, val chipLabel: String) {
  ALL("All Feeds", "All"),
  NATIONAL("National Affairs", "National"),
  GOV_SCHEMES("Government Schemes", "Schemes"),
  POLITY("Polity & Governance", "Polity"),
  ECONOMY("Economy & Trade", "Economy"),
  BANKING("Banking & Finance", "Banking"),
  SCIENCE("Science & Tech", "Science"),
  DEFENCE("Defence & Security", "Defence"),
  ENVIRONMENT("Environment & Climate", "Environment"),
  INTERNATIONAL("International Affairs", "International"),
  APPOINTMENTS("Appointments & Resignations", "Appointments"),
  AWARDS("Awards & Honours", "Awards"),
  SPORTS("Sports & Games", "Sports"),
  REPORTS_INDICES("Reports & Indices", "Reports"),
  STATE_NEWS("State & UT News", "State News");

  companion object {
    private fun hasWord(text: String, word: String): Boolean {
      return Regex("\\b" + Regex.escape(word) + "\\b", RegexOption.IGNORE_CASE).containsMatchIn(text)
    }

    fun classify(title: String, description: String = ""): CurrentAffairsCategory {
      val text = "$title $description".lowercase()
      return when {
        hasWord(text, "rbi") || text.contains("reserve bank") || text.contains("repo rate") ||
            text.contains("monetary policy") || text.contains("banking") || hasWord(text, "nbfc") ||
            text.contains("bad bank") || text.contains("treasury bill") -> BANKING

        hasWord(text, "isro") || text.contains("satellite") || text.contains("space") ||
            text.contains("artificial intelligence") || text.contains("quantum") ||
            text.contains("scientific") || text.contains("technology") -> SCIENCE

        hasWord(text, "drdo") || text.contains("defence") || text.contains("defense") || text.contains("army") ||
            text.contains("navy") || text.contains("air force") ||
            text.contains("missile") || text.contains("warship") || text.contains("border") ||
            text.contains("security council") || text.contains("ins ") -> DEFENCE

        text.contains("gdp") || text.contains("inflation") || text.contains("export") ||
            text.contains("import") || text.contains("fiscal") || hasWord(text, "gst") ||
            text.contains("commerce") || text.contains("economy") ||
            hasWord(text, "forex") || hasWord(text, "fdi") -> ECONOMY

        text.contains("yojana") || text.contains("scheme") || text.contains("pradhan mantri") ||
            text.contains("beneficiary") || text.contains("portal") ||
            text.contains("dhan-dhaanya") || text.contains("pm-") || text.contains("pmay") -> GOV_SCHEMES

        text.contains("environment") || text.contains("pollution") || text.contains("forest") ||
            text.contains("wildlife") || text.contains("climate") || text.contains("cop") ||
            text.contains("renewable") || text.contains("solar") || text.contains("biodiversity") ||
            text.contains("tiger") || text.contains("wetland") -> ENVIRONMENT

        text.contains("supreme court") || text.contains("high court") || text.contains("constitution") ||
            text.contains("parliament") || text.contains("lok sabha") || text.contains("rajya sabha") ||
            text.contains("bill") || text.contains("ordinance") || text.contains("judiciary") ||
            text.contains("election commission") -> POLITY

        text.contains("appointed") || text.contains("takes charge") || text.contains("governor") ||
            text.contains("chief justice") || text.contains("chairman") || text.contains("director general") ||
            text.contains("secretary") -> APPOINTMENTS

        text.contains("award") || text.contains("prize") || text.contains("padma") ||
            text.contains("bharat ratna") || text.contains("sahitya") || text.contains("khel ratna") ||
            text.contains("nobel") || text.contains("honour") || text.contains("felicitat") -> AWARDS

        text.contains("cricket") || text.contains("badminton") || text.contains("olympic") ||
            text.contains("asian games") || text.contains("fifa") || text.contains("hockey") ||
            text.contains("championship") || text.contains("tournament") || text.contains("medal") -> SPORTS

        text.contains("index") || text.contains("report") || text.contains("ranking") ||
            text.contains("survey") || text.contains("niti aayog") || text.contains("wef") ||
            text.contains("undp") || text.contains("world bank") || text.contains("imf") -> REPORTS_INDICES

        text.contains("bilateral") || text.contains("mou") || text.contains("summit") ||
            text.contains("g20") || text.contains("brics") || text.contains("un ") ||
            text.contains("united nations") || text.contains("treaty") || text.contains("ambassador") ||
            text.contains("foreign") || text.contains("global") -> INTERNATIONAL

        text.contains("state") || text.contains("uttar pradesh") || text.contains("maharashtra") ||
            text.contains("tamil nadu") || text.contains("kerala") || text.contains("bihar") ||
            text.contains("karnataka") || text.contains("delhi") || text.contains("ladakh") ||
            text.contains("assam") || text.contains("gujarat") || text.contains("rajasthan") -> STATE_NEWS

        else -> NATIONAL
      }
    }
  }
}

data class LiveCurrentAffairsItem(
  val id: String,
  val title: String,
  val description: String,
  val source: String,
  val pubDate: String,
  val pubDateMillis: Long,
  val category: CurrentAffairsCategory,
  val articleUrl: String,
  val isCached: Boolean = false,
  val feedSourceUrl: String = ""
) {
  val headline: String get() = title
  val summary: String get() = description
  val publishedTimestamp: Long get() = pubDateMillis
  val formattedDate: String get() = pubDate
}

data class FeedStatus(
  val feedName: String,
  val feedUrl: String,
  val isOnline: Boolean,
  val httpStatusCode: Int,
  val itemCount: Int,
  val notes: String
) {
  val sourceName: String get() = feedName
  val isAccessible: Boolean get() = isOnline
}

data class LiveCurrentAffairsState(
  val items: List<LiveCurrentAffairsItem> = emptyList(),
  val isLoading: Boolean = false,
  val errorMessage: String? = null,
  val lastRefreshedTimeMillis: Long = 0L,
  val lastRefreshedLabel: String = "Never",
  val feedStatuses: List<FeedStatus> = emptyList(),
  val selectedCategory: CurrentAffairsCategory = CurrentAffairsCategory.ALL,
  val searchQuery: String = "",
  val isOfflineFallback: Boolean = false
) {
  val articles: List<LiveCurrentAffairsItem> get() = items
  val isOnline: Boolean get() = !isOfflineFallback
  val lastSuccessfulRefreshLabel: String get() = lastRefreshedLabel
}
