package com.example;

/**
 * ExamService alias in com.example
 */
public class ExamService extends com.example.data.ai.ExamService {
}
