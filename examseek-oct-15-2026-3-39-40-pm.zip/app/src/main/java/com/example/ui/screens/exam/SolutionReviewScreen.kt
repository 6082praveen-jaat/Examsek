package com.example.ui.screens.exam

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.TestQuestion
import com.example.ui.components.VerifiedBadge
import com.example.ui.viewmodel.ExamViewModel
import com.example.ui.viewmodel.MainViewModel

enum class SolutionFilter {
  ALL, CORRECT, INCORRECT, UNATTEMPTED
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SolutionReviewScreen(
  examViewModel: ExamViewModel,
  mainViewModel: MainViewModel,
  onNavigateToAiSolver: (TestQuestion) -> Unit,
  onBack: () -> Unit
) {
  val testResult by examViewModel.testResult.collectAsState()
  val bookmarkedIds by mainViewModel.bookmarks.collectAsState()

  var selectedFilter by remember { mutableStateOf(SolutionFilter.ALL) }

  if (testResult == null) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Text("No solution details found.")
    }
    return
  }

  val res = testResult!!
  val questions = res.questions
  val answers = res.userAnswers

  val filteredQuestions = questions.filter { q ->
    val userChoice = answers[q.id]
    when (selectedFilter) {
      SolutionFilter.ALL -> true
      SolutionFilter.CORRECT -> userChoice == q.correctOptionIndex
      SolutionFilter.INCORRECT -> userChoice != null && userChoice != q.correctOptionIndex
      SolutionFilter.UNATTEMPTED -> userChoice == null
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text("Solutions & Explanations", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(
              "${res.testTitle} • ${filteredQuestions.size} Questions",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface
        )
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .testTag("solution_review_screen")
    ) {
      // Filter Chips Row
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp)
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        FilterChip(
          selected = selectedFilter == SolutionFilter.ALL,
          onClick = { selectedFilter = SolutionFilter.ALL },
          label = { Text("All (${questions.size})") }
        )
        FilterChip(
          selected = selectedFilter == SolutionFilter.CORRECT,
          onClick = { selectedFilter = SolutionFilter.CORRECT },
          label = { Text("Correct (${res.correctAnswersCount})") }
        )
        FilterChip(
          selected = selectedFilter == SolutionFilter.INCORRECT,
          onClick = { selectedFilter = SolutionFilter.INCORRECT },
          label = { Text("Incorrect (${res.incorrectAnswersCount})") }
        )
        FilterChip(
          selected = selectedFilter == SolutionFilter.UNATTEMPTED,
          onClick = { selectedFilter = SolutionFilter.UNATTEMPTED },
          label = { Text("Skipped (${res.unattemptedCount})") }
        )
      }

      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        itemsIndexed(filteredQuestions, key = { _, item -> item.id }) { index, question ->
          val userChoice = answers[question.id]
          val isUserCorrect = userChoice == question.correctOptionIndex
          val isUnattempted = userChoice == null
          val isSaved = bookmarkedIds.any { it.questionId == question.id }

          SolutionItemCard(
            questionNumber = index + 1,
            question = question,
            userChoice = userChoice,
            isUserCorrect = isUserCorrect,
            isUnattempted = isUnattempted,
            isBookmarked = isSaved,
            onToggleBookmark = { mainViewModel.toggleBookmark(question.id) },
            onAskAi = { onNavigateToAiSolver(question) }
          )
        }
        item {
          Spacer(modifier = Modifier.height(24.dp))
        }
      }
    }
  }
}

@Composable
private fun SolutionItemCard(
  questionNumber: Int,
  question: TestQuestion,
  userChoice: Int?,
  isUserCorrect: Boolean,
  isUnattempted: Boolean,
  isBookmarked: Boolean,
  onToggleBookmark: () -> Unit,
  onAskAi: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("solution_card_${question.id}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      // Top status row with subject & source
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          val (badgeBg, badgeText, statusIcon) = when {
            isUserCorrect -> Triple(Color(0xFFDCFCE7), Color(0xFF15803D), Icons.Default.CheckCircle)
            isUnattempted -> Triple(Color(0xFFF1F5F9), Color(0xFF475569), Icons.Default.HelpOutline)
            else -> Triple(Color(0xFFFEE2E2), Color(0xFFB91C1C), Icons.Default.Close)
          }

          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(badgeBg)
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Icon(imageVector = statusIcon, contentDescription = null, tint = badgeText, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = when {
                isUserCorrect -> "CORRECT (+2.0)"
                isUnattempted -> "NOT ATTEMPTED"
                else -> "INCORRECT (-0.5)"
              },
              color = badgeText,
              fontWeight = FontWeight.Bold,
              fontSize = 10.sp
            )
          }

          Spacer(modifier = Modifier.width(8.dp))

          Text(
            text = "${question.subject} • ${question.topic}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          VerifiedBadge(isVerified = question.isVerified)

          IconButton(onClick = onToggleBookmark) {
            Icon(
              imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
              contentDescription = "Bookmark",
              tint = if (isBookmarked) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Question text & source label
      Text(
        text = "Q$questionNumber. ${question.questionText}",
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.SemiBold,
        lineHeight = 22.sp
      )

      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "Source: ${question.source} (${question.year})",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary,
        fontSize = 11.sp
      )

      Spacer(modifier = Modifier.height(12.dp))

      // Options
      val labels = listOf("A", "B", "C", "D")
      question.options.forEachIndexed { optIdx, optText ->
        val isThisCorrect = optIdx == question.correctOptionIndex
        val isThisUserChoice = optIdx == userChoice

        val (optBg, optBorder, optTextColor) = when {
          isThisCorrect -> Triple(Color(0xFFDCFCE7), Color(0xFF22C55E), Color(0xFF15803D))
          isThisUserChoice -> Triple(Color(0xFFFEE2E2), Color(0xFFEF4444), Color(0xFFB91C1C))
          else -> Triple(MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), MaterialTheme.colorScheme.onSurface)
        }

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(optBg)
            .border(1.dp, optBorder, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "${labels[optIdx]}.",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              color = optTextColor
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = optText,
              style = MaterialTheme.typography.bodySmall,
              color = optTextColor,
              modifier = Modifier.weight(1f)
            )
            if (isThisCorrect) {
              Text("✓ Correct Answer", color = Color(0xFF15803D), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            } else if (isThisUserChoice) {
              Text("✗ Your Choice", color = Color(0xFFB91C1C), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Detailed Explanation Section
      Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Lightbulb,
                contentDescription = null,
                tint = Color(0xFF16A34A),
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Detailed Academic Explanation",
                color = Color(0xFF15803D),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }

            OutlinedButton(
              onClick = onAskAi,
              shape = RoundedCornerShape(6.dp),
              modifier = Modifier.height(30.dp),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
              Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(12.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Ask AI Guru", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = question.explanation,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF1E293B),
            lineHeight = 20.sp
          )
        }
      }
    }
  }
}
