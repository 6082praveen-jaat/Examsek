package com.example.ui.screens.exam

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ExamCategory
import com.example.domain.model.ExamDetail
import com.example.domain.model.ExamRegistry
import com.example.domain.model.TestItem
import com.example.domain.model.TestQuestion
import com.example.ui.components.SourceLabelBadge
import com.example.ui.components.VerifiedBadge
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ExamSelectionGeneratorScreen(
  viewModel: MainViewModel,
  onStartCustomMock: (TestItem, List<TestQuestion>) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val selectedExam by viewModel.selectedExamDetail.collectAsState()
  val selectedStage by viewModel.selectedStage.collectAsState()
  val selectedSubject by viewModel.selectedSubject.collectAsState()
  val selectedTopic by viewModel.selectedTopic.collectAsState()
  val selectedDifficulty by viewModel.selectedDifficulty.collectAsState()
  val selectedLanguage by viewModel.selectedLanguage.collectAsState()

  val isGenerating by viewModel.isGenerating.collectAsState()
  val genMessage by viewModel.generationMessage.collectAsState()
  val genError by viewModel.generationError.collectAsState()
  val dailyGenerations by viewModel.dailyGenerationCount.collectAsState()

  val bankQuestions by viewModel.examBankQuestions.collectAsState()

  var searchQuery by remember { mutableStateOf("") }
  var showExamPicker by remember { mutableStateOf(false) }
  var activeCategoryFilter by remember { mutableStateOf<ExamCategory?>(null) }

  val filteredExams = ExamRegistry.allExams.filter { exam ->
    (activeCategoryFilter == null || exam.category == activeCategoryFilter) &&
      (searchQuery.isBlank() || exam.name.contains(searchQuery, ignoreCase = true) || exam.category.displayName.contains(searchQuery, ignoreCase = true))
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Exam Practice Hub & Generator", fontWeight = FontWeight.Bold, fontSize = 17.sp)
          }
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        }
      )
    }
  ) { innerPadding ->
    LazyColumn(
      modifier = modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(MaterialTheme.colorScheme.background)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // 1. Current Exam Card & Picker Toggle
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth().testTag("selected_exam_header_card")
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "TARGET EXAM PROFILE",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.primary,
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = selectedExam.name,
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.ExtraBold
                )
                Text(
                  text = "${selectedExam.category.displayName} • ${selectedExam.syllabusOverview}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 2
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              OutlinedButton(
                onClick = { showExamPicker = !showExamPicker },
                modifier = Modifier.testTag("change_exam_btn")
              ) {
                Text(if (showExamPicker) "Close" else "Change")
              }
            }

            // Marking Scheme Tag
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
              VerifiedBadge(isVerified = selectedExam.verifiedMarkingScheme)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Marks: +${selectedExam.defaultMarksPerQuestion} | Neg: -${selectedExam.defaultNegativeMarking}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
              )
            }
          }
        }
      }

      // 2. Exam Picker Dropdown/Search when opened
      if (showExamPicker) {
        item {
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth().testTag("exam_picker_container")
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text("Select Competitive Exam", fontWeight = FontWeight.Bold, fontSize = 14.sp)
              Spacer(modifier = Modifier.height(8.dp))

              OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search SSC CGL, RRB NTPC, UPSC, Police, CTET...") },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                  if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                      Icon(imageVector = Icons.Default.Close, contentDescription = "Clear")
                    }
                  }
                },
                modifier = Modifier.fillMaxWidth().testTag("search_exam_input"),
                singleLine = true
              )

              Spacer(modifier = Modifier.height(8.dp))

              // Category filter chips
              FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                FilterChip(
                  selected = activeCategoryFilter == null,
                  onClick = { activeCategoryFilter = null },
                  label = { Text("All (${ExamRegistry.allExams.size})", fontSize = 11.sp) }
                )
                ExamCategory.entries.forEach { cat ->
                  val count = ExamRegistry.allExams.count { it.category == cat }
                  if (count > 0) {
                    FilterChip(
                      selected = activeCategoryFilter == cat,
                      onClick = { activeCategoryFilter = if (activeCategoryFilter == cat) null else cat },
                      label = { Text("${cat.displayName} ($count)", fontSize = 11.sp) }
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              // List of selectable exams
              Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                filteredExams.forEach { exam ->
                  val isCurrent = exam.id == selectedExam.id
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isCurrent) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                      .fillMaxWidth()
                      .clickable {
                        viewModel.selectExam(exam)
                        showExamPicker = false
                      }
                      .testTag("exam_item_${exam.id}")
                  ) {
                    Row(
                      modifier = Modifier.padding(10.dp),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Column {
                        Text(exam.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("${exam.category.displayName} • ${exam.stages.joinToString(", ")}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                      }
                      if (isCurrent) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = "Selected", tint = MaterialTheme.colorScheme.primary)
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }

      // 3. Stage, Subject, Topic, Difficulty & Language Configurations
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          modifier = Modifier.fillMaxWidth().testTag("exam_config_card")
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text("Syllabus & Generator Filters", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(10.dp))

            // Stage selection
            Text("Stage / Tier:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              modifier = Modifier.padding(vertical = 4.dp)
            ) {
              selectedExam.stages.forEach { stage ->
                FilterChip(
                  selected = selectedStage == stage,
                  onClick = { viewModel.setStage(stage) },
                  label = { Text(stage, fontSize = 11.sp) }
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Subject selection
            Text("Subject:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              modifier = Modifier.padding(vertical = 4.dp)
            ) {
              FilterChip(
                selected = selectedSubject == "All",
                onClick = { viewModel.setSubject("All") },
                label = { Text("All Subjects", fontSize = 11.sp) }
              )
              selectedExam.subjects.forEach { subj ->
                FilterChip(
                  selected = selectedSubject == subj,
                  onClick = { viewModel.setSubject(subj) },
                  label = { Text(subj, fontSize = 11.sp) }
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Topic selection (if subject selected)
            val availableTopics = if (selectedSubject == "All") {
              selectedExam.topicsBySubject.values.flatten().distinct().take(10)
            } else {
              selectedExam.topicsBySubject[selectedSubject] ?: emptyList()
            }

            if (availableTopics.isNotEmpty()) {
              Text("Topic ($selectedSubject):", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
              FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(vertical = 4.dp)
              ) {
                FilterChip(
                  selected = selectedTopic == "All",
                  onClick = { viewModel.setTopic("All") },
                  label = { Text("All Topics", fontSize = 11.sp) }
                )
                availableTopics.forEach { topic ->
                  FilterChip(
                    selected = selectedTopic == topic,
                    onClick = { viewModel.setTopic(topic) },
                    label = { Text(topic, fontSize = 11.sp) }
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Difficulty & Language Row
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Column(modifier = Modifier.weight(1f)) {
                Text("Difficulty:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  listOf("EASY", "MEDIUM", "HARD").forEach { diff ->
                    FilterChip(
                      selected = selectedDifficulty == diff,
                      onClick = { viewModel.setDifficulty(diff) },
                      label = { Text(diff, fontSize = 10.sp) }
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.width(8.dp))

              Column(modifier = Modifier.weight(1f)) {
                Text("Language:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  listOf("ENGLISH", "HINDI").forEach { lang ->
                    FilterChip(
                      selected = selectedLanguage == lang,
                      onClick = { viewModel.setLanguage(lang) },
                      label = { Text(if (lang == "HINDI") "हिंदी" else "English", fontSize = 10.sp) }
                    )
                  }
                }
              }
            }
          }
        }
      }

      // 4. Generator Action & Quota Controls
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
          modifier = Modifier.fillMaxWidth().testTag("generator_action_card")
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("AI Question Generator", fontWeight = FontWeight.Bold, fontSize = 14.sp)
              }
              Text(
                text = "Batches: $dailyGenerations / ${viewModel.maxDailyGenerations}",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "Generate batches of 10 or 20 fresh MCQs mapped to ${selectedExam.name}'s official syllabus. Questions are deduplicated and saved persistently.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (genMessage != null) {
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = genMessage ?: "",
                fontSize = 12.sp,
                color = Color(0xFF15803D),
                fontWeight = FontWeight.Medium
              )
            }

            if (genError != null) {
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = genError ?: "",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.error,
                fontWeight = FontWeight.Medium
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Button(
                onClick = { viewModel.generateQuestions(batchSize = 10) },
                enabled = !isGenerating,
                modifier = Modifier.weight(1f).testTag("generate_batch_10_btn")
              ) {
                if (isGenerating) {
                  CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Generating...", fontSize = 12.sp)
                } else {
                  Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Generate 10", fontSize = 12.sp)
                }
              }

              Button(
                onClick = { viewModel.generateQuestions(batchSize = 20) },
                enabled = !isGenerating,
                modifier = Modifier.weight(1f).testTag("generate_batch_20_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
              ) {
                Text("Generate 20", fontSize = 12.sp)
              }
            }

            if (genError != null) {
              Spacer(modifier = Modifier.height(6.dp))
              OutlinedButton(
                onClick = { viewModel.generateQuestions(batchSize = 10) },
                modifier = Modifier.fillMaxWidth().testTag("retry_generation_btn")
              ) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Retry Failed Generation")
              }
            }
          }
        }
      }

      // 5. Test Launcher Bar
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          modifier = Modifier.fillMaxWidth().testTag("mock_test_launcher_card")
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Ready to Test Yourself?",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
              )
              Text(
                text = "${bankQuestions.size} saved questions available in ${selectedExam.name} bank.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
              onClick = {
                viewModel.createMockFromCurrentSelection(
                  questionCount = if (bankQuestions.size >= 10) 10 else maxOf(1, bankQuestions.size),
                  durationMinutes = 15,
                  onReady = { testItem, questions ->
                    onStartCustomMock(testItem, questions)
                  }
                )
              },
              modifier = Modifier.testTag("start_exam_mock_btn")
            ) {
              Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Start CBT Mock")
            }
          }
        }
      }

      // 6. Question Bank Header with Real Count
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Saved Questions in Bank (${bankQuestions.size})",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "No fake counts",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      // 7. Question List Cards
      if (bankQuestions.isEmpty()) {
        item {
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
          ) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(imageVector = Icons.Default.FilterList, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
              Spacer(modifier = Modifier.height(8.dp))
              Text("No questions found for this topic/filter yet.", fontWeight = FontWeight.Bold, fontSize = 14.sp)
              Text("Click 'Generate 10' or 'Generate 20' above to create a fresh batch mapped to ${selectedExam.name}.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      } else {
        items(bankQuestions, key = { it.id }) { q ->
          BankQuestionItemCard(question = q)
        }
      }

      item {
        Spacer(modifier = Modifier.height(60.dp))
      }
    }
  }
}

@Composable
private fun BankQuestionItemCard(question: TestQuestion) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "${question.subject} • ${question.topic}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.primary,
          fontWeight = FontWeight.SemiBold
        )
        SourceLabelBadge(sourceLabel = question.sourceLabel)
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = question.questionText,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.Medium
      )

      if (question.hindiQuestionText.isNotBlank() && question.hindiQuestionText != question.questionText) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = question.hindiQuestionText,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Options
      val labels = listOf("A", "B", "C", "D")
      question.options.forEachIndexed { idx, opt ->
        val isCorrect = idx == question.correctOptionIndex
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (isCorrect) Color(0xFFDCFCE7) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            .padding(horizontal = 8.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("${labels[idx]}. ", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (isCorrect) Color(0xFF15803D) else MaterialTheme.colorScheme.onSurface)
          Text(opt, fontSize = 12.sp, color = if (isCorrect) Color(0xFF15803D) else MaterialTheme.colorScheme.onSurface)
          if (isCorrect) {
            Spacer(modifier = Modifier.weight(1f))
            Text("Correct", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF15803D))
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Explanation
      Text(
        text = "Explanation: ${question.explanation}",
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
      )

      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "Source: ${question.source} (${question.year})",
        fontSize = 10.sp,
        color = Color(0xFF94A3B8)
      )
    }
  }
}
