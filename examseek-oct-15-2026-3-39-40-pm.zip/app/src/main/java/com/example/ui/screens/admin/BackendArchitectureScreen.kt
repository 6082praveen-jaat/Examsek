package com.example.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Api
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackendArchitectureScreen(
  onBack: () -> Unit
) {
  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Backend & Web Architecture Plan", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        }
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
        .padding(horizontal = 16.dp)
        .verticalScroll(rememberScrollState())
        .testTag("backend_architecture_screen")
    ) {
      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = "ExamSeek Production Cloud Specification",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.ExtraBold
      )
      Text(
        text = "Blueprint for multi-tenant web & mobile scale with PostgreSQL and Next.js",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(16.dp))

      // Section 1: Cloud Architecture Overview
      ArchitectureSectionCard(
        title = "1. Production Cloud Stack",
        icon = Icons.Default.Cloud,
        content = """
• Database: Managed PostgreSQL (AWS RDS / GCP Cloud SQL) with read replicas for test queries.
• Caching & Leaderboard: Redis cluster for sub-millisecond All-India rank calculation.
• API Backend: Go / Kotlin Ktor microservices or Node.js NestJS REST + GraphQL gateway.
• Web Frontend: Next.js (React 19) server-rendered web portal sharing identical TypeScript DTOs.
• Media / Diagrams: AWS S3 / Cloud Storage CDN with signed URLs for question figures.
• Mobile App: Kotlin Jetpack Compose client (Offline Room cache + Cloud synchronization).
        """.trimIndent()
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Section 2: PostgreSQL Relational Schema
      ArchitectureSectionCard(
        title = "2. PostgreSQL Relational Schema",
        icon = Icons.Default.Storage,
        content = """
-- Core Tables
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(120) NOT NULL,
    target_exam VARCHAR(50) DEFAULT 'SSC CGL',
    role VARCHAR(20) DEFAULT 'STUDENT', -- 'STUDENT', 'INSTRUCTOR', 'ADMIN'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE tests (
    id VARCHAR(64) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL, -- 'SSC', 'RAILWAY', 'BANKING', etc.
    test_type VARCHAR(50) NOT NULL, -- 'FULL_MOCK', 'DAILY_QUIZ', 'PRACTICE'
    duration_minutes INT NOT NULL,
    total_marks NUMERIC(5,2) NOT NULL,
    marks_per_question NUMERIC(4,2) DEFAULT 2.0,
    negative_rate NUMERIC(4,2) DEFAULT 0.5,
    is_verified BOOLEAN DEFAULT TRUE,
    created_by UUID REFERENCES users(id)
);

CREATE TABLE questions (
    id VARCHAR(64) PRIMARY KEY,
    test_id VARCHAR(64) REFERENCES tests(id) ON DELETE CASCADE,
    subject VARCHAR(100) NOT NULL,
    statement TEXT NOT NULL,
    option_a TEXT NOT NULL,
    option_b TEXT NOT NULL,
    option_c TEXT NOT NULL,
    option_d TEXT NOT NULL,
    correct_option INT NOT NULL CHECK (correct_option BETWEEN 0 AND 3),
    explanation TEXT NOT NULL,
    is_verified BOOLEAN DEFAULT TRUE
);

CREATE TABLE test_attempts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    test_id VARCHAR(64) REFERENCES tests(id),
    score NUMERIC(5,2) NOT NULL,
    accuracy NUMERIC(5,2) NOT NULL,
    correct_count INT NOT NULL,
    incorrect_count INT NOT NULL,
    unattempted_count INT NOT NULL,
    time_spent_seconds INT NOT NULL,
    attempted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
        """.trimIndent(),
        isCode = true
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Section 3: REST API Specifications
      ArchitectureSectionCard(
        title = "3. Core REST API Endpoints",
        icon = Icons.Default.Api,
        content = """
AUTH & USERS:
POST   /api/v1/auth/register       -> Create student account with JWT
POST   /api/v1/auth/login          -> Returns accessToken (15m) & refreshToken (7d)
GET    /api/v1/users/me            -> Fetch current profile & stats

EXAM & QUESTION ENGINE:
GET    /api/v1/tests?category=SSC  -> Paginated list of tests with verified badges
GET    /api/v1/tests/{id}/start    -> Start session with server-signed start timestamp
POST   /api/v1/tests/{id}/submit   -> Submit responses & receive real-time percentile
GET    /api/v1/tests/{id}/solution -> Full post-exam step-by-step explanations

STUDENT REVISION:
GET    /api/v1/bookmarks           -> List user's saved high-yield questions
POST   /api/v1/bookmarks/toggle    -> Save / unsave question
GET    /api/v1/analytics/history   -> User's historical scorecard & trends

ADMIN & CONTENT STUDIO:
POST   /api/v1/admin/tests         -> Create verified or demo exam series (Role: ADMIN)
POST   /api/v1/admin/questions     -> Add MCQ items with explanation to test bank
PATCH  /api/v1/admin/tests/{id}    -> Toggle Verified Exam Status
        """.trimIndent(),
        isCode = true
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Section 4: Security & Website Compatibility
      ArchitectureSectionCard(
        title = "4. Security & Multi-Platform Web Parity",
        icon = Icons.Default.Security,
        content = """
• Anti-Tampering Engine:
  - Submissions enforce server-side timestamp verification to eliminate client clock manipulation.
  - Test attempts calculate marks on the server using cryptographic question IDs.

• Future Website Parity (Next.js):
  - Shared TypeScript types for Tests, Questions, and UserAttempts ensure 100% parity between mobile and web.
  - Server-Side Rendering (SSR) in Next.js enables SEO optimization for previous year question papers.
  - Progressive Web App (PWA) support enables desktop computer-based test (CBT) practice.
        """.trimIndent()
      )

      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}

@Composable
private fun ArchitectureSectionCard(
  title: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  content: String,
  isCode: Boolean = false
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
        ) {
          Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = title,
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (isCode) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0F172A))
            .padding(12.dp)
        ) {
          Text(
            text = content,
            color = Color(0xFFE2E8F0),
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            lineHeight = 17.sp
          )
        }
      } else {
        Text(
          text = content,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurface,
          lineHeight = 20.sp
        )
      }
    }
  }
}
