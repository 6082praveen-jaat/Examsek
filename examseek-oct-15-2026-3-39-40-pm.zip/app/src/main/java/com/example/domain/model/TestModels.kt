package com.example.domain.model

enum class Difficulty {
  EASY, MEDIUM, HARD
}

enum class QuestionStatus {
  NOT_VISITED,
  NOT_ANSWERED,
  ANSWERED,
  MARKED_FOR_REVIEW,
  ANSWERED_AND_MARKED_FOR_REVIEW
}

data class TestQuestion(
  val id: String,
  val testId: String,
  val subject: String,
  val topic: String = "General",
  val questionText: String,
  val hindiQuestionText: String = "",
  val options: List<String>,
  val hindiOptions: List<String> = emptyList(),
  val correctOptionIndex: Int,
  val explanation: String,
  val hindiExplanation: String = "",
  val difficulty: Difficulty = Difficulty.MEDIUM,
  val source: String = "ExamSeek Academic Team",
  val year: String = "2024",
  val isVerified: Boolean = true,
  val sourceLabel: String = "OFFICIAL_VERIFIED_PYQ", // "OFFICIAL_VERIFIED_PYQ", "AI_GENERATED_PRACTICE", "AI_GENERATED", "NEEDS_REVIEW"
  val contentHash: String = "",
  val targetExam: String = "SSC CGL",
  val stage: String = "Tier-1"
) {
  val correctAnswer: String
    get() = if (correctOptionIndex in 0..3) listOf("A", "B", "C", "D")[correctOptionIndex] else "A"
}

data class TestItem(
  val id: String,
  val title: String,
  val category: ExamCategory,
  val type: TestType,
  val durationMinutes: Int,
  val totalQuestions: Int,
  val totalMarks: Float,
  val marksPerQuestion: Float = 2.0f,
  val negativeMarkingRate: Float = 0.5f, // Marks deducted per wrong answer
  val isNegativeMarkingEnabled: Boolean = true,
  val isVerified: Boolean = true, // Verified Exam Content vs Demo Content
  val subject: String = "All Subjects",
  val description: String = "",
  val tier: SubscriptionTier = SubscriptionTier.FREE,
  val attemptsCount: Int = 1240
)

data class UserAnswer(
  val questionId: String,
  val selectedOption: Int?, // 0, 1, 2, 3 or null if unattempted
  val isMarkedForReview: Boolean = false,
  val timeSpentSeconds: Int = 0
)

data class TestResult(
  val attemptId: String,
  val testId: String,
  val testTitle: String,
  val category: ExamCategory,
  val totalQuestions: Int,
  val correctAnswersCount: Int,
  val incorrectAnswersCount: Int,
  val unattemptedCount: Int,
  val marksObtained: Float,
  val totalMarks: Float,
  val accuracyPercentage: Float,
  val timeSpentSeconds: Int,
  val totalTimeSeconds: Int,
  val negativeMarkingApplied: Boolean,
  val negativeMarksDeducted: Float,
  val percentileEstimate: Float,
  val dateTimestamp: Long,
  val questions: List<TestQuestion>,
  val userAnswers: Map<String, Int?> // questionId -> selectedOption
)

data class StudyMaterialItem(
  val id: String,
  val title: String,
  val category: String, // "CURRENT_AFFAIRS", "FORMULA_SHEET", "REVISION_NOTE", "FLASHCARD"
  val subject: String,
  val dateLabel: String,
  val content: String,
  val source: String,
  val tier: SubscriptionTier = SubscriptionTier.FREE
)

data class WrongAnswerItem(
  val id: String,
  val question: TestQuestion,
  val userWrongOption: Int,
  val recordedAt: Long,
  val isResolved: Boolean = false
)

data class SubscriptionPlan(
  val id: String,
  val tier: SubscriptionTier,
  val durationTitle: String,
  val priceInRupees: Int,
  val originalPriceInRupees: Int,
  val billingPeriod: String,
  val discountLabel: String,
  val features: List<String>
)
