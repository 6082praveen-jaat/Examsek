package com.example

import com.example.data.currentaffairs.LiveCurrentAffairsService
import com.example.data.formula.EnglishTopicsPart1
import com.example.data.formula.EnglishTopicsPart2
import com.example.data.formula.MathTopicsPart1
import com.example.data.formula.MathTopicsPart2
import com.example.data.formula.MathTopicsPart3
import com.example.data.formula.ReasoningTopicsPart1
import com.example.data.formula.ReasoningTopicsPart2
import com.example.domain.formula.FormulaSubject
import com.example.domain.model.CurrentAffairsCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CurrentAffairsAndFormulaTest {

  @Test
  fun testFormulaTopicCounts() {
    val mathTopics = MathTopicsPart1.topics + MathTopicsPart2.topics + MathTopicsPart3.topics
    val reasoningTopics = ReasoningTopicsPart1.topics + ReasoningTopicsPart2.topics
    val englishTopics = EnglishTopicsPart1.topics + EnglishTopicsPart2.topics

    println("Mathematics Topics: ${mathTopics.size}")
    println("Reasoning Topics: ${reasoningTopics.size}")
    println("English Topics: ${englishTopics.size}")

    assertEquals(32, mathTopics.size)
    assertEquals(21, reasoningTopics.size)
    assertEquals(27, englishTopics.size)

    val allTopics = mathTopics + reasoningTopics + englishTopics
    assertEquals(80, allTopics.size)
  }

  @Test
  fun testFormulaTopicsStructureAndQuestionIntegrity() {
    val allTopics = MathTopicsPart1.topics +
      MathTopicsPart2.topics +
      MathTopicsPart3.topics +
      ReasoningTopicsPart1.topics +
      ReasoningTopicsPart2.topics +
      EnglishTopicsPart1.topics +
      EnglishTopicsPart2.topics

    val uniqueIds = mutableSetOf<String>()

    for (topic in allTopics) {
      // 1. Verify unique IDs
      assertTrue("Duplicate topic id: ${topic.id}", uniqueIds.add(topic.id))

      // 2. Non-empty essential text
      assertTrue("Topic title blank: ${topic.id}", topic.title.isNotBlank())
      assertTrue("Chapter blank: ${topic.id}", topic.chapter.isNotBlank())
      assertTrue("Core formula blank: ${topic.id}", topic.coreFormula.isNotBlank())
      assertTrue("Summary blank: ${topic.id}", topic.summary.isNotBlank())

      // 3. At least 3 solved examples
      assertTrue(
        "Topic ${topic.id} has ${topic.solvedExamples.size} examples, expected at least 3",
        topic.solvedExamples.size >= 3
      )
      for (example in topic.solvedExamples) {
        assertTrue("Problem blank in ${topic.id}", example.problem.isNotBlank())
        assertTrue("Step-by-step blank in ${topic.id}", example.stepByStepSolution.isNotEmpty())
        assertTrue("Final answer blank in ${topic.id}", example.finalAnswer.isNotBlank())
      }

      // 4. Exactly 10 practice MCQs
      assertEquals(
        "Topic ${topic.id} must have exactly 10 MCQs",
        10,
        topic.practiceMcqs.size
      )

      for ((idx, mcq) in topic.practiceMcqs.withIndex()) {
        assertTrue("MCQ $idx in ${topic.id} question text blank", mcq.question.isNotBlank())
        assertEquals("MCQ $idx in ${topic.id} must have 4 options", 4, mcq.options.size)
        assertTrue(
          "MCQ $idx in ${topic.id} correctOptionIndex ${mcq.correctOptionIndex} out of bounds",
          mcq.correctOptionIndex in 0..3
        )
        assertTrue(
          "MCQ $idx in ${topic.id} explanation is blank",
          mcq.explanation.isNotBlank()
        )
      }
    }
  }

  @Test
  fun testCurrentAffairsCategoryClassification() {
    assertEquals(
      CurrentAffairsCategory.BANKING,
      CurrentAffairsCategory.classify("RBI Monetary Policy Committee leaves repo rate unchanged at 6.5%")
    )
    assertEquals(
      CurrentAffairsCategory.ECONOMY,
      CurrentAffairsCategory.classify("India's GDP growth surges to 7.8% led by manufacturing exports")
    )
    assertEquals(
      CurrentAffairsCategory.SCIENCE,
      CurrentAffairsCategory.classify("ISRO launches advanced meteorological satellite into orbit")
    )
    assertEquals(
      CurrentAffairsCategory.DEFENCE,
      CurrentAffairsCategory.classify("DRDO successfully flight-tests new generation surface-to-air missile")
    )
    assertEquals(
      CurrentAffairsCategory.GOV_SCHEMES,
      CurrentAffairsCategory.classify("Cabinet approves Pradhan Mantri Awas Yojana Urban 2.0 with enhanced subsidy")
    )
    assertEquals(
      CurrentAffairsCategory.SPORTS,
      CurrentAffairsCategory.classify("India clinches gold medal at Asian Shooting Championship")
    )
    assertEquals(
      CurrentAffairsCategory.ENVIRONMENT,
      CurrentAffairsCategory.classify("Ministry of Environment adds three new Ramsar wetland sites in India")
    )
  }

  @Test
  fun testLiveServiceRssParsingAndFallbacks() {
    val service = LiveCurrentAffairsService()
    assertNotNull(service)

    // Test offline cache fallback
    val fallback = service.getOfflineFallbackResult()
    assertTrue("Offline fallback must not be empty", fallback.items.isNotEmpty())
    assertTrue("Offline fallback must have feed statuses", fallback.feedStatuses.isNotEmpty())
    assertTrue("Must be marked as offline cache", fallback.isOfflineCache)

    for (item in fallback.items) {
      assertTrue("Item headline must not be blank", item.headline.isNotBlank())
      assertTrue("Item article URL must not be blank", item.articleUrl.isNotBlank())
      assertTrue("Item source must not be blank", item.source.isNotBlank())
      assertTrue("Item pubDate must not be blank", item.pubDate.isNotBlank())
    }
  }
}
