package com.example.ui.screens.trust

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContactSupport
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrustAndLegalScreen(
  onBack: () -> Unit
) {
  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Trust, Policies & Support", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        }
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
        .padding(horizontal = 16.dp)
        .verticalScroll(rememberScrollState())
        .testTag("trust_and_legal_screen")
    ) {
      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = "Student Trust & Disclaimers",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.ExtraBold
      )
      Text(
        text = "ExamSeek is an independent preparatory platform created to assist students.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(14.dp))

      PolicyCard(
        title = "Official Disclaimer",
        icon = Icons.Default.Info,
        content = """
ExamSeek is not affiliated with, endorsed by, or representing any government body, including the Staff Selection Commission (SSC), Railway Recruitment Boards (RRB), Institute of Banking Personnel Selection (IBPS), or Union Public Service Commission (UPSC).

All tests, sample questions, and practice sets are intended exclusively for academic preparation. ExamSeek does not promise or guarantee government recruitment, selection, or specific exam ranks.
        """.trimIndent()
      )

      Spacer(modifier = Modifier.height(12.dp))

      PolicyCard(
        title = "Privacy Policy & Student Data Protection",
        icon = Icons.Default.Lock,
        content = """
1. Data Storage: Your login details, target exams, test performance, and mistakes are encrypted in a secure local database and server repository.
2. AI Queries: When utilizing the AI Doubt Solver, questions are processed securely without transmitting personal student identities or contact numbers.
3. Third Parties: We do not sell or rent student data to third-party marketing companies.
        """.trimIndent()
      )

      Spacer(modifier = Modifier.height(12.dp))

      PolicyCard(
        title = "Subscription & Refund Policy",
        icon = Icons.Default.Payment,
        content = """
1. Billing: Subscriptions are billed upfront on a monthly or annual basis based on selected plan (Plus or Pro).
2. Cancellation: Students may cancel recurring subscriptions at any time from their account settings. Access continues until the end of the billing cycle.
3. Refunds: We offer a 48-hour full refund policy if a paid subscription experiences severe technical unavailability, subject to review by our support desk.
        """.trimIndent()
      )

      Spacer(modifier = Modifier.height(12.dp))

      PolicyCard(
        title = "Student Help Desk & Contact",
        icon = Icons.Default.ContactSupport,
        content = """
Have questions about test evaluation, billing, or found an error in an answer key?

• Academic Support: support@examseek.com
• Response Time: Within 24-48 business hours
• Operating Hours: Monday to Saturday, 9:00 AM - 6:00 PM IST
        """.trimIndent()
      )

      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}

@Composable
private fun PolicyCard(
  title: String,
  icon: ImageVector,
  content: String
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
      }
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = content,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurface,
        lineHeight = 20.sp
      )
    }
  }
}
