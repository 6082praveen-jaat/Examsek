package com.example.ui.screens.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.AppLanguage
import com.example.domain.model.SubscriptionTier
import com.example.domain.model.TestQuestion
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiDoubtSolverScreen(
  viewModel: MainViewModel,
  onNavigateToSubscription: () -> Unit,
  onBack: () -> Unit
) {
  val currentUser by viewModel.currentUser.collectAsState()
  val allQuestions by viewModel.allQuestions.collectAsState()
  val preselectedQuestion by viewModel.selectedQuestionForAi.collectAsState()
  val aiResponse by viewModel.aiDoubtResponse.collectAsState()
  val isAiSolving by viewModel.isAiSolving.collectAsState()
  val aiError by viewModel.aiDoubtError.collectAsState()

  var queryText by remember { mutableStateOf("") }
  var selectedQuestion by remember { mutableStateOf<TestQuestion?>(preselectedQuestion ?: allQuestions.firstOrNull()) }
  var selectedLanguage by remember { mutableStateOf("HINDI") } // Default Hindi/Hinglish

  androidx.compose.runtime.LaunchedEffect(preselectedQuestion) {
    if (preselectedQuestion != null) {
      selectedQuestion = preselectedQuestion
      queryText = "Why is Option ${('A' + preselectedQuestion!!.correctOptionIndex)} correct? Please provide step-by-step reasoning and a short trick for this ${preselectedQuestion!!.subject} question."
    }
  }

  val tier = try { SubscriptionTier.valueOf(currentUser?.subscriptionTier ?: "FREE") } catch (e: Exception) { SubscriptionTier.FREE }
  val usedToday = currentUser?.aiDoubtsUsedToday ?: 0
  val maxLimit = when (tier) {
    SubscriptionTier.FREE -> 3
    SubscriptionTier.PLUS -> 15
    SubscriptionTier.PRO -> 999
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("AI Doubt Guru", fontWeight = FontWeight.Bold, fontSize = 18.sp)
          }
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        }
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
        .padding(horizontal = 16.dp)
        .verticalScroll(rememberScrollState())
        .testTag("ai_doubt_solver_screen")
    ) {
      Spacer(modifier = Modifier.height(10.dp))

      // Quota Status Card
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              contentAlignment = Alignment.Center,
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0xFFFEF3C7))
            ) {
              Icon(imageVector = Icons.Default.Bolt, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "${tier.displayName} Daily Quota",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              )
              Text(
                text = if (tier == SubscriptionTier.PRO) "Unlimited doubts available" else "$usedToday of $maxLimit doubts used today",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          if (tier != SubscriptionTier.PRO) {
            Button(
              onClick = onNavigateToSubscription,
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.height(34.dp)
            ) {
              Text("Upgrade", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Language Toggle
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Explain In Language:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(
            selected = selectedLanguage == "HINDI",
            onClick = { selectedLanguage = "HINDI" },
            label = { Text("हिंदी / Hinglish", fontSize = 12.sp) }
          )
          FilterChip(
            selected = selectedLanguage == "ENGLISH",
            onClick = { selectedLanguage = "ENGLISH" },
            label = { Text("English", fontSize = 12.sp) }
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Sample Problem Selection Chip Row
      Text("Or choose a high-yield question from Question Bank:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
      Spacer(modifier = Modifier.height(6.dp))

      allQuestions.take(3).forEach { q ->
        val isChosen = selectedQuestion?.id == q.id
        Card(
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isChosen) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
          ),
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable {
              selectedQuestion = q
              queryText = "Why is Option ${('A' + q.correctOptionIndex)} correct? Please provide step-by-step reasoning and a short-trick for this ${q.subject} question."
            }
        ) {
          Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Psychology,
              contentDescription = null,
              tint = if (isChosen) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "${q.subject} (${q.topic}): ${q.questionText.take(55)}...",
              fontSize = 11.sp,
              fontWeight = if (isChosen) FontWeight.Bold else FontWeight.Normal,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Custom Doubt Input
      OutlinedTextField(
        value = queryText,
        onValueChange = { queryText = it },
        label = { Text("Ask your doubt or request step-by-step math proof") },
        placeholder = { Text("e.g. Explain how to solve this in under 30 seconds using formula trick...") },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("ai_doubt_query_field"),
        shape = RoundedCornerShape(12.dp),
        maxLines = 4
      )

      Spacer(modifier = Modifier.height(12.dp))

      Button(
        onClick = {
          val targetQ = selectedQuestion ?: allQuestions.firstOrNull() ?: return@Button
          viewModel.askAiDoubt(
            question = targetQ,
            userQuery = queryText,
            language = selectedLanguage
          )
        },
        enabled = !isAiSolving,
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("ask_ai_btn"),
        shape = RoundedCornerShape(12.dp)
      ) {
        if (isAiSolving) {
          CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Generating Step-by-Step Solution...")
        } else {
          Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Solve with AI Doubt Guru", fontWeight = FontWeight.Bold)
        }
      }

      if (aiError != null) {
        Spacer(modifier = Modifier.height(12.dp))
        Card(
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = aiError ?: "",
              fontSize = 12.sp,
              color = Color(0xFFB91C1C)
            )
          }
        }
      }

      if (aiResponse != null) {
        Spacer(modifier = Modifier.height(16.dp))

        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_response_card")
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "AI Guru Step-by-Step Solution",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.primary
              )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
              text = aiResponse ?: "",
              style = MaterialTheme.typography.bodyMedium,
              lineHeight = 22.sp,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(40.dp))
    }
  }
}
