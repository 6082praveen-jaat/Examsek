package com.example.ui.screens.learning

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LinearScale
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.formula.FormulaRepository
import com.example.domain.formula.FormulaSubject
import com.example.domain.formula.FormulaTopic
import com.example.domain.model.CurrentAffairsCategory
import com.example.domain.model.LiveCurrentAffairsItem
import com.example.domain.model.LiveCurrentAffairsState
import com.example.domain.model.StudyMaterialItem
import com.example.domain.model.WrongAnswerItem
import com.example.ui.components.VerifiedBadge
import com.example.ui.viewmodel.MainViewModel

@Composable
fun DailyLearningScreen(
  viewModel: MainViewModel,
  onNavigateToAiSolver: () -> Unit,
  onNavigateToFormulaDetail: (String) -> Unit = {},
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val studyMaterials by viewModel.studyMaterials.collectAsState()
  val wrongAnswers by viewModel.wrongAnswers.collectAsState()
  val liveCurrentAffairsState by viewModel.liveCurrentAffairsState.collectAsState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("daily_learning_screen")
  ) {
    // Top Bar Header
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(MaterialTheme.colorScheme.surface)
        .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "Daily Learning & Vault",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold
          )
          Text(
            text = "Live India news, 80-topic formula library, flashcards & mistake vault",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }

        IconButton(
          onClick = onNavigateToAiSolver,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = "AI Doubt Solver",
            tint = MaterialTheme.colorScheme.primary
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.surface
      ) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text("Live India Affairs", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text("Formula Library", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
        )
        Tab(
          selected = selectedTab == 2,
          onClick = { selectedTab = 2 },
          text = { Text("Mistake Vault", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
        )
        Tab(
          selected = selectedTab == 3,
          onClick = { selectedTab = 3 },
          text = { Text("Flashcards", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
        )
      }
    }

    when (selectedTab) {
      0 -> LiveCurrentAffairsTab(
        state = liveCurrentAffairsState,
        onRefresh = { viewModel.refreshLiveCurrentAffairs(force = true) }
      )
      1 -> TopicWiseFormulaLibraryTab(
        formulaRepository = viewModel.formulaRepository,
        onNavigateToDetail = onNavigateToFormulaDetail
      )
      2 -> WrongAnswerVaultTab(
        wrongAnswers = wrongAnswers,
        onResolve = { viewModel.resolveWrongAnswer(it) },
        onAskAi = onNavigateToAiSolver
      )
      3 -> FlashcardsTab(
        items = studyMaterials.filter { it.category == "FLASHCARD" }
      )
    }
  }
}

// -------------------------------------------------------------
// FEATURE 1: LIVE INDIA CURRENT AFFAIRS TAB
// -------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LiveCurrentAffairsTab(
  state: LiveCurrentAffairsState,
  onRefresh: () -> Unit
) {
  val context = LocalContext.current
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf(CurrentAffairsCategory.ALL) }
  var selectedDateFilter by remember { mutableStateOf("ALL") } // "ALL", "TODAY", "YESTERDAY", "WEEK"
  var showFeedDiagnostics by remember { mutableStateOf(false) }

  val filteredArticles = remember(state.articles, searchQuery, selectedCategory, selectedDateFilter) {
    val q = searchQuery.trim().lowercase()
    val now = System.currentTimeMillis()
    val oneDayMs = 24 * 60 * 60 * 1000L

    state.articles.filter { item ->
      val matchesCategory = selectedCategory == CurrentAffairsCategory.ALL || item.category == selectedCategory
      val matchesQuery = q.isEmpty() ||
        item.headline.lowercase().contains(q) ||
        item.summary.lowercase().contains(q) ||
        item.source.lowercase().contains(q)

      val matchesDate = when (selectedDateFilter) {
        "TODAY" -> (now - item.publishedTimestamp) <= oneDayMs
        "YESTERDAY" -> {
          val diff = now - item.publishedTimestamp
          diff in (oneDayMs + 1)..(2 * oneDayMs)
        }
        "WEEK" -> (now - item.publishedTimestamp) <= (7 * oneDayMs)
        else -> true
      }

      matchesCategory && matchesQuery && matchesDate
    }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp, vertical = 10.dp)
      .testTag("live_current_affairs_tab")
  ) {
    // 1. Status & Live Bar
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .clip(CircleShape)
                  .background(if (state.isOnline) Color(0xFF4CAF50) else Color(0xFFFF9800))
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (state.isOnline) "LIVE OFFICIAL FEEDS" else "OFFLINE CACHE ACTIVE",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = if (state.isOnline) Color(0xFF4CAF50) else Color(0xFFFF9800)
              )
            }

            // Refresh Button
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = onRefresh,
                enabled = !state.isLoading,
                modifier = Modifier
                  .size(32.dp)
                  .testTag("refresh_current_affairs_button")
              ) {
                if (state.isLoading) {
                  CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.primary
                  )
                } else {
                  Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                  )
                }
              }

              IconButton(
                onClick = { showFeedDiagnostics = !showFeedDiagnostics },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Info,
                  contentDescription = "Feed Status",
                  tint = MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.size(18.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(4.dp))

          // Last successful refresh label
          Text(
            text = "Last synced: ${state.lastSuccessfulRefreshLabel} • ${state.articles.size} official releases",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 11.sp
          )

          // Error banner if any
          if (state.errorMessage != null) {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFFEF5350).copy(alpha = 0.15f))
                .padding(horizontal = 8.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.ErrorOutline,
                contentDescription = null,
                tint = Color(0xFFEF5350),
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = state.errorMessage,
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFEF5350),
                fontSize = 11.sp,
                modifier = Modifier.weight(1f)
              )
              Text(
                text = "Retry",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier.clickable { onRefresh() }
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
    }

    // 2. Feed Diagnostics Expandable Card
    if (showFeedDiagnostics) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
          shape = RoundedCornerShape(10.dp)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(
              text = "Official Government Source Feeds & Status",
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(6.dp))

            state.feedStatuses.forEach { f ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(f.sourceName, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                  Text(f.notes, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (f.isAccessible) Color(0xFF2E7D32) else Color(0xFFC62828))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = if (f.isAccessible) "${f.itemCount} items" else "Unavailable",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
              }
            }
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
      }
    }

    // 3. Search and Date Filters
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search news by headline, ministry, or keyword...", fontSize = 12.sp) },
        leadingIcon = {
          Icon(imageVector = Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
        },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(20.dp)) {
              Icon(imageVector = Icons.Default.Close, contentDescription = "Clear")
            }
          }
        },
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("current_affairs_search_input"),
        shape = RoundedCornerShape(10.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = MaterialTheme.colorScheme.surface,
          unfocusedContainerColor = MaterialTheme.colorScheme.surface
        )
      )

      Spacer(modifier = Modifier.height(8.dp))

      // Date Archive Chips
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        listOf(
          "ALL" to "All Dates",
          "TODAY" to "Today",
          "YESTERDAY" to "Yesterday",
          "WEEK" to "This Week"
        ).forEach { (key, label) ->
          val isSelected = selectedDateFilter == key
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(16.dp))
              .background(
                if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
              )
              .border(
                1.dp,
                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                RoundedCornerShape(16.dp)
              )
              .clickable { selectedDateFilter = key }
              .padding(horizontal = 10.dp, vertical = 4.dp)
          ) {
            Text(
              text = label,
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // 14 Category Chips (Horizontal Scroll)
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        items(CurrentAffairsCategory.entries) { cat ->
          val isSelected = selectedCategory == cat
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(
                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
              )
              .clickable { selectedCategory = cat }
              .padding(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Text(
              text = cat.chipLabel,
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
              color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))
    }

    // 4. Articles List
    if (filteredArticles.isEmpty()) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(40.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              imageVector = Icons.Default.Newspaper,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text("No articles match your filter", fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              "Try selecting 'All Dates' or clearing search keyword.",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(filteredArticles, key = { it.id }) { item ->
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            // Header: Category, Source & Date
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(MaterialTheme.colorScheme.primaryContainer)
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = item.category.displayName,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onPrimaryContainer
                )
              }

              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = item.source,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "• ${item.formattedDate}",
                  fontSize = 10.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Headline
            Text(
              text = item.headline,
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              lineHeight = 20.sp
            )

            // Summary
            if (item.summary.isNotBlank()) {
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = item.summary,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis
              )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Footer with clickable official article URL
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "Official Release",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.outline
              )

              if (item.articleUrl.isNotBlank()) {
                Row(
                  modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .clickable {
                      try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(item.articleUrl))
                        context.startActivity(intent)
                      } catch (_: Exception) {}
                    }
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = "Read Official Release",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Icon(
                    imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                    contentDescription = "Open Link",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(13.dp)
                  )
                }
              }
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(80.dp))
    }
  }
}

// -------------------------------------------------------------
// FEATURE 2: TOPIC-WISE FORMULA LIBRARY TAB (80 TOPICS)
// -------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TopicWiseFormulaLibraryTab(
  formulaRepository: FormulaRepository,
  onNavigateToDetail: (String) -> Unit
) {
  var selectedSubject by remember { mutableStateOf<FormulaSubject?>(FormulaSubject.MATHEMATICS) }
  var searchQuery by remember { mutableStateOf("") }
  var onlyBookmarked by remember { mutableStateOf(false) }

  val bookmarkedIds by formulaRepository.bookmarkedTopicIds.collectAsState()
  val completedIds by formulaRepository.completedTopicIds.collectAsState()
  val recentlyViewedIds by formulaRepository.recentlyViewedIds.collectAsState()
  val quizResults by formulaRepository.quizResults.collectAsState()

  // Filter topics
  val filteredTopics = remember(selectedSubject, searchQuery, onlyBookmarked, bookmarkedIds) {
    val base = formulaRepository.searchTopics(searchQuery, selectedSubject)
    if (onlyBookmarked) {
      base.filter { bookmarkedIds.contains(it.id) }
    } else {
      base
    }
  }

  // Group by chapter
  val chaptersMap = remember(filteredTopics) {
    filteredTopics.groupBy { it.chapter }
  }

  // Completion calculation for selected subject
  val subjectStats = remember(selectedSubject, completedIds) {
    if (selectedSubject != null) {
      formulaRepository.getSubjectCompletionStats(selectedSubject!!)
    } else {
      Pair(completedIds.size, formulaRepository.allTopics.size)
    }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp, vertical = 10.dp)
      .testTag("formula_library_tab")
  ) {
    // 1. Header & Progress Bar
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = selectedSubject?.displayName ?: "All 80 Topics",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold
              )
              Text(
                text = "${subjectStats.first} of ${subjectStats.second} topics mastered",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
              )
            }

            val percentage = if (subjectStats.second > 0) {
              (subjectStats.first * 100) / subjectStats.second
            } else 0

            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (percentage >= 50) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primaryContainer)
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "$percentage%",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = if (percentage >= 50) Color.White else MaterialTheme.colorScheme.onPrimaryContainer
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          LinearProgressIndicator(
            progress = {
              if (subjectStats.second > 0) subjectStats.first.toFloat() / subjectStats.second.toFloat() else 0f
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(6.dp)
              .clip(RoundedCornerShape(3.dp)),
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))
    }

    // 2. Subject Filter Tabs & Bookmarks Toggle
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        listOf(
          FormulaSubject.MATHEMATICS to "Maths (32)",
          FormulaSubject.REASONING to "Reasoning (21)",
          FormulaSubject.ENGLISH to "English (27)"
        ).forEach { (sub, label) ->
          val isSelected = selectedSubject == sub
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
              .clickable { selectedSubject = if (isSelected) null else sub }
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = label,
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
              color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Search & Bookmark Filter Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text("Search formulas, rules, topics...", fontSize = 12.sp) },
          leadingIcon = {
            Icon(imageVector = Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
          },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(20.dp)) {
                Icon(imageVector = Icons.Default.Close, contentDescription = "Clear")
              }
            }
          },
          singleLine = true,
          modifier = Modifier
            .weight(1f)
            .testTag("formula_search_input"),
          shape = RoundedCornerShape(10.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface
          )
        )

        IconButton(
          onClick = { onlyBookmarked = !onlyBookmarked },
          modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (onlyBookmarked) Color(0xFFFFB74D) else MaterialTheme.colorScheme.surface)
            .size(48.dp)
        ) {
          Icon(
            imageVector = if (onlyBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
            contentDescription = "Bookmarks Filter",
            tint = if (onlyBookmarked) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))
    }

    // 3. Recently Viewed Carousel if any
    if (recentlyViewedIds.isNotEmpty() && searchQuery.isEmpty()) {
      item {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.History,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Recently Viewed Topics",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            items(recentlyViewedIds.take(6)) { rid ->
              val rTopic = formulaRepository.getTopicById(rid)
              if (rTopic != null) {
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .clickable { onNavigateToDetail(rTopic.id) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = rTopic.title,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.SemiBold,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                      imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                      contentDescription = null,
                      modifier = Modifier.size(12.dp),
                      tint = MaterialTheme.colorScheme.primary
                    )
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
        }
      }
    }

    // 4. Topic Cards Grouped by Chapter
    chaptersMap.forEach { (chapterName, topicsInChapter) ->
      item {
        Text(
          text = chapterName.uppercase(),
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.ExtraBold,
          color = MaterialTheme.colorScheme.primary,
          modifier = Modifier.padding(vertical = 4.dp)
        )
      }

      items(topicsInChapter, key = { it.id }) { topic ->
        val isBookmarked = bookmarkedIds.contains(topic.id)
        val isCompleted = completedIds.contains(topic.id)
        val quizResult = quizResults[topic.id]

        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { onNavigateToDetail(topic.id) }
            .testTag("topic_card_${topic.id}")
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            // Header: Title, Hindi, Bookmark & Completion
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.Top
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = topic.title,
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold
                )
                if (topic.hindiTitle.isNotBlank()) {
                  Text(
                    text = topic.hindiTitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium
                  )
                }
              }

              Row(verticalAlignment = Alignment.CenterVertically) {
                if (isCompleted) {
                  Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Completed",
                    tint = Color(0xFF4CAF50),
                    modifier = Modifier.size(18.dp)
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                }

                IconButton(
                  onClick = { formulaRepository.toggleBookmark(topic.id) },
                  modifier = Modifier.size(28.dp)
                ) {
                  Icon(
                    imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = "Bookmark",
                    tint = if (isBookmarked) Color(0xFFFFB74D) else MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(18.dp)
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Summary
            Text(
              text = topic.summary,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
              fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Formula snippet box
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
                .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
              Text(
                text = topic.coreFormula.lines().firstOrNull() ?: topic.coreFormula,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Footer info: Solved examples, 10 MCQs, Quiz status
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "3 Solved Examples • 10 MCQs",
                  fontSize = 10.sp,
                  color = MaterialTheme.colorScheme.outline
                )

                if (quizResult != null) {
                  Spacer(modifier = Modifier.width(6.dp))
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(4.dp))
                      .background(if (quizResult.score >= 6) Color(0xFF2E7D32) else Color(0xFFE65100))
                      .padding(horizontal = 4.dp, vertical = 1.dp)
                  ) {
                    Text(
                      text = "Score: ${quizResult.score}/10",
                      color = Color.White,
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Bold
                    )
                  }
                }
              }

              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "Open Topic",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(2.dp))
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(12.dp)
                )
              }
            }
          }
        }
      }

      item {
        Spacer(modifier = Modifier.height(8.dp))
      }
    }

    item {
      Spacer(modifier = Modifier.height(80.dp))
    }
  }
}

// -------------------------------------------------------------
// EXISTING TABS PRESERVED: MISTAKE VAULT & FLASHCARDS
// -------------------------------------------------------------

@Composable
private fun WrongAnswerVaultTab(
  wrongAnswers: List<WrongAnswerItem>,
  onResolve: (String) -> Unit,
  onAskAi: () -> Unit
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2))
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.WarningAmber,
            contentDescription = null,
            tint = Color(0xFFDC2626),
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "Wrong-Answer Notebook (${wrongAnswers.size} Unresolved)",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              color = Color(0xFF991B1B)
            )
            Text(
              text = "Mistakes from tests are automatically collected here. Master them so you never repeat errors!",
              fontSize = 11.sp,
              color = Color(0xFF7F1D1D)
            )
          }
        }
      }
      Spacer(modifier = Modifier.height(4.dp))
    }

    if (wrongAnswers.isEmpty()) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(40.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = Color(0xFF10B981),
              modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text("No Pending Mistakes!", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(
              "All wrong answers have been revised and resolved.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(wrongAnswers, key = { it.id }) { wa ->
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "${wa.question.subject} • ${wa.question.topic}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
              )
              VerifiedBadge(isVerified = wa.question.isVerified)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = wa.question.questionText,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold,
              lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFFFEF2F2))
                .padding(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(imageVector = Icons.Default.Close, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "You Marked: Option ${('A' + wa.userWrongOption)} (${wa.question.options.getOrElse(wa.userWrongOption) { "" }})",
                fontSize = 12.sp,
                color = Color(0xFFB91C1C),
                fontWeight = FontWeight.SemiBold
              )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFFF0FDF4))
                .padding(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Correct: Option ${('A' + wa.question.correctOptionIndex)} (${wa.question.options.getOrElse(wa.question.correctOptionIndex) { "" }})",
                fontSize = 12.sp,
                color = Color(0xFF15803D),
                fontWeight = FontWeight.SemiBold
              )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
              text = "Explanation: ${wa.question.explanation}",
              style = MaterialTheme.typography.bodySmall,
              color = Color(0xFF334155),
              lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              OutlinedButton(
                onClick = onAskAi,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(36.dp)
              ) {
                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Ask AI Solver", fontSize = 11.sp)
              }

              Button(
                onClick = { onResolve(wa.id) },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(36.dp)
              ) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Mark Resolved", fontSize = 11.sp)
              }
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(80.dp))
    }
  }
}

@Composable
private fun FlashcardsTab(items: List<StudyMaterialItem>) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = Icons.Default.Style, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Memory Flashcards & Mnemonics",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
      }
      Spacer(modifier = Modifier.height(4.dp))
    }

    items(items, key = { it.id }) { item ->
      var isRevealed by remember { mutableStateOf(false) }

      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { isRevealed = !isRevealed }
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "${item.subject} • ${item.dateLabel}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = if (isRevealed) "Tap to Hide" else "Tap to Flip",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = item.title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )

          AnimatedVisibility(visible = isRevealed) {
            Column(modifier = Modifier.padding(top = 10.dp)) {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color(0xFFEFF6FF))
                  .padding(12.dp)
              ) {
                Text(
                  text = item.content,
                  style = MaterialTheme.typography.bodySmall,
                  lineHeight = 20.sp,
                  color = Color(0xFF1E3A8A)
                )
              }
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(80.dp))
    }
  }
}
