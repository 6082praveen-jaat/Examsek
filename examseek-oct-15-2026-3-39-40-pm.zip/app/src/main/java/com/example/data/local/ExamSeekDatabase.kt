package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.ActiveTestSessionDao
import com.example.data.local.dao.BookmarkDao
import com.example.data.local.dao.QuestionDao
import com.example.data.local.dao.StudyMaterialDao
import com.example.data.local.dao.SubscriptionOrderDao
import com.example.data.local.dao.TestAttemptDao
import com.example.data.local.dao.TestDao
import com.example.data.local.dao.UserDao
import com.example.data.local.dao.WrongAnswerDao
import com.example.data.local.entity.ActiveTestSessionEntity
import com.example.data.local.entity.BookmarkEntity
import com.example.data.local.entity.QuestionEntity
import com.example.data.local.entity.StudyMaterialEntity
import com.example.data.local.entity.SubscriptionOrderEntity
import com.example.data.local.entity.TestAttemptEntity
import com.example.data.local.entity.TestEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WrongAnswerEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [
    UserEntity::class,
    TestEntity::class,
    QuestionEntity::class,
    TestAttemptEntity::class,
    ActiveTestSessionEntity::class,
    WrongAnswerEntity::class,
    StudyMaterialEntity::class,
    SubscriptionOrderEntity::class,
    BookmarkEntity::class
  ],
  version = 3,
  exportSchema = false
)
abstract class ExamSeekDatabase : RoomDatabase() {

  abstract fun userDao(): UserDao
  abstract fun testDao(): TestDao
  abstract fun questionDao(): QuestionDao
  abstract fun testAttemptDao(): TestAttemptDao
  abstract fun activeTestSessionDao(): ActiveTestSessionDao
  abstract fun wrongAnswerDao(): WrongAnswerDao
  abstract fun studyMaterialDao(): StudyMaterialDao
  abstract fun subscriptionOrderDao(): SubscriptionOrderDao
  abstract fun bookmarkDao(): BookmarkDao

  companion object {
    @Volatile
    private var INSTANCE: ExamSeekDatabase? = null

    val MIGRATION_2_3 = object : androidx.room.migration.Migration(2, 3) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE questions ADD COLUMN targetExam TEXT NOT NULL DEFAULT 'SSC CGL'")
        db.execSQL("ALTER TABLE questions ADD COLUMN stage TEXT NOT NULL DEFAULT 'Tier-1'")
        db.execSQL("ALTER TABLE questions ADD COLUMN language TEXT NOT NULL DEFAULT 'ENGLISH'")
        db.execSQL("ALTER TABLE questions ADD COLUMN sourceLabel TEXT NOT NULL DEFAULT 'OFFICIAL_VERIFIED_PYQ'")
        db.execSQL("ALTER TABLE questions ADD COLUMN contentHash TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE questions ADD COLUMN createdAt INTEGER NOT NULL DEFAULT 0")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_questions_testId ON questions(testId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_questions_subject ON questions(subject)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_questions_topic ON questions(topic)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_questions_targetExam ON questions(targetExam)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_questions_contentHash ON questions(contentHash)")
      }
    }

    fun getInstance(context: Context): ExamSeekDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          ExamSeekDatabase::class.java,
          "examseek_database.db"
        )
          .addMigrations(MIGRATION_2_3)
          .addCallback(object : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
              super.onCreate(db)
              CoroutineScope(Dispatchers.IO).launch {
                val database = getInstance(context)
                database.userDao().insertUser(SampleExamData.defaultUser)
                database.testDao().insertTests(SampleExamData.sampleTests)
                database.questionDao().insertQuestions(SampleExamData.sampleQuestions)
                database.studyMaterialDao().insertMaterials(SampleExamData.sampleStudyMaterials)
              }
            }
          })
          .fallbackToDestructiveMigration(true)
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
