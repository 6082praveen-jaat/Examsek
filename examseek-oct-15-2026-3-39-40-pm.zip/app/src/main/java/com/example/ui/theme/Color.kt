package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ExamSeek Brand Palette - Modern Royal Navy & Emerald
val NavyPrimary = Color(0xFF1E3A8A)
val NavyLight = Color(0xFF3B82F6)
val NavyDark = Color(0xFF0F172A)
val NavyContainerLight = Color(0xFFDBEAFE)
val NavyOnContainerLight = Color(0xFF1E40AF)

val EmeraldSecondary = Color(0xFF0D9488)
val EmeraldLight = Color(0xFF14B8A6)
val EmeraldContainer = Color(0xFFCCFBF1)
val EmeraldOnContainer = Color(0xFF115E59)

val AmberAccent = Color(0xFFD97706)
val AmberLight = Color(0xFFF59E0B)
val AmberContainer = Color(0xFFFEF3C7)
val AmberOnContainer = Color(0xFF92400E)

val CrimsonError = Color(0xFFDC2626)
val CrimsonContainer = Color(0xFFFEE2E2)
val CrimsonOnContainer = Color(0xFF991B1B)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Theme Colors
val NavyPrimaryDark = Color(0xFF93C5FD)
val NavyContainerDark = Color(0xFF1E3A8A)
val NavyOnContainerDark = Color(0xFFDBEAFE)

val EmeraldSecondaryDark = Color(0xFF5EEAD4)
val EmeraldContainerDark = Color(0xFF0F766E)
val EmeraldOnContainerDark = Color(0xFFCCFBF1)

val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val OutlineDark = Color(0xFF475569)

// Exam Status Colors
val QuestionAnswered = Color(0xFF10B981)
val QuestionNotAnswered = Color(0xFFEF4444)
val QuestionMarkedReview = Color(0xFF8B5CF6)
val QuestionNotVisited = Color(0xFF94A3B8)
val VerifiedBadgeColor = Color(0xFF0284C7)
val DemoBadgeColor = Color(0xFFE11D48)
