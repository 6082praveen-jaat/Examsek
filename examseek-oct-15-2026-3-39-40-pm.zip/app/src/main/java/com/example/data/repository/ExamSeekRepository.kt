package com.example.data.repository

import android.content.Context
import com.example.data.ai.AiDoubtSolverService
import com.example.data.local.ExamSeekDatabase
import com.example.data.local.SampleExamData
import com.example.data.local.entity.ActiveTestSessionEntity
import com.example.data.local.entity.BookmarkEntity
import com.example.data.local.entity.QuestionEntity
import com.example.data.local.entity.StudyMaterialEntity
import com.example.data.local.entity.SubscriptionOrderEntity
import com.example.data.local.entity.TestAttemptEntity
import com.example.data.local.entity.TestEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WrongAnswerEntity
import com.example.domain.model.Difficulty
import com.example.domain.model.ExamCategory
import com.example.domain.model.StudyMaterialItem
import com.example.domain.model.SubscriptionTier
import com.example.domain.model.TestItem
import com.example.domain.model.TestQuestion
import com.example.domain.model.TestResult
import com.example.domain.model.TestType
import com.example.domain.model.WrongAnswerItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class ExamSeekRepository(private val context: Context) {

  private val database = ExamSeekDatabase.getInstance(context)
  private val userDao = database.userDao()
  private val testDao = database.testDao()
  private val questionDao = database.questionDao()
  private val testAttemptDao = database.testAttemptDao()
  private val activeSessionDao = database.activeTestSessionDao()
  private val wrongAnswerDao = database.wrongAnswerDao()
  private val studyMaterialDao = database.studyMaterialDao()
  private val subscriptionOrderDao = database.subscriptionOrderDao()
  private val bookmarkDao = database.bookmarkDao()

  val aiDoubtService = AiDoubtSolverService()
  val questionGeneratorService = com.example.data.ai.ExamQuestionGeneratorService()

  private val _currentUser = MutableStateFlow<UserEntity?>(null)
  val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

  init {
    CoroutineScope(Dispatchers.IO).launch {
      // Ensure seed data exists
      if (testDao.getTestById("test_ssc_cgl_tier1_01") == null) {
        testDao.insertTests(SampleExamData.sampleTests)
        questionDao.insertQuestions(SampleExamData.sampleQuestions)
        studyMaterialDao.insertMaterials(SampleExamData.sampleStudyMaterials)
      }
      var user = userDao.getUserById(1)
      if (user == null) {
        userDao.insertUser(SampleExamData.defaultUser)
        userDao.insertUser(SampleExamData.defaultAdmin)
        user = SampleExamData.defaultUser
      }
      _currentUser.value = user
    }
  }

  // Authentication
  suspend fun login(email: String, password: String): Result<UserEntity> = withContext(Dispatchers.IO) {
    val trimmedEmail = email.trim()
    val user = userDao.getUserByEmail(trimmedEmail)
    if (user != null && user.password == password) {
      _currentUser.value = user
      Result.success(user)
    } else {
      Result.failure(IllegalArgumentException("Invalid email or password. Try aspirant@examseek.com / password123"))
    }
  }

  suspend fun register(
    name: String,
    email: String,
    password: String,
    targetExam: String,
    phone: String
  ): Result<UserEntity> = withContext(Dispatchers.IO) {
    val trimmedEmail = email.trim()
    if (userDao.getUserByEmail(trimmedEmail) != null) {
      return@withContext Result.failure(IllegalArgumentException("User with this email already exists"))
    }
    val newUser = UserEntity(
      name = name.trim(),
      email = trimmedEmail,
      password = password,
      targetExam = targetExam,
      phone = phone.trim(),
      role = "STUDENT",
      subscriptionTier = "FREE"
    )
    val generatedId = userDao.insertUser(newUser)
    val created = newUser.copy(id = generatedId)
    _currentUser.value = created
    Result.success(created)
  }

  fun logout() {
    _currentUser.value = null
  }

  suspend fun updateTargetExamAndDate(targetExam: String, examDate: Long) = withContext(Dispatchers.IO) {
    val current = _currentUser.value ?: return@withContext
    userDao.updateTargetExamAndDate(current.id, targetExam, examDate)
    val updated = current.copy(targetExam = targetExam, targetExamDate = examDate)
    _currentUser.value = updated
  }

  suspend fun updateLanguage(lang: String) = withContext(Dispatchers.IO) {
    val current = _currentUser.value ?: return@withContext
    userDao.updateLanguage(current.id, lang)
    val updated = current.copy(preferredLanguage = lang)
    _currentUser.value = updated
  }

  suspend fun updateDailyGoal(goal: Int) = withContext(Dispatchers.IO) {
    val current = _currentUser.value ?: return@withContext
    userDao.updateDailyGoal(current.id, goal)
    val updated = current.copy(dailyGoalQuestions = goal)
    _currentUser.value = updated
  }

  // Tests & Questions
  fun getAllTests(): Flow<List<TestItem>> {
    return testDao.getAllTests().map { list ->
      list.map { it.toTestItem() }
    }
  }

  suspend fun getTestById(testId: String): TestItem? = withContext(Dispatchers.IO) {
    testDao.getTestById(testId)?.toTestItem()
  }

  suspend fun getQuestionsForTest(testId: String): List<TestQuestion> = withContext(Dispatchers.IO) {
    questionDao.getQuestionsForTest(testId).map { it.toTestQuestion() }
  }

  fun getAllQuestions(): Flow<List<TestQuestion>> {
    return questionDao.getAllQuestions().map { list -> list.map { it.toTestQuestion() } }
  }

  // Active Session Persistence (Restore in-progress test safely)
  suspend fun saveActiveTestSession(
    testId: String,
    timeRemainingSeconds: Int,
    currentIndex: Int,
    answers: Map<String, Int?>,
    markedForReview: Set<String>,
    applyNegativeMarking: Boolean
  ) = withContext(Dispatchers.IO) {
    val userId = _currentUser.value?.id ?: 1L
    val answersStr = answers.entries.joinToString(",") { "${it.key}:${it.value ?: -1}" }
    val markedStr = markedForReview.joinToString(",")

    val session = ActiveTestSessionEntity(
      testId = testId,
      userId = userId,
      timeRemainingSeconds = timeRemainingSeconds,
      currentIndex = currentIndex,
      answersSummary = answersStr,
      markedReviewSummary = markedStr,
      applyNegativeMarking = applyNegativeMarking,
      lastSavedTimestamp = System.currentTimeMillis()
    )
    activeSessionDao.saveActiveSession(session)
  }

  suspend fun getActiveTestSession(testId: String): ActiveTestSessionEntity? = withContext(Dispatchers.IO) {
    val userId = _currentUser.value?.id ?: 1L
    activeSessionDao.getActiveSession(testId, userId)
  }

  suspend fun getLatestActiveSession(): ActiveTestSessionEntity? = withContext(Dispatchers.IO) {
    val userId = _currentUser.value?.id ?: 1L
    activeSessionDao.getLatestActiveSession(userId)
  }

  suspend fun clearActiveTestSession(testId: String) = withContext(Dispatchers.IO) {
    val userId = _currentUser.value?.id ?: 1L
    activeSessionDao.deleteActiveSession(testId, userId)
  }

  // Test Evaluation & Scoring
  suspend fun evaluateAndSubmitTest(
    test: TestItem,
    questions: List<TestQuestion>,
    answers: Map<String, Int?>,
    timeSpentSeconds: Int,
    applyNegativeMarking: Boolean
  ): TestResult = withContext(Dispatchers.IO) {
    var correctCount = 0
    var incorrectCount = 0
    var unattemptedCount = 0

    val answersSummaryBuilder = StringBuilder()
    val userId = _currentUser.value?.id ?: 1L

    questions.forEach { q ->
      val selectedOption = answers[q.id]
      val selectedStr = selectedOption?.toString() ?: "-1"
      if (answersSummaryBuilder.isNotEmpty()) answersSummaryBuilder.append(",")
      answersSummaryBuilder.append("${q.id}:$selectedStr")

      if (selectedOption == null) {
        unattemptedCount++
      } else if (selectedOption == q.correctOptionIndex) {
        correctCount++
      } else {
        incorrectCount++
        // Automatically save wrong answer to Wrong-Answer Notebook (Mistake Vault)
        wrongAnswerDao.insertWrongAnswer(
          WrongAnswerEntity(
            id = "wa_${System.currentTimeMillis()}_${q.id}",
            userId = userId,
            questionId = q.id,
            testId = test.id,
            userWrongOption = selectedOption,
            correctOption = q.correctOptionIndex,
            recordedAt = System.currentTimeMillis(),
            isResolved = false
          )
        )
      }
    }

    val marksPerCorrect = test.marksPerQuestion
    val negativeRate = if (applyNegativeMarking) test.negativeMarkingRate else 0.0f

    val positiveMarks = correctCount * marksPerCorrect
    val negativeDeduction = incorrectCount * negativeRate
    val rawMarks = positiveMarks - negativeDeduction
    val finalScore = maxOf(0.0f, rawMarks)

    val attempted = correctCount + incorrectCount
    val accuracy = if (attempted > 0) (correctCount.toFloat() / attempted) * 100f else 0.0f

    val totalPossibleMarks = questions.size * marksPerCorrect
    val percentile = if (totalPossibleMarks > 0) {
      val ratio = (finalScore / totalPossibleMarks) * 100f
      minOf(99.4f, maxOf(15.0f, ratio * 0.95f + 10.0f))
    } else 50.0f

    val attemptId = UUID.randomUUID().toString()

    val attemptEntity = TestAttemptEntity(
      attemptId = attemptId,
      userId = userId,
      testId = test.id,
      testTitle = test.title,
      category = test.category.id,
      score = finalScore,
      totalMarks = totalPossibleMarks,
      accuracy = accuracy,
      totalQuestions = questions.size,
      correctCount = correctCount,
      incorrectCount = incorrectCount,
      unattemptedCount = unattemptedCount,
      timeSpentSeconds = timeSpentSeconds,
      totalTimeSeconds = test.durationMinutes * 60,
      negativeMarkingApplied = applyNegativeMarking,
      negativeMarksDeducted = negativeDeduction,
      attemptedAt = System.currentTimeMillis(),
      answersSummary = answersSummaryBuilder.toString()
    )

    testAttemptDao.insertAttempt(attemptEntity)

    // Clear active in-progress session since test is finished
    activeSessionDao.deleteActiveSession(test.id, userId)

    TestResult(
      attemptId = attemptId,
      testId = test.id,
      testTitle = test.title,
      category = test.category,
      totalQuestions = questions.size,
      correctAnswersCount = correctCount,
      incorrectAnswersCount = incorrectCount,
      unattemptedCount = unattemptedCount,
      marksObtained = finalScore,
      totalMarks = totalPossibleMarks,
      accuracyPercentage = accuracy,
      timeSpentSeconds = timeSpentSeconds,
      totalTimeSeconds = test.durationMinutes * 60,
      negativeMarkingApplied = applyNegativeMarking,
      negativeMarksDeducted = negativeDeduction,
      percentileEstimate = percentile,
      dateTimestamp = attemptEntity.attemptedAt,
      questions = questions,
      userAnswers = answers
    )
  }

  // Attempts
  fun getAttemptsForCurrentUser(): Flow<List<TestAttemptEntity>> {
    val currentUserId = _currentUser.value?.id ?: 1L
    return testAttemptDao.getAttemptsForUser(currentUserId)
  }

  // Wrong Answers Notebook
  fun getWrongAnswersForCurrentUser(): Flow<List<WrongAnswerItem>> {
    val currentUserId = _currentUser.value?.id ?: 1L
    return wrongAnswerDao.getUnresolvedWrongAnswers(currentUserId).map { list ->
      list.mapNotNull { entity ->
        val question = questionDao.getQuestionById(entity.questionId)?.toTestQuestion()
        if (question != null) {
          WrongAnswerItem(
            id = entity.id,
            question = question,
            userWrongOption = entity.userWrongOption,
            recordedAt = entity.recordedAt,
            isResolved = entity.isResolved
          )
        } else null
      }
    }
  }

  suspend fun resolveWrongAnswer(id: String) = withContext(Dispatchers.IO) {
    wrongAnswerDao.markResolved(id)
  }

  // Study Materials
  fun getStudyMaterials(): Flow<List<StudyMaterialItem>> {
    return studyMaterialDao.getAllMaterials().map { list ->
      list.map { it.toStudyMaterialItem() }
    }
  }

  // Bookmarks
  fun getBookmarksForCurrentUser(): Flow<List<BookmarkEntity>> {
    val currentUserId = _currentUser.value?.id ?: 1L
    return bookmarkDao.getBookmarksForUser(currentUserId)
  }

  suspend fun isBookmarked(questionId: String): Boolean = withContext(Dispatchers.IO) {
    val currentUserId = _currentUser.value?.id ?: 1L
    bookmarkDao.isBookmarked(questionId, currentUserId)
  }

  suspend fun toggleBookmark(questionId: String) = withContext(Dispatchers.IO) {
    val currentUserId = _currentUser.value?.id ?: 1L
    if (bookmarkDao.isBookmarked(questionId, currentUserId)) {
      bookmarkDao.deleteBookmark(questionId, currentUserId)
    } else {
      bookmarkDao.insertBookmark(BookmarkEntity(questionId = questionId, userId = currentUserId))
    }
  }

  // AI Doubt Quotas & Calling
  suspend fun canUseAiDoubt(): Pair<Boolean, String> = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext Pair(false, "Please log in to use AI Doubt Solver")
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    val tier = try { SubscriptionTier.valueOf(user.subscriptionTier) } catch (e: Exception) { SubscriptionTier.FREE }
    val maxLimit = when (tier) {
      SubscriptionTier.FREE -> 3
      SubscriptionTier.PLUS -> 15
      SubscriptionTier.PRO -> 999
    }

    val usedToday = if (user.lastAiDoubtDate == today) user.aiDoubtsUsedToday else 0
    if (usedToday >= maxLimit) {
      return@withContext Pair(false, "Daily AI limit of $maxLimit doubts reached for ${tier.displayName}. Upgrade plan for higher limits!")
    }
    Pair(true, "Allowed (${maxLimit - usedToday} left today)")
  }

  suspend fun recordAiDoubtUsed() = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    val usedToday = if (user.lastAiDoubtDate == today) user.aiDoubtsUsedToday + 1 else 1
    userDao.updateAiDoubtUsage(user.id, usedToday, today)
    _currentUser.value = user.copy(aiDoubtsUsedToday = usedToday, lastAiDoubtDate = today)
  }

  // Subscriptions & Payment Handling
  suspend fun purchaseSubscription(planId: String, tier: SubscriptionTier, amount: Int, durationMonths: Int): Result<String> = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext Result.failure(Exception("User not authenticated"))

    val orderId = "ORD_${System.currentTimeMillis()}_${user.id}"
    val expiryTime = System.currentTimeMillis() + (durationMonths.toLong() * 30 * 24 * 60 * 60 * 1000)

    val order = SubscriptionOrderEntity(
      orderId = orderId,
      userId = user.id,
      plan = planId,
      amount = amount,
      status = "ACTIVE",
      gateway = "EXAMSEEK_SECURE_PAYMENT_SIMULATOR",
      transactionRef = "TXN_${UUID.randomUUID().toString().take(10).uppercase()}",
      createdAt = System.currentTimeMillis(),
      expiresAt = expiryTime
    )

    subscriptionOrderDao.insertOrder(order)
    userDao.updateSubscription(user.id, tier.name, expiryTime)
    _currentUser.value = user.copy(subscriptionTier = tier.name, subscriptionExpiry = expiryTime)

    Result.success(orderId)
  }

  fun getSubscriptionOrders(): Flow<List<SubscriptionOrderEntity>> {
    val userId = _currentUser.value?.id ?: 1L
    return subscriptionOrderDao.getOrdersForUser(userId)
  }

  // Admin Panel operations
  suspend fun createCustomTest(test: TestEntity) = withContext(Dispatchers.IO) {
    testDao.insertTest(test)
  }

  suspend fun createCustomQuestion(question: QuestionEntity) = withContext(Dispatchers.IO) {
    questionDao.insertQuestion(question)
  }

  suspend fun toggleTestVerification(testId: String) = withContext(Dispatchers.IO) {
    val existing = testDao.getTestById(testId) ?: return@withContext
    val updated = existing.copy(isVerified = !existing.isVerified)
    testDao.insertTest(updated)
  }

  // Dynamic Question Bank & AI Generator methods
  fun getQuestionsForExam(examName: String, subject: String = "All", topic: String = "All"): Flow<List<TestQuestion>> {
    return questionDao.getFilteredQuestionsFlow(examName, subject, topic).map { list ->
      list.map { it.toTestQuestion() }
    }
  }

  suspend fun getQuestionCountForExam(examName: String): Int = withContext(Dispatchers.IO) {
    questionDao.getQuestionCountForExam(examName)
  }

  suspend fun getQuestionCountForTopic(examName: String, topic: String): Int = withContext(Dispatchers.IO) {
    questionDao.getQuestionCountForExamTopic(examName, topic)
  }

  fun getPendingReviewQuestions(): Flow<List<TestQuestion>> {
    return questionDao.getQuestionsPendingReviewFlow().map { list ->
      list.map { it.toTestQuestion() }
    }
  }

  suspend fun updateQuestionReviewStatus(id: String, verified: Boolean, sourceLabel: String) = withContext(Dispatchers.IO) {
    questionDao.updateQuestionVerification(id, verified, sourceLabel)
  }

  suspend fun deleteQuestion(id: String) = withContext(Dispatchers.IO) {
    questionDao.deleteQuestion(id)
  }

  suspend fun generateAndSaveQuestionBatch(
    examDetail: com.example.domain.model.ExamDetail,
    stage: String,
    subject: String,
    topic: String,
    difficulty: String,
    language: String,
    batchSize: Int
  ): com.example.data.ai.GenerationResult = withContext(Dispatchers.IO) {
    val genResult = questionGeneratorService.generateQuestionBatch(
      examDetail = examDetail,
      stage = stage,
      subject = subject,
      topic = topic,
      difficulty = difficulty,
      language = language,
      batchSize = batchSize,
      existingHashesChecker = { hash ->
        questionDao.existsByContentHash(hash)
      }
    )

    if (genResult is com.example.data.ai.GenerationResult.Success) {
      if (genResult.questions.isNotEmpty()) {
        questionDao.insertQuestions(genResult.questions)
      }
    }

    genResult
  }

  suspend fun createDynamicMockTest(
    examDetail: com.example.domain.model.ExamDetail,
    stage: String,
    subject: String,
    topic: String,
    questionCount: Int,
    durationMinutes: Int
  ): Pair<TestItem, List<TestQuestion>> = withContext(Dispatchers.IO) {
    val pool = questionDao.getPagedQuestions(
      exam = examDetail.name,
      subject = subject,
      topic = topic,
      limit = questionCount,
      offset = 0
    )

    val finalQuestions: List<QuestionEntity> = if (pool.size < questionCount) {
      val fillMore = questionDao.getRandomQuestionsForExam(
        exam = examDetail.name,
        subject = subject,
        limit = questionCount
      )
      (pool + fillMore).distinctBy { it.id }.take(questionCount)
    } else {
      pool.shuffled().take(questionCount)
    }

    val testId = "dyn_test_${System.currentTimeMillis()}"
    val testEntity = TestEntity(
      id = testId,
      title = "${examDetail.name} AI Practice Mock ($subject - $topic)",
      category = examDetail.category.name,
      type = "PRACTICE_SET",
      durationMinutes = durationMinutes,
      totalMarks = finalQuestions.size * examDetail.defaultMarksPerQuestion,
      marksPerQuestion = examDetail.defaultMarksPerQuestion,
      negativeMarkingRate = examDetail.defaultNegativeMarking,
      isVerified = examDetail.verifiedMarkingScheme,
      subject = subject,
      description = "Generated Practice Test on ${examDetail.name} ($stage). Marking: +${examDetail.defaultMarksPerQuestion}, -${examDetail.defaultNegativeMarking}.",
      tier = "FREE",
      attemptsCount = 1
    )

    testDao.insertTest(testEntity)
    Pair(testEntity.toTestItem(), finalQuestions.map { it.copy(testId = testId).toTestQuestion() })
  }

  // Conversion extensions
  private fun TestEntity.toTestItem(): TestItem {
    return TestItem(
      id = this.id,
      title = this.title,
      category = ExamCategory.fromId(this.category),
      type = try { TestType.valueOf(this.type) } catch (e: Exception) { TestType.FULL_MOCK },
      durationMinutes = this.durationMinutes,
      totalQuestions = 0,
      totalMarks = this.totalMarks,
      marksPerQuestion = this.marksPerQuestion,
      negativeMarkingRate = this.negativeMarkingRate,
      isNegativeMarkingEnabled = this.negativeMarkingRate > 0f,
      isVerified = this.isVerified,
      subject = this.subject,
      description = this.description,
      tier = try { SubscriptionTier.valueOf(this.tier) } catch (e: Exception) { SubscriptionTier.FREE },
      attemptsCount = this.attemptsCount
    )
  }

  private fun QuestionEntity.toTestQuestion(): TestQuestion {
    return TestQuestion(
      id = this.id,
      testId = this.testId,
      subject = this.subject,
      topic = this.topic,
      questionText = this.questionText,
      hindiQuestionText = this.hindiQuestionText,
      options = listOf(this.optionA, this.optionB, this.optionC, this.optionD),
      hindiOptions = if (this.hindiOptionA.isNotBlank()) listOf(this.hindiOptionA, this.hindiOptionB, this.hindiOptionC, this.hindiOptionD) else emptyList(),
      correctOptionIndex = this.correctOptionIndex,
      explanation = this.explanation,
      hindiExplanation = this.hindiExplanation,
      difficulty = try { Difficulty.valueOf(this.difficulty) } catch (e: Exception) { Difficulty.MEDIUM },
      source = this.source,
      year = this.year,
      isVerified = this.isVerified,
      sourceLabel = this.sourceLabel,
      contentHash = this.contentHash,
      targetExam = this.targetExam,
      stage = this.stage
    )
  }

  private fun StudyMaterialEntity.toStudyMaterialItem(): StudyMaterialItem {
    return StudyMaterialItem(
      id = this.id,
      title = this.title,
      category = this.category,
      subject = this.subject,
      dateLabel = this.dateLabel,
      content = this.content,
      source = this.source,
      tier = try { SubscriptionTier.valueOf(this.tier) } catch (e: Exception) { SubscriptionTier.FREE }
    )
  }
}
