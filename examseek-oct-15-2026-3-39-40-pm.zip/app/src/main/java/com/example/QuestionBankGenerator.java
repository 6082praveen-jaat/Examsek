package com.example;

/**
 * QuestionBankGenerator alias in com.example
 */
public class QuestionBankGenerator extends com.example.data.ai.QuestionBankGenerator {
}
